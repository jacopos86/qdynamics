#!/usr/bin/env bash
set -euo pipefail
umask 077
PACKAGE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRATCH_ROOT="$PWD"
verify_file() { local relative="$1" expected_bytes="$2" expected_sha="$3"; local target="$PACKAGE_ROOT/$relative"; [[ -f "$target" ]] && [[ "$(wc -c < "$target" | tr -d " ")" == "$expected_bytes" ]] && [[ "$(sha256sum "$target" | awk '{print $1}')" == "$expected_sha" ]] || exit 2; }
verify_file executor_overlay/pipelines/scaffold/runtime_loader.py 67574 1f61046961b756d0a7c520459dd9a126e771d531cd33c2343aa390c0b8311d56
verify_file executor_overlay/pipelines/time_dynamics/ap_mclachlan/exchange_integration.py 32565 a26ff1cd92c37d5712270f72a40323ed6713a76cfd4ac11a01c65aaaabee175c
verify_file executor_overlay/pipelines/time_dynamics/ap_mclachlan/exchange_selector.py 13499 376a9261bded89d649031974e89df53b7190fe5082fc1921773a874176556e51
verify_file executor_overlay/pipelines/time_dynamics/ap_mclachlan/exchange_structural.py 23152 757a5a9f3aa59c88a1357161223d0dadb9dbf3c425980405c72d17847ed20819
verify_file executor_overlay/pipelines/time_dynamics/generalized_exchange.py 6161 18d73690f8d29abcd279b7480d95be0474be6beb27459eb35ef6a5436c3033b3
verify_file executor_overlay/pipelines/time_dynamics/prospective_apm_exchange_worker.py 64832 4f82b337752424beb7918eabb40069e0a0eafcf7205ac953de3af920e8733c14
verify_file executor_overlay/pipelines/time_dynamics/runners/run_prospective_apm_exchange.py 6039 a29c9d69a5e4cfa14e8d64f1f65943e83b90a421f7956afb05358fc82899eea9
verify_file input/execution_request.json 5494 dc9357e5732475421a39ce75d50e5069f7f412e25021c23c5ee66582b45d26e1
verify_file input/executor_overlay_identity.json 2542 c54e46431b8b7cf8a402a6c8ea7d693ab88ad693820ea6babd3b39c07787bad9
verify_file input/runtime_image_identity.json 453 ba0a01109dd7d233499ac451a672b4eef0e9e999f4ca893bbcd0ec548dff3d85
verify_file input/seed.json 380952 0d26126cb1568b051bc2d33178b6b0c3a5e2481667308e5df4c85ac59a4daf63
verify_file input/seed_qualification_receipt.json 1107 b9e34d07f819acc885e93e3e7fbdcb4a8315a69244e5ef25466dc3ff7bbcf1c3
verify_file input/source_epoch_receipt.json 895 cc65dda01379cf8a6125eec1e082acb40e6b1121ad70d98c3e293d62e24efe96
verify_file input/source_tree_manifest.json 5528512 a4addfe3a6397f8abe65cefafd9810ddeb1b58f8d206c0672f31e4feedc86eb3
verify_file input/work_order.json 19520 ce37112474abb62a9084059fefef7b306bd74b2ad8ac6d663a04c72006db341a
verify_file submit.sub 2753 f7bcb460f3c88c2f58bddbe6e22171bfb615a6faca883caab7b08e7ce204feb4
RUNTIME_SOURCE="$SCRATCH_ROOT/source_5eedf0dc_runtime.tar.gz"
[[ -f "$RUNTIME_SOURCE" ]] && [[ "$(wc -c < "$RUNTIME_SOURCE" | tr -d " ")" == "5324792" ]] && [[ "$(sha256sum "$RUNTIME_SOURCE" | awk '{print $1}')" == "da056abce6f9c15d3352ad08a06baa78964e31b338df74c83d1d8bf39429db76" ]] || exit 2
IMAGE="$SCRATCH_ROOT/image.sif"
[[ -f "$IMAGE" ]] && [[ "$(wc -c < "$IMAGE" | tr -d " ")" == "216371200" ]] && [[ "$(sha256sum "$IMAGE" | awk '{print $1}')" == "fa5c4ea89a19ad2fa4c264f3bce65d9e83b86b91618ed97dfc80ee7be401239f" ]] || exit 2
if command -v apptainer >/dev/null 2>&1; then APPTAINER_BIN="$(command -v apptainer)"; elif command -v singularity >/dev/null 2>&1; then APPTAINER_BIN="$(command -v singularity)"; else exit 127; fi
tar -xzf "$RUNTIME_SOURCE" -C "$SCRATCH_ROOT"
SOURCE_ROOT="$SCRATCH_ROOT/source"
RAW_ROOT="$SCRATCH_ROOT/raw_outputs/paper_ii_apm_exchange/paper-ii-hubbard-l4-scale-v1-e667b05f39a4b711cb1c"
mkdir -p "$RAW_ROOT"
mkdir -p "$SOURCE_ROOT/output/paper_ii_hubbard_l4_scale_v1/source_epochs/bootstrap_5eedf0dc"
cp "$PACKAGE_ROOT/input/source_epoch_receipt.json" "$SOURCE_ROOT/output/paper_ii_hubbard_l4_scale_v1/source_epochs/bootstrap_5eedf0dc/source_epoch_receipt.json"
mkdir -p "$SOURCE_ROOT/output/paper_ii_hubbard_l4_scale_v1/seeds/l4__u4__half_filled"
cp "$PACKAGE_ROOT/input/seed_qualification_receipt.json" "$SOURCE_ROOT/output/paper_ii_hubbard_l4_scale_v1/seeds/l4__u4__half_filled/seed_qualification_receipt.json"
mkdir -p "$SOURCE_ROOT/output/paper_ii_hubbard_l4_scale_v1/seeds/l4__u4__half_filled"
cp "$PACKAGE_ROOT/input/seed.json" "$SOURCE_ROOT/output/paper_ii_hubbard_l4_scale_v1/seeds/l4__u4__half_filled/seed.json"
mkdir -p "$SOURCE_ROOT/_paper_ii_bootstrap/paper-ii-hubbard-l4-scale-v1-e667b05f39a4b711cb1c"
cp "$PACKAGE_ROOT/input/work_order.json" "$SOURCE_ROOT/_paper_ii_bootstrap/paper-ii-hubbard-l4-scale-v1-e667b05f39a4b711cb1c/apm_exchange_work_order.json"
mkdir -p "$SOURCE_ROOT/output/paper_ii_hubbard_l4_scale_v1/source_epochs/bootstrap_5eedf0dc"
cp "$PACKAGE_ROOT/input/source_tree_manifest.json" "$SOURCE_ROOT/output/paper_ii_hubbard_l4_scale_v1/source_epochs/bootstrap_5eedf0dc/source_tree_manifest.json"
"$APPTAINER_BIN" exec --cleanenv --bind "$SOURCE_ROOT:/work" "$IMAGE" bash -lc 'cd /work && PYTHONPATH=. python3 -c '"'"'from pipelines.time_dynamics.prospective_execution_bindings import SourceEpochReceipt; SourceEpochReceipt.load('"'"'"'"'"'"'"'"'output/paper_ii_hubbard_l4_scale_v1/source_epochs/bootstrap_5eedf0dc/source_epoch_receipt.json'"'"'"'"'"'"'"'"', repository_root='"'"'"'"'"'"'"'"'.'"'"'"'"'"'"'"'"')'"'"''
[[ ! -e "$SOURCE_ROOT/pipelines/time_dynamics/prospective_apm_exchange_worker.py" ]] || { echo "unexpected pristine base path: pipelines/time_dynamics/prospective_apm_exchange_worker.py" >&2; exit 2; }
[[ "$(sha256sum "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/prospective_apm_exchange_worker.py" | awk '{print $1}')" == "4f82b337752424beb7918eabb40069e0a0eafcf7205ac953de3af920e8733c14" ]] || { echo "executor overlay digest mismatch: pipelines/time_dynamics/prospective_apm_exchange_worker.py" >&2; exit 2; }
mkdir -p "$(dirname "$SOURCE_ROOT/pipelines/time_dynamics/prospective_apm_exchange_worker.py")"
cp "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/prospective_apm_exchange_worker.py" "$SOURCE_ROOT/pipelines/time_dynamics/prospective_apm_exchange_worker.py"
[[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/prospective_apm_exchange_worker.py" | awk '{print $1}')" == "4f82b337752424beb7918eabb40069e0a0eafcf7205ac953de3af920e8733c14" ]] || { echo "installed executor overlay mismatch: pipelines/time_dynamics/prospective_apm_exchange_worker.py" >&2; exit 2; }
[[ ! -e "$SOURCE_ROOT/pipelines/time_dynamics/runners/run_prospective_apm_exchange.py" ]] || { echo "unexpected pristine base path: pipelines/time_dynamics/runners/run_prospective_apm_exchange.py" >&2; exit 2; }
[[ "$(sha256sum "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/runners/run_prospective_apm_exchange.py" | awk '{print $1}')" == "a29c9d69a5e4cfa14e8d64f1f65943e83b90a421f7956afb05358fc82899eea9" ]] || { echo "executor overlay digest mismatch: pipelines/time_dynamics/runners/run_prospective_apm_exchange.py" >&2; exit 2; }
mkdir -p "$(dirname "$SOURCE_ROOT/pipelines/time_dynamics/runners/run_prospective_apm_exchange.py")"
cp "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/runners/run_prospective_apm_exchange.py" "$SOURCE_ROOT/pipelines/time_dynamics/runners/run_prospective_apm_exchange.py"
[[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/runners/run_prospective_apm_exchange.py" | awk '{print $1}')" == "a29c9d69a5e4cfa14e8d64f1f65943e83b90a421f7956afb05358fc82899eea9" ]] || { echo "installed executor overlay mismatch: pipelines/time_dynamics/runners/run_prospective_apm_exchange.py" >&2; exit 2; }
[[ -f "$SOURCE_ROOT/pipelines/scaffold/runtime_loader.py" ]] && [[ "$(sha256sum "$SOURCE_ROOT/pipelines/scaffold/runtime_loader.py" | awk '{print $1}')" == "1f61046961b756d0a7c520459dd9a126e771d531cd33c2343aa390c0b8311d56" ]] || { echo "pristine base digest mismatch: pipelines/scaffold/runtime_loader.py" >&2; exit 2; }
[[ "$(sha256sum "$PACKAGE_ROOT/executor_overlay/pipelines/scaffold/runtime_loader.py" | awk '{print $1}')" == "1f61046961b756d0a7c520459dd9a126e771d531cd33c2343aa390c0b8311d56" ]] || { echo "executor overlay digest mismatch: pipelines/scaffold/runtime_loader.py" >&2; exit 2; }
mkdir -p "$(dirname "$SOURCE_ROOT/pipelines/scaffold/runtime_loader.py")"
cp "$PACKAGE_ROOT/executor_overlay/pipelines/scaffold/runtime_loader.py" "$SOURCE_ROOT/pipelines/scaffold/runtime_loader.py"
[[ "$(sha256sum "$SOURCE_ROOT/pipelines/scaffold/runtime_loader.py" | awk '{print $1}')" == "1f61046961b756d0a7c520459dd9a126e771d531cd33c2343aa390c0b8311d56" ]] || { echo "installed executor overlay mismatch: pipelines/scaffold/runtime_loader.py" >&2; exit 2; }
[[ -f "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_integration.py" ]] && [[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_integration.py" | awk '{print $1}')" == "60e3b7b27a869f2fedab8be9471c570924b5dbbdbcaf085a6ea6d7bd9d2bdb52" ]] || { echo "pristine base digest mismatch: pipelines/time_dynamics/ap_mclachlan/exchange_integration.py" >&2; exit 2; }
[[ "$(sha256sum "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/ap_mclachlan/exchange_integration.py" | awk '{print $1}')" == "a26ff1cd92c37d5712270f72a40323ed6713a76cfd4ac11a01c65aaaabee175c" ]] || { echo "executor overlay digest mismatch: pipelines/time_dynamics/ap_mclachlan/exchange_integration.py" >&2; exit 2; }
mkdir -p "$(dirname "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_integration.py")"
cp "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/ap_mclachlan/exchange_integration.py" "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_integration.py"
[[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_integration.py" | awk '{print $1}')" == "a26ff1cd92c37d5712270f72a40323ed6713a76cfd4ac11a01c65aaaabee175c" ]] || { echo "installed executor overlay mismatch: pipelines/time_dynamics/ap_mclachlan/exchange_integration.py" >&2; exit 2; }
[[ -f "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_selector.py" ]] && [[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_selector.py" | awk '{print $1}')" == "8b19fd59e1cea8dcb201e4a17f09c96d3fa2fe1b05e3adfce7d6596fa7926e42" ]] || { echo "pristine base digest mismatch: pipelines/time_dynamics/ap_mclachlan/exchange_selector.py" >&2; exit 2; }
[[ "$(sha256sum "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/ap_mclachlan/exchange_selector.py" | awk '{print $1}')" == "376a9261bded89d649031974e89df53b7190fe5082fc1921773a874176556e51" ]] || { echo "executor overlay digest mismatch: pipelines/time_dynamics/ap_mclachlan/exchange_selector.py" >&2; exit 2; }
mkdir -p "$(dirname "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_selector.py")"
cp "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/ap_mclachlan/exchange_selector.py" "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_selector.py"
[[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_selector.py" | awk '{print $1}')" == "376a9261bded89d649031974e89df53b7190fe5082fc1921773a874176556e51" ]] || { echo "installed executor overlay mismatch: pipelines/time_dynamics/ap_mclachlan/exchange_selector.py" >&2; exit 2; }
[[ -f "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_structural.py" ]] && [[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_structural.py" | awk '{print $1}')" == "8b946879334fbca21603fc7916f81627c8986aac09aa1f5a1a8a06f24db25970" ]] || { echo "pristine base digest mismatch: pipelines/time_dynamics/ap_mclachlan/exchange_structural.py" >&2; exit 2; }
[[ "$(sha256sum "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/ap_mclachlan/exchange_structural.py" | awk '{print $1}')" == "757a5a9f3aa59c88a1357161223d0dadb9dbf3c425980405c72d17847ed20819" ]] || { echo "executor overlay digest mismatch: pipelines/time_dynamics/ap_mclachlan/exchange_structural.py" >&2; exit 2; }
mkdir -p "$(dirname "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_structural.py")"
cp "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/ap_mclachlan/exchange_structural.py" "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_structural.py"
[[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/ap_mclachlan/exchange_structural.py" | awk '{print $1}')" == "757a5a9f3aa59c88a1357161223d0dadb9dbf3c425980405c72d17847ed20819" ]] || { echo "installed executor overlay mismatch: pipelines/time_dynamics/ap_mclachlan/exchange_structural.py" >&2; exit 2; }
[[ -f "$SOURCE_ROOT/pipelines/time_dynamics/generalized_exchange.py" ]] && [[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/generalized_exchange.py" | awk '{print $1}')" == "c3db50b17dc890702945bc5829d6c1d98149f95b0e216504d3a6387aaa1ea89d" ]] || { echo "pristine base digest mismatch: pipelines/time_dynamics/generalized_exchange.py" >&2; exit 2; }
[[ "$(sha256sum "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/generalized_exchange.py" | awk '{print $1}')" == "18d73690f8d29abcd279b7480d95be0474be6beb27459eb35ef6a5436c3033b3" ]] || { echo "executor overlay digest mismatch: pipelines/time_dynamics/generalized_exchange.py" >&2; exit 2; }
mkdir -p "$(dirname "$SOURCE_ROOT/pipelines/time_dynamics/generalized_exchange.py")"
cp "$PACKAGE_ROOT/executor_overlay/pipelines/time_dynamics/generalized_exchange.py" "$SOURCE_ROOT/pipelines/time_dynamics/generalized_exchange.py"
[[ "$(sha256sum "$SOURCE_ROOT/pipelines/time_dynamics/generalized_exchange.py" | awk '{print $1}')" == "18d73690f8d29abcd279b7480d95be0474be6beb27459eb35ef6a5436c3033b3" ]] || { echo "installed executor overlay mismatch: pipelines/time_dynamics/generalized_exchange.py" >&2; exit 2; }
cp "$PACKAGE_ROOT/input/executor_overlay_identity.json" "$RAW_ROOT/executor_overlay_identity.json"
printf "%s\n" "pristine base source epoch verified before executor overlay" > "$RAW_ROOT/BASE_SOURCE_VERIFIED_BEFORE_OVERLAY"
set +e
"$APPTAINER_BIN" exec --cleanenv --bind "$SOURCE_ROOT:/work" "$IMAGE" bash -lc 'cd /work && PYTHONPATH=. PYTHONUNBUFFERED=1 python3 -m pipelines.time_dynamics.runners.run_prospective_apm_exchange run --repo-root . --work-order _paper_ii_bootstrap/paper-ii-hubbard-l4-scale-v1-e667b05f39a4b711cb1c/apm_exchange_work_order.json' >"$RAW_ROOT/worker_stdout.json" 2>"$RAW_ROOT/worker_stderr.log"
status=$?
set -e
[[ "$status" -eq 0 ]] || exit "$status"
cp "$SOURCE_ROOT/output/prospective_scientific/paper_ii_hubbard_l4_scale_v1/hubbard__l4__u4__weakslow/apm_exchange/e667b05f39a4b711cb1c/run.json" "$RAW_ROOT/run.json"
cp "$SOURCE_ROOT/output/prospective_scientific/paper_ii_hubbard_l4_scale_v1/hubbard__l4__u4__weakslow/apm_exchange/e667b05f39a4b711cb1c/completion_receipt.json" "$RAW_ROOT/completion_receipt.json"
printf "%s\n" "raw evidence preserved; no remote cleanup authorized" > "$RAW_ROOT/REMOTE_RAW_PRESERVED"
