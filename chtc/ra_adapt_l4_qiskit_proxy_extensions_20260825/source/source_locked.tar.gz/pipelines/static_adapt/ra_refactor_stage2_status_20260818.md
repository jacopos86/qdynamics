# RA Refactor Stage 2 — CLOSED 2026-08-18

**Stage 2 is complete.** Route C (plateau acquisition) no longer exists
as executable code: 541 monolith traces reduced to a handful of
honestly-named historical-compat readers; 15 parameters and CLI flags
removed; `plateau_acquisition.py`, `route_c_plateau.py`, and their
dedicated test retired into
`archive/route_c_plateau_retirement_20260818/` (hash-locked manifest);
`test/test_route_c_retired_reachability.py` keeps them retired. Battery
at close: 196 passed (parity, scoring, historical identity, both
reachability suites) + 67 facade. Old checkpoints containing Route C
rows still compact correctly via the verbatim compat copies in
`checkpoint_telemetry.py`. Stage 3 (module split per the design
decisions below) is the next campaign.

## Stage 3 progress (2026-08-18)

- Increment 1 (`49c92252`): energy-model skeleton — `Phase3EnergyModel`
  (exact delegation, equivalence-tested), `RecordSet` with in-run
  restriction traces, named restriction taxonomy incl.
  append-as-specialization. S3 = DeltaE_TR/K3 convention (unit floor
  inside K3 per Paper 1) documented in the contract.
- Increment 2 (`0c870fc7`): cost backends as separate callable files —
  `qiskit_cost.py` (default) and `proxy_cost.py`; `selection.py` is
  fail-closed (proxy constructs only with the explicit user speed flag)
  and emits a declared cost-backend payload for run records.
- Increment 3 (`82f1e286`): the three phase evaluators (487 lines)
  relocated verbatim into `energy_model/phases.py`; scaffold keeps lazy
  compat wrappers. All guard suites green at every increment.

## Stage-3 backlog (user, 2026-08-18 evening)

1. V3 sheet execution (blueprint committed).
2. [DONE 2026-08-19, first increment] CHTC memory diet: estimator
   ledger occurrence streaming landed (env
   STATIC_ADAPT_ESTIMATOR_LEDGER_STREAM_DIR; default off; byte-identical
   payloads proven; parity green in BOTH modes). Second increment DONE 2026-08-19: run-history spilling
   (SpillingHistory, list-identical semantics with random access;
   env STATIC_ADAPT_RUN_HISTORY_SPILL_DIR; wired on both the legacy
   flow and the typed session cursor; S_alg/measurement accounting
   reads the complete record live during the run and deterministically
   from the spill after it, per user constraint; beam rebinding
   reverts to RAM by construction). Remaining diet item: the deep-run
   segmenting playbook (docs + submit templates). Original
   scope: stream
   ledgers/telemetry to disk instead of accumulating in RAM, lean on the
   existing segment controls + validated checkpoint continuation to
   split deep runs. This targets the user's actual pain (excessive
   storage/RAM on heavy CHTC jobs), which is a design problem, not a
   language problem.
3. Phase-rename campaign: align code symbol names with Paper 1's phase
   convention (implementation generations). GitNexus impact analysis
   before every rename (user instinct, correct — this is exactly where
   name-pattern tools failed us); recorded payload KEYS are provenance
   — code symbols rename freely, recorded keys get write-new/read-both
   compatibility.
4. Profile-then-decide on native kernels: bounded strong-sector segment
   under cProfile + ram_guard to split time between candidate-volume,
   NumPy kernels, and Python overhead. No C++ rewrite: hot loops are
   already BLAS; a narrow kernel (or worker parallelism across
   candidates with fixed-order deterministic reduction) only if the
   profile proves it. Parallel knobs already exist
   (adapt_parallel_gradient_workers, beam parent workers) — capped at 1
   locally by RAM policy; CHTC multi-core submits are the cheap
   wall-time lever.

### V3/V4 sheet EXECUTED (2026-08-19)

The activation flip is complete: new protocols emit sheet-2 schemas
(V3 legacy / V4 full-response); every route contract carries
cost_backend + cost_backend_selection (qiskit default; proxy only via
the explicit user_selected_speed flag on the execution policy);
sheet_version threads through the contract builder so historical
lineage/parent reconstructions stay sheet-1 byte-faithful; summary
authority accepts sheet-2 twins; resume accepts sheet-2 checkpoints.
Parity baselines intentionally re-recorded (sheet-2 protocol digests).
Battery: facade 67, mid-battery 203, integration at inherited 30,
parity re-recorded then green.

### V3 sheet execution state (2026-08-18, late — historical)

User approved the sheet field. Steps 1-2 LANDED behavior-neutral
(`6e06eb0a`, `579810e4`): two-axis schema space (semantics x sheet;
V3 = legacy+cost, V4 = full_response+cost) and ALL version-coupled
checks rewritten through the axis maps — zero V2-equality sites remain
in contracts.py; full facade + parity green. REMAINING (the activation
flip, one focused block): bundles emit sheet-2 for new protocols;
engine serializes cost_backend/cost_backend_selection into
execution_settings; user_selected_speed on the execution policy;
monolith audit key sets; facade test expectations; parity baseline
re-record (INTENTIONAL-CHANGE procedure per the blueprint); full
battery including integration at inherited baseline.

**Resolved user gate (historical):** stamping the cost-backend declaration into
run records requires the request-level speed switch on the typed RA
surface, which touches protocol/route-contract schemas (provenance
digests). Do not add it without the user's explicit sign-off on the
schema change.

# Stage 2 — Verification Findings (2026-08-18, historical)

Branch: `ra-refactor-stage2` (worktree). Parity guard:
`test/test_ra_adapt_refactor_parity.py`, green at baseline `9f55e696`.
No code moved yet; this note records the evidence pass that scopes the
retirement the user approved on 2026-08-17.

## Already done (by the 2026-07-27 retirement)

- TETRIS / qubit-ADAPT static executables are retired to
  `archive/paper_i_static_adapt_legacy_20260727/` (hash-locked), with
  `test/test_ra_adapt_retired_reachability.py` enforcing unreachability
  (`static_tetris_qubit_adapt_vqe`, `tetris_disjoint_benchmark`).
- `qeb_adapt` / `hea_adapt`: zero executable references remain anywhere
  in `pipelines/static_adapt/` (only the declarative
  `legacy_algorithm_ids` tuple in `paper_i_config.py`).
- `route_b`: zero occurrences in `adapt_pipeline.py`. Route B's
  executable surface appears already gone.

## Name collisions — do NOT touch

- `uccsd_qeb` / `uccsd_qeb_hva_blocks` are LIVE canonical Hubbard
  physical-lane pools (`lane_routes.py`
  `route_a_hubbard_physical_operator_lanes_v3_uccsd_qeb_hva_blocks`,
  prelaunch audits in `adapt_pipeline.py` ~18804). Same letters as the
  retired QEB-ADAPT method; entirely different object.
- "Plateau" is partly CANONICAL: the current singleton route uses
  plateau-triggered commutation-reduced insertion
  (`PlateauCommutationInsertion`, `RA_ADAPT_PHASE3_POPULATION_*`
  contracts). Route C "plateau acquisition" is the retired concept.
  Every `route_c`/plateau occurrence must be classified
  canonical-insertion vs legacy-acquisition before movement.

## Actual remaining stage-2 work

Route C excision: 511 `route_c` occurrences in `adapt_pipeline.py`,
plus dedicated files `route_c_plateau.py`, `plateau_acquisition.py`,
and route_c references in ~13 support modules (checkpoint/telemetry,
resume scaffold, phase shortlists, scoring types). Many are
compatibility payload fields, not executable branches.

Next step: classify the 511 occurrences (executable branch vs
compat-payload vs telemetry) with the same evidence discipline as this
pass; excise executable Route C into the inert-archive pattern;
payload/telemetry fields need a compatibility decision per field.

### Increment 1 executed (2026-08-18): gate welded shut

`_run_hardcoded_adapt_vqe` now raises RuntimeError if
`phase3_plateau_acquisition_mode` normalizes to anything but OFF —
Route C is fail-closed retired at the config boundary. Verification:
parity suite + scoring + historical-identity tests, 186 passed.

Two findings recorded during verification:

1. **Pre-existing integration failures, not caused by stage 2.**
   `test_adapt_vqe_integration.py` has 30 failures (fixed-count sector
   contract violations in beam candidate scoring) that reproduce
   identically with the weld stashed. They were inherited from the
   shared-checkout state captured at checkpoint `ba7f2ac9` — another
   campaign's in-flight conversion. Stage 2's guard is the parity suite
   (green); the inherited failures belong to that other campaign and
   must not be "fixed" as part of this refactor.
2. **GitNexus `analyze` injected instruction blocks into `AGENTS.md`
   and `CLAUDE.md`** (`<!-- gitnexus:start -->`), despite the icm plan's
   prohibition — even without running `setup`. Reverted; `.gitnexus/`
   added to `.gitignore`; the main checkout was not affected. Future
   GitNexus runs must be followed by a control-surface diff check.

### GitNexus pilot verdict (2026-08-18, index-only per icm plan)

Graph (96,853 nodes, monolith included after raising
`GITNEXUS_MAX_FILE_SIZE`) marks `plateau_score_formula` upstream-HIGH:
`_run_hardcoded_adapt_vqe` reaches it. Source verification resolves the
lead: the call sites sit behind
`phase3_plateau_acquisition_mode: str = PLATEAU_ACQUISITION_MODE_OFF`
(adapt_pipeline.py:15199, gate applied ~17024), and the RA facade
(`ra_adapt/engine.py`, `contracts.py`) contains ZERO references to
`plateau_acquisition` — the canonical path cannot express turning it
on. Route C is gated-dead from `run_ra_adapt`: excision of the gate
parameter, gated branches, and both modules is provable by the existing
parity baselines (which run with the default OFF gate). Checkpoint
payload fields recording the mode string need per-field compat
decisions for old-resume validation.

## Stage-3 design decisions (user, 2026-08-18)

1. **Problem construction out of the RA file.** Reference state and
   Hamiltonian construction are problem-specific (and often already
   computed); the RA algorithm file describes what a run *does*. The
   route runner consumes a resolved problem; it never builds one.
2. **Hardware cost split into two callable backends in separate
   files:** real Qiskit transpilation cost, and the fast structural
   proxy. They are effectively different routes. Default is Qiskit;
   the proxy is used only when the user explicitly selects speed in
   the interface. Selection is a request-level switch, never implicit.
3. (Earlier, same day) Append-only insertion becomes a true
   algorithmic specialization of the always-insertion canonical route;
   algorithmic metadata stays strictly separated from reporting.
4. **Top-down energy model (user, 2026-08-18):** one central object —
   the Phase-III energy model plus the initial record set. Phases 0–II
   are formulated as limiting instances (restrictions) of the Phase-III
   model; the phase funnel restricts the record set (adaptive
   shortlists are run-state restriction traces, since restriction
   happens during the run). Pool construction, Hamiltonian builder, and
   exact reference move fully out of the algorithm file — the algorithm
   no longer mutates generators/operators (historically it did), so
   pool initialization is separable; only record-set restriction stays
   in-run. The model objects carry the metadata needed for S_alg,
   Qiskit cost, and record-set size. This unifies with the
   append-as-specialization directive: comparators, phases, and
   shortlists are all restrictions of one canonical object.

## Deliberately out of scope pending user confirmation

HEA as a *benchmark baseline* (`pipelines/exact_bench/qiskit_hea_adapter.py`,
`hh_conventional_vqe.py`) is referenced by generic benchmark suites and
table-lock tests that appear Paper-II-adjacent (AVQDS/dynamics tables).
The user's retirement approval was Paper-I-scoped; these baselines stay
until the user confirms the dynamics tables no longer need them.
