"""Qiskit cost backend (delegating skeleton) — THE default.

User directive (2026-08-18): real Qiskit transpilation cost is always
used unless the user explicitly selects speed in the interface. This
module is the callable home of the Qiskit side; it delegates to the
existing backend-compile oracle machinery
(`pipelines/static_adapt/hh_backend_compile_oracle.py`). The oracle
construction itself still happens in the run engine; moving it behind
this interface is a later increment.
"""

from __future__ import annotations

from pipelines.static_adapt.hh_backend_compile_oracle import (
    backend_compile_scope_uses_qiskit_for_stage,
)

BACKEND_NAME = "qiskit_transpilation_v1"


def owns_stage(scope: str, stage: str) -> bool:
    """Whether the Qiskit oracle owns cost evaluation for this stage."""
    return bool(backend_compile_scope_uses_qiskit_for_stage(scope, stage))


def declaration() -> dict[str, str]:
    """The declared-cost-backend payload for run records."""
    return {
        "cost_backend": BACKEND_NAME,
        "cost_backend_basis": "transpiled_two_qubit_gate_deltas",
    }
