"""Cost-backend selection: Qiskit always, proxy only on explicit speed choice.

The two backends are effectively different routes (user, 2026-08-18).
Selection is a request-level switch and can never happen implicitly:
constructing the proxy selection without the explicit speed flag is a
fail-closed error, and every selection emits a declaration payload so
run records state which cost basis produced them.
"""

from __future__ import annotations

from dataclasses import dataclass

from pipelines.static_adapt.energy_model import proxy_cost, qiskit_cost

COST_BACKEND_QISKIT = qiskit_cost.BACKEND_NAME
COST_BACKEND_PROXY = proxy_cost.BACKEND_NAME


@dataclass(frozen=True)
class CostBackendSelection:
    backend: str
    user_selected_speed: bool

    def __post_init__(self) -> None:
        if self.backend not in (COST_BACKEND_QISKIT, COST_BACKEND_PROXY):
            raise ValueError(
                f"Unknown cost backend {self.backend!r}; valid: "
                f"{COST_BACKEND_QISKIT!r}, {COST_BACKEND_PROXY!r}."
            )
        if self.backend == COST_BACKEND_PROXY and not self.user_selected_speed:
            raise ValueError(
                "The structural proxy cost backend requires the user's "
                "explicit speed selection; it is never an implicit default "
                "(user directive 2026-08-18)."
            )

    def declaration(self) -> dict[str, str]:
        payload = (
            proxy_cost.declaration()
            if self.backend == COST_BACKEND_PROXY
            else qiskit_cost.declaration()
        )
        return {
            **payload,
            "cost_backend_selection": (
                "user_explicit_speed_choice"
                if self.user_selected_speed
                else "default"
            ),
        }


def resolve_cost_backend(*, user_selected_speed: bool = False) -> CostBackendSelection:
    """The single entry point: Qiskit unless the user explicitly chose speed."""
    if user_selected_speed:
        return CostBackendSelection(
            backend=COST_BACKEND_PROXY, user_selected_speed=True
        )
    return CostBackendSelection(
        backend=COST_BACKEND_QISKIT, user_selected_speed=False
    )
