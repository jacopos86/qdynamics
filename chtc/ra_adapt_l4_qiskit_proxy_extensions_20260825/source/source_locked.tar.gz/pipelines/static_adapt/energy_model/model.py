"""Phase-III energy model, record set, and named restrictions (skeleton).

Increment one of stage 3: these objects define the shape every later
extraction lands in. All evaluation DELEGATES to the existing canonical
implementation in ``pipelines/scaffold/hh_continuation_scoring.py`` —
`test/test_energy_model_skeleton.py` proves the delegation is exact.

Score convention (user, 2026-08-18): the canonical Phase-III primary
score is S3 = DeltaE_TR / K3, where K3 as defined in Paper 1 already
incorporates the unit floor — the implementation's cheap-burden helper
returns that full denominator directly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from pipelines.scaffold.hh_continuation_scoring import (
    CandidateFeatures,
    FullScoreConfig,
)
from pipelines.static_adapt.energy_model.phases import (
    phase3_canonical_score_components,
)

RESTRICTION_KIND_MODEL_LIMIT = "model_limiting_instance_v1"
RESTRICTION_KIND_RECORD_SET = "record_set_restriction_v1"


@dataclass(frozen=True)
class Restriction:
    """A named restriction of the canonical object.

    Everything that is not the full Phase-III evaluation over the full
    record set is one of these: a cheaper limiting instance of the
    energy model, or a shrinking of the record set. Comparators (append
    as the end-position-restricted insertion case) follow the same
    concept.
    """

    name: str
    kind: str
    description: str


PHASE_RESTRICTIONS: tuple[Restriction, ...] = (
    Restriction(
        name="phase0_gradient_ranking",
        kind=RESTRICTION_KIND_MODEL_LIMIT,
        description=(
            "Rank by the standard ADAPT commutator gradient — the "
            "first-order limiting instance of the Phase-III energy model."
        ),
    ),
    Restriction(
        name="shortlist_record_restriction",
        kind=RESTRICTION_KIND_RECORD_SET,
        description=(
            "Retain only shortlist survivors for expensive evaluation; "
            "adaptive shortlists are the in-run trace of this restriction. "
            "Phase numbers name implementation generations (version-control "
            "stages, user convention): earlier-generation scorers are "
            "limiting instances of the Phase-III model, not steps of a "
            "fixed per-round pipeline."
        ),
    ),
    Restriction(
        name="append_only_insertion",
        kind=RESTRICTION_KIND_RECORD_SET,
        description=(
            "Restrict candidate records to end-position insertions — the "
            "intended true algorithmic specialization behind the "
            "Append-ADAPT comparator (stage-3 work item)."
        ),
    ),
)


@dataclass(frozen=True)
class RecordSet:
    """The candidate record set, with an explicit restriction trace.

    Restriction happens DURING a run (this is the complexity the user
    flagged): the initial set is built once outside the algorithm, and
    every in-run shrinking returns a new RecordSet carrying its lineage,
    so record-set size is always available as model metadata.
    """

    labels: tuple[str, ...]
    restriction_trace: tuple[tuple[str, int, int], ...] = field(
        default_factory=tuple
    )

    @property
    def size(self) -> int:
        return len(self.labels)

    def restrict(self, restriction_name: str, keep: Sequence[str]) -> "RecordSet":
        keep_set = set(keep)
        unknown = keep_set.difference(self.labels)
        if unknown:
            raise ValueError(
                "RecordSet restriction may only keep existing records; "
                f"unknown: {sorted(unknown)[:5]}"
            )
        kept = tuple(label for label in self.labels if label in keep_set)
        trace = self.restriction_trace + (
            (str(restriction_name), self.size, len(kept)),
        )
        return RecordSet(labels=kept, restriction_trace=trace)


@dataclass(frozen=True)
class Phase3EnergyModel:
    """The canonical Phase-III energy model (delegating skeleton).

    Owns evaluation of the canonical score S3 = DeltaE_TR / K3 for one
    candidate's features under one score configuration. Later increments
    move the cost backends (Qiskit default, proxy on explicit speed
    choice) and the phase limiting-instances behind this interface.
    """

    score_config: FullScoreConfig
    problem_identity: str = "hh_L2"

    def score_components(self, feat: CandidateFeatures) -> Mapping[str, Any]:
        """Exact delegation to the canonical Phase-III component scorer."""
        return phase3_canonical_score_components(feat, self.score_config)

    def s3_primary(self, feat: CandidateFeatures) -> float:
        return float(self.score_components(feat)["phase3_primary_score"])
