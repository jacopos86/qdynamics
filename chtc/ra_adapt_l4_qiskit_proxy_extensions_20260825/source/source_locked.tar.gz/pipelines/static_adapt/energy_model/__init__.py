"""Top-down energy model: the central object of the stage-3 refactor.

User directives (2026-08-18, recorded in
pipelines/static_adapt/ra_refactor_stage2_status_20260818.md):

- ONE central object: the Phase-III energy model plus the initial record
  set. Phases 0-II are limiting instances (restrictions) of the
  Phase-III model; the phase funnel restricts the record set; adaptive
  shortlists are in-run restriction traces.
- The model objects carry the metadata needed for S_alg accounting,
  Qiskit cost, and record-set size.
- Hardware cost resolves through exactly two callable backends — real
  Qiskit transpilation cost (always the default) and the structural
  proxy (only on an explicit user speed choice) — arriving in increment
  two of stage 3.

This package is a strangler-pattern shell: it DELEGATES to the existing
scoring implementation and changes no behavior. Extraction moves code in
here increment by increment, parity-proven at each step.
"""

from pipelines.static_adapt.energy_model.model import (
    PHASE_RESTRICTIONS,
    Phase3EnergyModel,
    RecordSet,
    Restriction,
)

__all__ = [
    "PHASE_RESTRICTIONS",
    "Phase3EnergyModel",
    "RecordSet",
    "Restriction",
]
