"""Phase evaluators of the canonical energy model (relocated 2026-08-18).

Phases 0 and 2 are limiting instances of the Phase-III model; Phase III
is the model's full evaluation (S3 = DeltaE_TR / K3; the unit floor is
part of K3 per Paper 1). Bodies moved verbatim from
pipelines/scaffold/hh_continuation_scoring.py, which keeps lazy
compatibility wrappers; supporting primitives still live there and are
imported explicitly below (they migrate in later increments).
"""

from __future__ import annotations

from pipelines.scaffold.hh_continuation_scoring import (
    Any,
    CandidateFeatures,
    FullScoreConfig,
    GRAM_NOVELTY_POLICY_FALLBACK_ONLY_V1,
    GRAM_NOVELTY_STATUS_NOT_COMPUTED_FOR_ORDINARY_SCORING,
    ORDINARY_NOVELTY_SCORING_RETIRED_V1,
    PHASE2_CHEAP_CURVATURE_PROXY_POLICY_LEGACY_LAMBDA_F_RATIO_V1,
    PHASE2_CHEAP_CURVATURE_PROXY_POLICY_OFF,
    PHASE2_CURVATURE_POLICY_LEGACY_OPTIONAL_V1,
    PHASE2_CURVATURE_POLICY_MEASURED_REQUIRED_FAIL_CLOSED_V1,
    PHASE2_NO_NOVELTY_RAW_SCORE_FORMULA,
    PHASE2_NO_NOVELTY_UNIT_GAIN_RAW_SCORE_FORMULA,
    PHASE2_SELECTOR_GAIN_UNIT_GAIN_V1,
    PHASE3_AUXILIARY_SCORE_TIE_BREAK_ONLY,
    PHASE3_CANONICAL_SCORE_FORMULA,
    Phase2CurvatureConstructionError,
    Sequence,
    _deferred_gram_fallback_enabled,
    _feature_curvature_or_legacy_lambda_f_proxy,
    _feature_phase3_schur_window,
    _gradient_resolution_components,
    _hardware_cost_denominator_payload,
    _phase3_auxiliary_tie_break_components,
    _phase3_window_relaxation_disabled,
    _phase_confidence_factor,
    _selector_gradient_lcb,
    _selector_gradient_resolution,
    math,
    normalize_phase2_cheap_curvature_proxy_policy,
    normalize_phase2_curvature_policy,
    normalize_phase2_selector_gain_mode,
    normalize_phase3_auxiliary_score_mode,
    np,
    trust_region_drop,
    validate_phase2_feature_curvature,
)


def phase0_raw_gradient_pilot_components(
    *,
    gradient_signed: float,
    sigma_hat: float | None,
    alpha0: float,
    z_alpha: float,
    hardware_resolution_mode: str,
    manual_b_g_hw: float,
    manual_b_g_drift: float,
) -> dict[str, float | str | bool | None]:
    """Return weak Phase-0 raw-gradient upper-confidence pilot telemetry.

    Unit 1A selector math uses the lower-confidence ``g_hw_lcb``.  The Phase 0
    pilot is intentionally permissive and uses the upper confidence value
    ``|g0_hat| + (z_alpha*sigma0 + b_g_hw + b_g_drift)`` as a one-sided keep
    screen before expensive Phase 1 feature construction.
    """

    gradient_value = float(gradient_signed)
    if not math.isfinite(gradient_value):
        raise ValueError("phase0 gradient_signed must be finite.")
    alpha_value = float(alpha0)
    if (not math.isfinite(alpha_value)) or alpha_value <= 0.0:
        raise ValueError("phase0 alpha0 must be finite and > 0.")
    z_value = float(z_alpha)
    if (not math.isfinite(z_value)) or z_value < 0.0:
        raise ValueError("phase0 z_alpha must be finite and nonnegative.")

    sigma_available = sigma_hat is not None
    if sigma_available:
        try:
            sigma_value = float(sigma_hat)
        except (TypeError, ValueError):
            sigma_available = False
            sigma_value = 0.0
        else:
            if (not math.isfinite(sigma_value)) or sigma_value < 0.0:
                sigma_available = False
                sigma_value = 0.0
    else:
        sigma_value = 0.0

    g_abs = float(abs(gradient_value))
    resolution = _gradient_resolution_components(
        g_abs=float(g_abs),
        sigma_hat=float(sigma_value),
        z_alpha=float(z_value),
        hardware_resolution_mode=str(hardware_resolution_mode),
        manual_b_g_hw=float(manual_b_g_hw),
        manual_b_g_drift=float(manual_b_g_drift),
    )
    epsilon_g_res = float(resolution["epsilon_g_res"])
    g_upper_hw = float(g_abs + epsilon_g_res)
    return {
        "phase0_pilot_schema": "phase0_raw_gradient_upper_v1",
        "phase0_raw_gradient_signed": float(gradient_value),
        "phase0_raw_gradient_abs": float(g_abs),
        "phase0_sigma_hat": float(sigma_value),
        "phase0_sigma_hat_available": bool(sigma_available),
        "phase0_epsilon_g_shot": float(resolution["epsilon_g_shot"]),
        "phase0_b_g_hw": float(resolution["b_g_hw"]),
        "phase0_b_g_drift": float(resolution["b_g_drift"]),
        "phase0_epsilon_g_res": float(epsilon_g_res),
        "phase0_g_upper_hw": float(g_upper_hw),
        "phase0_delta_e_upper_hw": float(alpha_value * g_upper_hw),
        "phase0_alpha": float(alpha_value),
        "phase0_hardware_resolution_mode": str(resolution["hardware_resolution_mode"]),
        "phase0_hardware_resolution_source": str(resolution["hardware_resolution_source"]),
    }


def phase2_raw_geometry_score(
    feat: CandidateFeatures,
    *,
    F_raw: float,
    h_raw: float,
    q_window: Sequence[float],
    Q_window: np.ndarray,
    cfg: FullScoreConfig,
) -> dict[str, Any]:
    """Score Phase II from response gain and cost, without ordinary novelty.

    The Gram cross-block inputs remain in the call contract because the same
    exact geometry is reused by insertion, supported response, and the
    deferred all-models-infeasible fallback.  They are not ranking inputs.
    """

    del q_window, Q_window
    curvature_policy = normalize_phase2_curvature_policy(
        getattr(
            cfg,
            "phase2_curvature_policy",
            PHASE2_CURVATURE_POLICY_LEGACY_OPTIONAL_V1,
        )
    )
    cheap_curvature_proxy_policy = (
        normalize_phase2_cheap_curvature_proxy_policy(
            getattr(
                cfg,
                "phase2_cheap_curvature_proxy_policy",
                PHASE2_CHEAP_CURVATURE_PROXY_POLICY_LEGACY_LAMBDA_F_RATIO_V1,
            )
        )
    )
    if (
        curvature_policy
        == PHASE2_CURVATURE_POLICY_MEASURED_REQUIRED_FAIL_CLOSED_V1
    ):
        try:
            h_raw = float(h_raw)
        except (TypeError, ValueError) as exc:
            raise Phase2CurvatureConstructionError(
                "RA-ADAPT Phase-II measured-required curvature is malformed."
            ) from exc
        if not math.isfinite(float(h_raw)):
            raise Phase2CurvatureConstructionError(
                "RA-ADAPT Phase-II measured-required curvature is nonfinite."
            )
        if (
            cheap_curvature_proxy_policy
            != PHASE2_CHEAP_CURVATURE_PROXY_POLICY_OFF
        ):
            raise Phase2CurvatureConstructionError(
                "RA-ADAPT Phase-II measured-required curvature cannot be "
                "paired with a lambda-F cheap proxy."
            )

    gain_mode = normalize_phase2_selector_gain_mode(
        getattr(cfg, "phase2_selector_gain_mode", None)
    )
    metric_floor = float(max(float(cfg.metric_floor), 0.0))
    F_raw_nonnegative = float(max(0.0, float(F_raw)))
    F_for_gain = (
        F_raw_nonnegative
        if curvature_policy
        == PHASE2_CURVATURE_POLICY_MEASURED_REQUIRED_FAIL_CLOSED_V1
        else float(max(F_raw_nonnegative, metric_floor))
    )
    confidence = _phase_confidence_factor(
        float(feat.g_abs),
        float(feat.sigma_hat),
        z_alpha=float(cfg.z_alpha),
    )
    g_hw_lcb = float(_selector_gradient_lcb(feat, cfg))
    trust_region_gain = float(
        trust_region_drop(
            g_hw_lcb,
            float(max(0.0, h_raw)),
            F_for_gain,
            float(cfg.rho),
        )
    )
    score_gain = (
        1.0
        if gain_mode == PHASE2_SELECTOR_GAIN_UNIT_GAIN_V1
        else float(trust_region_gain)
    )
    hardware_payload = _hardware_cost_denominator_payload(feat, cfg)
    burden_total = float(hardware_payload["hardware_cost_denominator"])
    cost_factor = float(hardware_payload["hardware_cost_score_factor"])
    score = float(
        score_gain
        * cost_factor
        / max(burden_total, float(cfg.cheap_score_eps))
    )
    return {
        "phase2_curvature_policy": str(curvature_policy),
        "phase2_cheap_curvature_proxy_policy": str(
            cheap_curvature_proxy_policy
        ),
        "phase2_lambda_f_proxy_applied": False,
        "phase2_missing_curvature_fallback_used": False,
        "confidence_factor": float(confidence),
        "phase2_raw_overlap_max": None,
        "phase2_raw_novelty": None,
        "phase2_measured_novelty": None,
        "phase2_novelty_multiplier": None,
        "phase2_novelty_multiplier_policy": (
            ORDINARY_NOVELTY_SCORING_RETIRED_V1
        ),
        "phase2_gram_novelty_policy": (
            GRAM_NOVELTY_POLICY_FALLBACK_ONLY_V1
            if _deferred_gram_fallback_enabled(cfg)
            else "off"
        ),
        "phase2_novelty_status": (
            GRAM_NOVELTY_STATUS_NOT_COMPUTED_FOR_ORDINARY_SCORING
        ),
        "phase2_novelty_query_charge": 0,
        "phase2_novelty_classical_solve_count": 0,
        "phase2_novelty_applied": False,
        "phase2_novelty_mode": ORDINARY_NOVELTY_SCORING_RETIRED_V1,
        "phase2_novelty_source": ORDINARY_NOVELTY_SCORING_RETIRED_V1,
        "phase2_novelty_fallback_reason": None,
        "phase2_span_projection_z": None,
        "phase2_novelty_ridge_used": None,
        "phase2_raw_F_effective": float(F_for_gain),
        "phase2_legacy_pairwise_novelty": None,
        "phase2_confidence_applied": False,
        "phase2_selector_gain_mode": str(gain_mode),
        "phase2_raw_score_formula": str(
            PHASE2_NO_NOVELTY_UNIT_GAIN_RAW_SCORE_FORMULA
            if gain_mode == PHASE2_SELECTOR_GAIN_UNIT_GAIN_V1
            else PHASE2_NO_NOVELTY_RAW_SCORE_FORMULA
        ),
        "phase2_trust_region_gain": float(trust_region_gain),
        "phase2_raw_trust_gain": float(score_gain),
        "phase2_g_hw_lcb": float(g_hw_lcb),
        "phase2_burden_total": float(burden_total),
        "hardware_cost_policy": str(
            hardware_payload["hardware_cost_policy"]
        ),
        "hardware_cost_signed_index": float(
            hardware_payload["hardware_cost_signed_index"]
        ),
        "hardware_cost_score_factor": float(cost_factor),
        "hardware_cost_population_hash": hardware_payload[
            "hardware_cost_population_hash"
        ],
        "phase2_raw_score": float(score),
    }


def phase3_canonical_score_components(
    feat: CandidateFeatures,
    cfg: FullScoreConfig,
) -> dict[str, Any]:
    """Return canonical Phase3 primary-score components for a candidate.

    Canonical static Phase3 scoring is physics-first:

        S3_primary = DeltaE_TR / (1 + K3)

    In this repo ``_cheap_burden_total()`` already returns the full
    ``1 + K3`` denominator, so this helper never adds another leading one.
    Ordinary novelty multipliers and their gamma schedules are retired.
    Auxiliary motif/duplicate terms are reported separately and only affect the
    returned selector score when ``auxiliary_score_mode='ablation_additive'``.
    """
    curvature_policy = normalize_phase2_curvature_policy(
        getattr(
            cfg,
            "phase2_curvature_policy",
            PHASE2_CURVATURE_POLICY_LEGACY_OPTIONAL_V1,
        )
    )
    cheap_curvature_proxy_policy = normalize_phase2_cheap_curvature_proxy_policy(
        getattr(
            cfg,
            "phase2_cheap_curvature_proxy_policy",
            PHASE2_CHEAP_CURVATURE_PROXY_POLICY_LEGACY_LAMBDA_F_RATIO_V1,
        )
    )
    validated_phase2_curvature: float | None = None
    if curvature_policy == PHASE2_CURVATURE_POLICY_MEASURED_REQUIRED_FAIL_CLOSED_V1:
        validated_phase2_curvature = validate_phase2_feature_curvature(feat, cfg)
    auxiliary_mode = normalize_phase3_auxiliary_score_mode(
        getattr(cfg, "auxiliary_score_mode", PHASE3_AUXILIARY_SCORE_TIE_BREAK_ONLY)
    )
    score_formula = PHASE3_CANONICAL_SCORE_FORMULA
    tie_components = _phase3_auxiliary_tie_break_components(feat, cfg)
    hardware_payload = _hardware_cost_denominator_payload(feat, cfg)
    denominator = float(hardware_payload["hardware_cost_denominator"])
    cost_factor = float(hardware_payload["hardware_cost_score_factor"])
    confidence = _phase_confidence_factor(
        float(feat.g_abs),
        float(feat.sigma_hat),
        z_alpha=float(cfg.z_alpha),
    )
    gradient_resolution = _selector_gradient_resolution(feat, cfg)
    g_hw_lcb = float(gradient_resolution.get("g_hw_lcb", 0.0))
    base: dict[str, Any] = {
        "phase2_curvature_policy": str(curvature_policy),
        "phase2_cheap_curvature_proxy_policy": str(
            cheap_curvature_proxy_policy
        ),
        "phase2_validated_directional_curvature": (
            None
            if validated_phase2_curvature is None
            else float(validated_phase2_curvature)
        ),
        "phase2_lambda_f_proxy_applied": False,
        "phase2_missing_curvature_fallback_used": False,
        "canonical_score_formula": str(score_formula),
        "phase3_canonical_score_formula": str(score_formula),
        "auxiliary_score_mode": str(auxiliary_mode),
        "phase3_auxiliary_score_mode": str(auxiliary_mode),
        "confidence_factor": float(confidence),
        "phase3_confidence_factor": float(confidence),
        "delta_e_tr": 0.0,
        "DeltaE_TR": 0.0,
        "epsilon_g_shot": float(gradient_resolution.get("epsilon_g_shot", 0.0)),
        "b_g_hw": float(gradient_resolution.get("b_g_hw", 0.0)),
        "b_g_drift": float(gradient_resolution.get("b_g_drift", 0.0)),
        "epsilon_g_res": float(gradient_resolution.get("epsilon_g_res", 0.0)),
        "g_hw_lcb": float(g_hw_lcb),
        "g_lcb_legacy_shot": float(gradient_resolution.get("g_lcb_legacy_shot", 0.0)),
        "hardware_resolution_mode": str(gradient_resolution.get("hardware_resolution_mode", "ideal")),
        "hardware_resolution_source": str(gradient_resolution.get("hardware_resolution_source", "legacy_unset")),
        "N3": None,
        "n3": None,
        "phase3_measured_novelty": None,
        "phase3_novelty_multiplier": None,
        "phase3_novelty_multiplier_policy": (
            ORDINARY_NOVELTY_SCORING_RETIRED_V1
        ),
        "phase3_gram_novelty_policy": (
            GRAM_NOVELTY_POLICY_FALLBACK_ONLY_V1
            if _deferred_gram_fallback_enabled(cfg)
            else "off"
        ),
        "phase3_novelty_status": (
            GRAM_NOVELTY_STATUS_NOT_COMPUTED_FOR_ORDINARY_SCORING
        ),
        "phase3_novelty_query_charge": 0,
        "phase3_novelty_classical_solve_count": 0,
        "phase3_novelty_applied": False,
        "K3": float(denominator - 1.0),
        "k3": float(denominator - 1.0),
        "denominator_1_plus_K3": float(denominator),
        "phase3_denominator_1_plus_K3": float(denominator),
        "hardware_cost_excess_sum": float(hardware_payload["hardware_cost_excess_sum"]),
        "hardware_cost_denominator": float(denominator),
        "hardware_cost_lambda_2q": float(hardware_payload["lambdas"]["2q"]),
        "hardware_cost_lambda_d": float(hardware_payload["lambdas"]["d"]),
        "hardware_cost_lambda_1q": float(hardware_payload["lambdas"]["1q"]),
        "hardware_cost_lambda_theta": float(hardware_payload["lambdas"]["theta"]),
        "hardware_cost_lambda_shot": float(hardware_payload["lambdas"]["shot"]),
        "hardware_cost_lambda_source": str(hardware_payload["lambda_source"]),
        "hardware_cost_policy": str(hardware_payload["hardware_cost_policy"]),
        "hardware_cost_signed_index": float(
            hardware_payload["hardware_cost_signed_index"]
        ),
        "hardware_cost_score_factor": float(cost_factor),
        "hardware_cost_population_hash": hardware_payload[
            "hardware_cost_population_hash"
        ],
        "c_bar_2q": float(hardware_payload["bars"]["2q"]),
        "c_bar_d": float(hardware_payload["bars"]["d"]),
        "c_bar_1q": float(hardware_payload["bars"]["1q"]),
        "c_bar_theta": float(hardware_payload["bars"]["theta"]),
        "c_bar_shot": float(hardware_payload["bars"]["shot"]),
        "leakage_factor": 0.0,
        "phase3_leakage_factor": 0.0,
        "phase3_primary_score": 0.0,
        "primary_score": 0.0,
        "phase3_tie_break_score": float(tie_components["phase3_tie_break_score"]),
        "tie_break_score": float(tie_components["phase3_tie_break_score"]),
        "motif_tie_break_score": float(tie_components["motif_tie_break_score"]),
        "duplicate_tie_break_score": float(tie_components["duplicate_tie_break_score"]),
        "fallback_mode": "unknown",
        "eligible": False,
        "block_reason": None,
    }
    if (not bool(feat.stage_gate_open)) or (not bool(feat.leakage_gate_open)):
        return {
            **base,
            "phase3_primary_score": float("-inf"),
            "primary_score": float("-inf"),
            "fallback_mode": "blocked_stage_or_leakage_gate",
            "block_reason": "blocked_stage_or_leakage_gate",
        }
    if not bool(feat.compile_gate_open):
        return {
            **base,
            "phase3_primary_score": float("-inf"),
            "primary_score": float("-inf"),
            "fallback_mode": "compile_gate_closed",
            "block_reason": "compile_gate_closed",
        }
    if float(feat.leakage_penalty) > float(cfg.leakage_cap):
        return {
            **base,
            "phase3_primary_score": float("-inf"),
            "primary_score": float("-inf"),
            "fallback_mode": "leakage_cap",
            "block_reason": "leakage_cap",
        }

    if g_hw_lcb <= 0.0:
        return {
            **base,
            "fallback_mode": "nonpositive_gradient",
            "block_reason": "nonpositive_gradient",
        }

    window_relaxation_disabled = _phase3_window_relaxation_disabled(cfg)
    F_red_raw = (
        (feat.F_raw if feat.F_raw is not None else feat.F_metric)
        if window_relaxation_disabled
        else (feat.F_red if feat.F_red is not None else feat.F_raw)
    )
    if F_red_raw is None:
        if float(feat.F_metric) <= 0.0:
            return {
                **base,
                "fallback_mode": "nonpositive_metric",
                "block_reason": "nonpositive_metric",
            }
        F_red = float(max(float(feat.F_metric), float(cfg.metric_floor)))
        h_eff = float(
            max(
                0.0,
                _feature_curvature_or_legacy_lambda_f_proxy(
                    feat,
                    cfg,
                    legacy_metric=float(feat.F_metric),
                ),
            )
        )
        fallback_mode = "legacy_metric_path"
    else:
        h_eff = float(
            _feature_curvature_or_legacy_lambda_f_proxy(
                feat,
                cfg,
                legacy_metric=float(F_red_raw),
            )
            if window_relaxation_disabled
            else (
                feat.h_eff
                if feat.h_eff is not None
                else (feat.h_hat if feat.h_hat is not None else 0.0)
            )
        )
        F_red = float(max(float(F_red_raw), float(cfg.metric_floor)))
        metric_collapse = str(feat.curvature_mode).startswith("append_exact_metric_collapse")
        if metric_collapse and not window_relaxation_disabled:
            return {
                **base,
                "fallback_mode": "reduced_metric_collapse",
                "block_reason": "reduced_metric_collapse",
            }
        if window_relaxation_disabled:
            fallback_mode = "phase3_window_relaxation_disabled"
        else:
            fallback_mode = (
                "append_exact_reduced_path_ridge_grown"
                if feat.ridge_used is not None and float(feat.ridge_used) > float(max(cfg.lambda_H, 0.0))
                else (
                    "append_exact_empty_window"
                    if len(_feature_phase3_schur_window(feat)) == 0
                    else "append_exact_reduced_path"
                )
            )

    delta_e = float(trust_region_drop(g_hw_lcb, float(max(0.0, h_eff)), F_red, float(cfg.rho)))
    if delta_e <= 0.0:
        return {
            **base,
            "fallback_mode": str(fallback_mode),
            "block_reason": "nonpositive_delta_e_tr",
        }

    leakage_factor = float(math.exp(-float(cfg.eta_L) * float(feat.leakage_penalty)))
    primary_score = float(
        float(delta_e)
        * cost_factor
        / max(float(denominator), float(cfg.cheap_score_eps))
    )
    return {
        **base,
        "delta_e_tr": float(delta_e),
        "DeltaE_TR": float(delta_e),
        "g_hw_lcb": float(g_hw_lcb),
        "N3": None,
        "n3": None,
        "phase3_measured_novelty": None,
        "phase3_novelty_multiplier": None,
        "phase3_novelty_multiplier_policy": (
            ORDINARY_NOVELTY_SCORING_RETIRED_V1
        ),
        "phase3_gram_novelty_policy": (
            GRAM_NOVELTY_POLICY_FALLBACK_ONLY_V1
            if _deferred_gram_fallback_enabled(cfg)
            else "off"
        ),
        "phase3_novelty_status": (
            GRAM_NOVELTY_STATUS_NOT_COMPUTED_FOR_ORDINARY_SCORING
        ),
        "phase3_novelty_query_charge": 0,
        "phase3_novelty_classical_solve_count": 0,
        "phase3_novelty_applied": False,
        "leakage_factor": float(leakage_factor),
        "phase3_leakage_factor": float(leakage_factor),
        "phase3_primary_score": float(primary_score),
        "primary_score": float(primary_score),
        "fallback_mode": str(fallback_mode),
        "eligible": True,
        "block_reason": None,
    }
