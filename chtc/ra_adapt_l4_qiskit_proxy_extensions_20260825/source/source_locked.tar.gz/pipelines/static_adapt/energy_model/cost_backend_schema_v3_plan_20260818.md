# EXECUTED 2026-08-19 — see status doc. Historical blueprint below.

# Protocol Schema V3: the cost-backend field ("the sheet")

User decision 2026-08-18: add the cost-backend switch to the typed
request surface. "I don't care where the switch is located, just add it
to the sheet." Design settled; this is the execution blueprint for the
next session. Every step is mechanical; the one intentional-change
procedure (parity re-record) is called out.

## AMENDMENT (2026-08-18, found during execution step 1)

The existing checks enforce a biconditional: full-response algorithm id
<=> V2. "V3 unconditionally" would break it. The schema space is
two-axis: semantics tier (legacy | full_response) x sheet version
(1 | 2). Therefore FOUR schemas: V3 = legacy + cost field, V4 =
full_response + cost field. Constants and the two helpers
(`protocol_schema_semantics`, `protocol_schema_sheet_version`) are
ALREADY LANDED additively in contracts.py. Every remaining `== V2`
check rewrites as: semantics must match algorithm id;
materialization/result/route-contract versions pair by the full
(semantics, sheet) tuple. New protocols emit sheet 2 (V3 or V4 by
algorithm).

## Semantics

- New field on the resolved protocol / route contract:
  `cost_backend` (values: `qiskit_transpilation_v1` |
  `structural_proxy_v1`) plus `cost_backend_selection`
  (`default` | `user_explicit_speed_choice`), produced by
  `energy_model.selection.resolve_cost_backend` — which is already
  fail-closed (proxy requires the explicit speed flag).
- ALL newly resolved protocols emit schema V3 with the field (default
  qiskit). Historical V1/V2 contracts remain valid and untouched; the
  audit accepts them by their own schema ids.

## Sites (enumerated 2026-08-18)

1. `ra_adapt/contracts.py`
   - constants 54-78: add `RA_ADAPT_PROTOCOL_SCHEMA_V3`,
     `RA_ADAPT_ROUTE_CONTRACT_SCHEMA_V3`, `RA_ADAPT_RESULT_SCHEMA_V3`,
     `BUNDLE_PROTOCOL_MATERIALIZATION_SCHEMA_V3`; extend the VALID sets
     (line 61 and materialization set 709-710); export in `__all__`
     (1930-1962 region).
   - REPLACE the boolean version-coupling idiom: sites 734-746, 901-903,
     987, 1203, 1748 use `x == ..._V2` equivalence checks. Introduce
     `def protocol_schema_tier(schema) -> int` (V1->1, V2->2, V3->3;
     V3 uses the V2 materialization/result semantics plus the new
     field) and rewrite each check as tier comparison. Do NOT leave any
     `== V2` booleans behind — that idiom is why V3 touches 16 sites.
2. `ra_adapt/bundles.py` 646-649: schema derivation returns V3
   unconditionally for newly resolved protocols (the field exists on
   every new sheet; algorithm id no longer selects the schema, only the
   semantics tier).
3. `ra_adapt/engine.py` (4 sites): route-contract serialization adds
   `execution_settings["cost_backend"]` and
   `execution_settings["cost_backend_selection"]` from
   `resolve_cost_backend(user_selected_speed=<request field>)`;
   result schema V3.
4. Request surface: add `user_selected_speed: bool = False` to the
   execution policy (`SRExecutionPolicy` home) — NOT method policy: the
   user said the proxy exists so a run can be declared fast, which is
   execution semantics. Validation: field is a plain bool; the
   fail-closed rule stays in `energy_model/selection.py`.
5. Monolith contract audit (`expected_phase3_plateau_contract` region,
   `v2_execution_keys` set): add the V3 key set = V2 keys +
   {"cost_backend", "cost_backend_selection"}; select by schema id.
6. Tests:
   - facade "serializes exactly" tests: update expected schemas to V3
     and add the two fields to expected payloads.
   - parity baselines (`test/fixtures/ra_refactor_parity/*.json`):
     protocol sha256 changes are INTENTIONAL here. Delete both baseline
     files in the same commit as the schema change with the commit
     message stating the intentional-change justification; first run
     re-records; second run must pass. Never regenerate baselines in
     any other circumstance.
   - new test: V3 contract carries the declared fields; V1/V2 fixtures
     still validate; proxy declaration appears only with the explicit
     speed flag.
7. Regenerate the failure atlas afterward.

## Order

contracts constants -> tier helper + rewrites -> bundles derivation ->
engine serialization + request field -> monolith audit keys -> test
updates -> parity re-record -> full battery (scoring, model, cost,
facade, integration at inherited baseline, both reachability suites).
Commit per step; explicit paths only.
