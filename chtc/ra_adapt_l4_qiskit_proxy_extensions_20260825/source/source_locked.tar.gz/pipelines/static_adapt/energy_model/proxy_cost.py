"""Structural proxy cost backend (delegating skeleton) — explicit opt-in only.

User directive (2026-08-18): the proxy is used solely when the user
selects speed in the interface, so a published document can still
declare RA was used. Selection never happens implicitly — see
`energy_model.selection`. Delegates to the existing structural proxy
terms in `pipelines/scaffold/hh_continuation_scoring.py`.
"""

from __future__ import annotations

from typing import Any, Mapping

from pipelines.scaffold.hh_continuation_scoring import (
    FullScoreConfig,
    SimpleScoreConfig,
    _effective_compile_proxy_total,
    _effective_gate_proxy_total,
)

BACKEND_NAME = "structural_proxy_v1"


def gate_proxy_total(
    proxy_cost: Mapping[str, Any],
    cfg: SimpleScoreConfig | FullScoreConfig,
) -> float:
    """Exact delegation to the canonical structural gate-proxy total."""
    return float(_effective_gate_proxy_total(proxy_cost, cfg))


def compile_proxy_total(
    proxy_cost: Mapping[str, Any],
    cfg: SimpleScoreConfig | FullScoreConfig,
) -> float:
    """Exact delegation to the canonical structural compile-proxy total."""
    return float(_effective_compile_proxy_total(proxy_cost, cfg))


def declaration() -> dict[str, str]:
    """The declared-cost-backend payload for run records."""
    return {
        "cost_backend": BACKEND_NAME,
        "cost_backend_basis": "structural_gate_and_compile_proxies",
    }
