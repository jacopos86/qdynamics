"""Strict neutral contracts for exhaustive combinatorial-batch termination.

This module deliberately does not import the retired SNAKE route or the
Paper-I semantic-closure authority.  It authenticates the generic condition
that a fixed, generator-distinct ranked window was exhaustively searched and
every evaluated subset failed only the joint metric-rank gate.
"""

from __future__ import annotations

import hashlib
import itertools
import json
import math
from collections.abc import Mapping, Sequence
from typing import Any


COMBINATORIAL_BATCH_SUBSET_FEASIBILITY_POLICY = "joint_subset_gate_v1"
COMBINATORIAL_BATCH_EMPTY_FEASIBLE_SET_POLICY = (
    "typed_rank_gate_exhaustion_terminal_v1"
)
COMBINATORIAL_BATCH_PHASE3_POPULATION_AUTHORITY = (
    "full_phase2_population_full_response_supported_coordinates_v1"
)
COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTED_OUTCOME = (
    "combinatorial_batch_rank_gate_exhausted_v1"
)
COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTION_RECEIPT_SCHEMA = (
    "combinatorial_batch_rank_gate_exhaustion_terminal_v1"
)
COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTION_CHECKPOINT_KIND = (
    "terminal_combinatorial_batch_rank_gate_exhausted"
)
COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTION_STOP_REASON = (
    "combinatorial_batch_rank_gate_exhausted"
)
COMBINATORIAL_BATCH_TERMINAL_PHASE3_PROJECTION_SCHEMA = (
    "combinatorial_batch_terminal_phase3_projection_v1"
)

_TERMINAL_COMBINATORIAL_ROUTE_INVARIANTS = {
    "combinatorial_batch_phase3_population_authority": (
        COMBINATORIAL_BATCH_PHASE3_POPULATION_AUTHORITY
    ),
    "combinatorial_batch_enumeration": (
        "generator_distinct_subsets_not_permutations_v1"
    ),
    "combinatorial_batch_search_population": "ranked_phase3_candidates_v1",
    "combinatorial_batch_search_window_semantics": (
        "ranked_phase3_prefix_cardinality_v1"
    ),
    "combinatorial_batch_record_semantics": (
        "fixed_generator_plus_insertion_position_v1"
    ),
    "combinatorial_batch_joint_response_coordinate_scope": (
        "full_active_plus_ordered_batch_v1"
    ),
    "combinatorial_batch_internal_order": (
        "ranked_child_phase2_within_fixed_phase3_membership_v1"
    ),
    "combinatorial_batch_rank_tie_break": (
        "phase2_then_phase1_then_generator_support_then_route_identity_v1"
    ),
}


def canonical_json_copy(value: Any) -> Any:
    """Return a finite, JSON-isolated canonical copy."""

    return json.loads(
        json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        )
    )


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(
            value,
            allow_nan=False,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    ).hexdigest()


def combinatorial_candidate_record_id(
    *,
    domain_record_id: str,
    generator_id: str,
) -> str:
    """Identify one ranked child without collapsing siblings to their parent."""

    domain = str(domain_record_id)
    generator = str(generator_id)
    if not domain or not generator:
        raise ValueError(
            "combinatorial candidate identity requires domain and generator ids"
        )
    return "candidate-position:" + canonical_sha256(
        {
            "domain_record_id": domain,
            "generator_id": generator,
        }
    )


def _integer_count_map(value: Any, *, name: str) -> dict[str, int]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{name} must be a mapping")
    result: dict[str, int] = {}
    for raw_size, raw_count in value.items():
        if isinstance(raw_count, bool) or not isinstance(raw_count, int):
            raise ValueError(f"{name} counts must be integers")
        size = int(raw_size)
        if size < 1 or str(size) != str(raw_size):
            raise ValueError(f"{name} cardinalities must be positive integers")
        if int(raw_count) < 0:
            raise ValueError(f"{name} counts must be nonnegative")
        result[str(size)] = int(raw_count)
    return dict(sorted(result.items(), key=lambda item: int(item[0])))


def validate_rank_gate_exhaustion_summary(
    summary: Mapping[str, Any],
    *,
    maximum_size: int,
    search_window_size: int | None,
) -> dict[str, Any]:
    """Validate and isolate one complete no-feasible-subset search summary."""

    if not isinstance(summary, Mapping):
        raise TypeError("combinatorial exhaustion summary must be a mapping")
    maximum = int(maximum_size)
    if isinstance(maximum_size, bool) or not 1 <= maximum <= 5:
        raise ValueError("maximum_size must lie in 1..5")
    if search_window_size is not None and (
        isinstance(search_window_size, bool) or int(search_window_size) < 1
    ):
        raise ValueError("search_window_size must be positive or None")

    payload = canonical_json_copy(dict(summary))
    ranked_population_count = int(payload.get("ranked_population_count", 0))
    ranked_window_count = int(payload.get("ranked_window_count", 0))
    expected_window_count = (
        ranked_population_count
        if search_window_size is None
        else min(ranked_population_count, int(search_window_size))
    )
    if ranked_population_count < 1 or ranked_window_count != expected_window_count:
        raise ValueError(
            "rank-gate exhaustion requires a nonempty resolved ranked window"
        )
    if (
        payload.get("selection_mode") != "combinatorial_reduced_plane"
        or payload.get("selected") is not False
        or int(payload.get("selected_count", -1)) != 0
        or int(payload.get("proposal_count", -1)) != 0
        or payload.get("reason") != "no_feasible_subset"
        or payload.get("rank_gate_application_stage")
        != "joint_subset_after_search_pool"
        or int(payload.get("rank_prefilter_rejection_count", -1)) != 0
    ):
        raise ValueError(
            "rank-gate exhaustion requires an empty post-Phase-III proposal set"
        )
    prefilter = payload.get("rank_feasibility_prefilter")
    if not isinstance(prefilter, Mapping) or prefilter.get("active") is not False:
        raise ValueError(
            "rank-gate exhaustion cannot reuse a singleton rank prefilter"
        )

    cap = min(maximum, ranked_window_count)
    expected_counts = {
        str(size): math.comb(ranked_window_count, size)
        for size in range(1, cap + 1)
    }
    considered = _integer_count_map(
        payload.get("subset_counts_considered"),
        name="subset_counts_considered",
    )
    evaluated = _integer_count_map(
        payload.get("subset_counts_evaluated"),
        name="subset_counts_evaluated",
    )
    feasible = _integer_count_map(
        payload.get("subset_counts_feasible"),
        name="subset_counts_feasible",
    )
    if considered != expected_counts or evaluated != expected_counts or feasible:
        raise ValueError(
            "rank-gate exhaustion must evaluate every generator-distinct subset "
            "and find no feasible subset"
        )
    total = sum(expected_counts.values())
    query_chargeable_count = sum(
        count for size, count in expected_counts.items() if int(size) > 1
    )
    if (
        int(payload.get("candidate_batch_eval_count", -1)) != total
        or int(payload.get("subset_evaluation_count", -1)) != total
        or int(payload.get("same_generator_duplicate_skip_count", -1)) != 0
        or payload.get("same_generator_duplicate_identities") != []
        or payload.get("rejection_counts") != {"rank_gate": total}
        or int(payload.get("rank_gate_rejection_count", -1)) != total
        or int(payload.get("conditioning_gate_rejection_count", -1)) != 0
        or payload.get("public_search_window_size") != search_window_size
        or payload.get("batch_search_pool_size_requested")
        != (0 if search_window_size is None else int(search_window_size))
        or int(payload.get("batch_search_pool_size_effective", -1))
        != ranked_window_count
        or int(payload.get("search_pool_size", -1))
        != ranked_window_count
        or int(payload.get("query_chargeable_batch_subset_count", -1))
        != query_chargeable_count
        or int(
            payload.get("reused_child_phase2_singleton_subset_count", -1)
        )
        != expected_counts.get("1", 0)
        or payload.get("ranked_window_truncated")
        is not (ranked_window_count < ranked_population_count)
        or int(payload.get("effective_batch_size_cap", -1)) != cap
        or int(payload.get("effective_batch_target_size", -1)) != cap
        or payload.get("additivity_diagnostics")
        != payload.get("subset_diagnostics")
        or payload.get("geometry_mode")
        != "full_residual_gram_hessian_v1"
        or payload.get("additivity_policy") != "off"
        or not math.isfinite(float(payload.get("lambda_add", math.nan)))
        or float(payload.get("lambda_add", math.nan)) != 0.0
        or payload.get("near_degenerate_shell_active") is not False
        or int(payload.get("shell_size", -1)) != ranked_window_count
    ):
        raise ValueError(
            "rank-gate exhaustion accounting must close exclusively to rank_gate"
        )

    diagnostics = payload.get("subset_diagnostics")
    if not isinstance(diagnostics, list) or len(diagnostics) != total:
        raise ValueError("rank-gate exhaustion diagnostics do not close")
    expected_subsets = [
        tuple(indices)
        for size in range(1, cap + 1)
        for indices in itertools.combinations(range(ranked_window_count), size)
    ]
    observed_subsets: list[tuple[int, ...]] = []
    diagnostic_fields = {
        "cardinality",
        "eligible",
        "reason",
        "defect",
        "joint_gain",
        "singleton_gain_sum",
        "subset_workspace_indices",
        "gram_eigenvalues",
        "active_metric_eigenvalues",
        "active_metric_support_rank",
        "joint_metric_support_rank",
        "batch_metric_rank_increment",
        "required_batch_metric_rank_increment",
        "effective_rank",
        "rank_floor",
        "raw_gram_scale",
        "effective_gram_scale",
        "residual_to_raw_scale_ratio",
    }
    for row in diagnostics:
        if not isinstance(row, Mapping):
            raise ValueError("subset diagnostics must be mappings")
        indices = tuple(
            int(value)
            for value in row.get("subset_workspace_indices", ())
        )
        eigenvalues_raw = row.get("gram_eigenvalues")
        if not isinstance(eigenvalues_raw, list):
            raise ValueError("rank-gate diagnostic omitted Gram eigenvalues")
        eigenvalues = [float(value) for value in eigenvalues_raw]
        active_eigenvalues_raw = row.get("active_metric_eigenvalues")
        if not isinstance(active_eigenvalues_raw, list):
            raise ValueError(
                "rank-gate diagnostic omitted active-metric eigenvalues"
            )
        active_eigenvalues = [float(value) for value in active_eigenvalues_raw]
        rank_floor = float(row.get("rank_floor", math.nan))
        rank_field_names = (
            "active_metric_support_rank",
            "joint_metric_support_rank",
            "batch_metric_rank_increment",
            "required_batch_metric_rank_increment",
            "effective_rank",
        )
        rank_fields_raw = [row.get(name) for name in rank_field_names]
        if any(
            isinstance(value, bool) or not isinstance(value, int)
            for value in rank_fields_raw
        ):
            raise ValueError("rank-gate diagnostic rank fields are invalid")
        (
            active_rank,
            joint_rank,
            batch_rank_increment,
            required_rank_increment,
            effective_rank,
        ) = (int(value) for value in rank_fields_raw)
        numeric_diagnostics = [
            float(row.get(name, math.nan))
            for name in ("defect", "joint_gain", "singleton_gain_sum")
        ]
        optional_scales = [
            row.get(name)
            for name in (
                "raw_gram_scale",
                "effective_gram_scale",
                "residual_to_raw_scale_ratio",
            )
        ]
        if (
            set(row) != diagnostic_fields
            or row.get("eligible") is not False
            or row.get("reason") != "rank_gate"
            or int(row.get("cardinality", -1)) != len(indices)
            or len(set(indices)) != len(indices)
            or not math.isfinite(rank_floor)
            or rank_floor <= 0.0
            or any(not math.isfinite(value) for value in eigenvalues)
            or any(
                not math.isfinite(value) for value in active_eigenvalues
            )
            or len(eigenvalues) != len(active_eigenvalues) + len(indices)
            or any(not math.isfinite(value) for value in numeric_diagnostics)
            or any(
                value is not None
                and (
                    not math.isfinite(float(value))
                    or float(value) < 0.0
                )
                for value in optional_scales
            )
            or active_rank
            != sum(value > rank_floor for value in active_eigenvalues)
            or joint_rank
            != sum(value > rank_floor for value in eigenvalues)
            or joint_rank < active_rank
            or batch_rank_increment != joint_rank - active_rank
            or required_rank_increment != len(indices)
            or effective_rank != batch_rank_increment
            or effective_rank < 0
            or batch_rank_increment >= required_rank_increment
        ):
            raise ValueError("subset diagnostic is not an exact rank-gate rejection")
        observed_subsets.append(indices)
    if observed_subsets != expected_subsets:
        raise ValueError(
            "subset diagnostics do not enumerate the fixed ranked window exactly"
        )

    workspace = payload.get("geometry_workspace")
    if not isinstance(workspace, Mapping):
        raise ValueError("rank-gate exhaustion lost its geometry workspace")
    search_pool_records = workspace.get("search_pool_records")
    if (
        not isinstance(search_pool_records, list)
        or len(search_pool_records) != ranked_window_count
    ):
        raise ValueError("geometry workspace does not cover the ranked window")
    active_depth = int(workspace.get("active_ansatz_depth", -1))
    active_count = int(workspace.get("active_coordinate_count", -1))
    active_indices = workspace.get("active_indices")
    active_labels = workspace.get("active_labels")
    if (
        workspace.get("schema") != "batch_full_geometry_workspace_v1"
        or workspace.get("geometry_mode")
        != "full_residual_gram_hessian_v1"
        or workspace.get("geometry_mode") != payload.get("geometry_mode")
        or int(workspace.get("full_geometry_workspace_build_count", -1)) != 1
        or int(workspace.get("search_population_count", -1))
        != ranked_window_count
        or int(workspace.get("subset_cache_entry_count", -1)) != total
        or active_depth < 0
        or active_count != active_depth
        or not isinstance(active_indices, list)
        or active_indices != list(range(active_count))
        or not isinstance(active_labels, list)
        or len(active_labels) != active_count
        or any(
            not isinstance(value, str) or not value for value in active_labels
        )
        or workspace.get("G_search_shape")
        != [ranked_window_count, ranked_window_count]
        or workspace.get("H_search_shape")
        != [ranked_window_count, ranked_window_count]
        or workspace.get("G_active_candidate_shape")
        != [active_count, ranked_window_count]
        or workspace.get("H_active_candidate_shape")
        != [active_count, ranked_window_count]
        or workspace.get("G_AA_dimensions") != [active_count, active_count]
        or workspace.get("H_AA_dimensions") != [active_count, active_count]
        or workspace.get("G_AB_dimensions")
        != [active_count, ranked_window_count]
        or workspace.get("H_AB_dimensions")
        != [active_count, ranked_window_count]
        or workspace.get("G_BB_dimensions")
        != [ranked_window_count, ranked_window_count]
        or workspace.get("H_BB_dimensions")
        != [ranked_window_count, ranked_window_count]
    ):
        raise ValueError(
            "geometry workspace dimensions do not close the exhausted search"
        )
    child_search_count = int(
        payload.get("child_phase2_search_population_count", -1)
    )
    if (
        child_search_count < ranked_window_count
        or int(payload.get("child_phase2_survivor_count", -1))
        != child_search_count
        or int(payload.get("child_phase2_rank_feasible_count", -1))
        != child_search_count
        or payload.get("child_phase2_rank_feasible_count_semantics")
        != "compatibility_alias_for_unfiltered_search_population_count"
        or payload.get("search_pool_truncated")
        is not (child_search_count > ranked_window_count)
        or payload.get("batch_search_pool_truncated")
        is not (child_search_count > ranked_window_count)
    ):
        raise ValueError(
            "search-window aliases do not close the ranked child population"
        )
    identities: list[tuple[str, str]] = []
    admission_keys: list[tuple[int, int, str]] = []
    for index, row in enumerate(search_pool_records):
        if (
            not isinstance(row, Mapping)
            or int(row.get("workspace_index", -1)) != index
        ):
            raise ValueError("geometry workspace search order is incomplete")
        identity = (
            str(row.get("generator_identity_kind", "")),
            str(row.get("generator_identity", "")),
        )
        if not all(identity):
            raise ValueError("geometry workspace omitted generator identity")
        identities.append(identity)
        admission_keys.append(
            (
                int(row.get("candidate_pool_index", -1)),
                int(row.get("position_id", -1)),
                str(row.get("candidate_label", "")),
            )
        )
    if len(set(identities)) != ranked_window_count:
        raise ValueError("rank-gate exhaustion window is not generator-distinct")

    expected_pair_count = math.comb(ranked_window_count, 2)
    expected_pairs = list(itertools.combinations(range(ranked_window_count), 2))
    pair_receipts = workspace.get("joint_pair_receipts")
    observed_pairs = []
    if not isinstance(pair_receipts, list):
        raise ValueError("geometry workspace omitted joint-pair receipts")
    for row in pair_receipts:
        if not isinstance(row, Mapping):
            raise ValueError("joint-pair receipts must be mappings")
        observed_pairs.append(
            (
                int(row.get("left_workspace_index", -1)),
                int(row.get("right_workspace_index", -1)),
            )
        )
    if (
        observed_pairs != expected_pairs
        or int(workspace.get("candidate_pair_count", -1)) != expected_pair_count
        or int(workspace.get("required_candidate_pair_count", -1))
        != expected_pair_count
        or int(workspace.get("constructed_candidate_pair_count", -1))
        != expected_pair_count
    ):
        raise ValueError("geometry workspace pair accounting is incomplete")

    accounting = payload.get("pair_geometry_estimator_accounting")
    if not isinstance(accounting, Mapping):
        raise ValueError("rank-gate exhaustion lost pair estimator accounting")
    pair_rows = accounting.get("pairs")
    if (
        accounting.get("schema")
        != "combinatorial_batch_pair_estimator_accounting_v1"
        or int(accounting.get("all_evaluated_pair_count", -1))
        != expected_pair_count
        or int(accounting.get("winning_pair_count", -1)) != 0
        or not isinstance(pair_rows, list)
        or len(pair_rows) != expected_pair_count
        or any(
            not isinstance(row, Mapping) or row.get("winning_pair") is not False
            for row in pair_rows
        )
    ):
        raise ValueError("pair estimator accounting does not close the search")
    expected_accounting_pairs = list(itertools.combinations(admission_keys, 2))
    observed_accounting_pairs: list[
        tuple[tuple[int, int, str], tuple[int, int, str]]
    ] = []
    for row in pair_rows:
        left = row.get("left_record_key")
        right = row.get("right_record_key")
        primitive_rows = row.get("primitive_rows")
        if (
            row.get("schema")
            != "combinatorial_batch_pair_estimator_accounting_v1"
            or not isinstance(left, list)
            or not isinstance(right, list)
            or len(left) != 3
            or len(right) != 3
            or not isinstance(primitive_rows, list)
            or len(primitive_rows) != 2
        ):
            raise ValueError("pair estimator row is incomplete")
        observed_accounting_pairs.append(
            (
                (int(left[0]), int(left[1]), str(left[2])),
                (int(right[0]), int(right[1]), str(right[2])),
            )
        )
    if observed_accounting_pairs != expected_accounting_pairs:
        raise ValueError("pair estimator rows repeat or omit a required pair")
    return payload


def _terminal_phase3_record_identity(
    row: Mapping[str, Any],
) -> tuple[str, int, str, int]:
    required = {
        "domain_record_id",
        "generator_id",
        "pool_index",
        "pool_label",
        "insertion_position",
    }
    if (
        set(row) != required
        or not isinstance(row.get("domain_record_id"), str)
        or not row.get("domain_record_id")
        or not isinstance(row.get("generator_id"), str)
        or not row.get("generator_id")
        or isinstance(row.get("pool_index"), bool)
        or not isinstance(row.get("pool_index"), int)
        or int(row.get("pool_index", -1)) < 0
        or not isinstance(row.get("pool_label"), str)
        or not row.get("pool_label")
        or isinstance(row.get("insertion_position"), bool)
        or not isinstance(row.get("insertion_position"), int)
        or int(row.get("insertion_position", -1)) < 0
    ):
        raise ValueError("terminal Phase-III record schema is invalid")
    return (
        str(row["generator_id"]),
        int(row["pool_index"]),
        str(row["pool_label"]),
        int(row["insertion_position"]),
    )


def canonical_rank_gate_terminal_phase3_projection(
    value: Any,
    *,
    phase3_population: Sequence[Mapping[str, Any]],
    allow_source_projection: bool = False,
) -> dict[str, Any]:
    """Project legacy Phase-III telemetry into a strict terminal receipt.

    The source projection includes archival parent-expansion telemetry and an
    opaque digest whose preimage is not serialized.  Neither is suitable as
    re-sign-resistant terminal authority.  This projection retains only the
    closed child-evaluation population and derives its identity digest from
    those sealed rows.
    """

    if not isinstance(value, Mapping):
        raise ValueError("terminal exhaustion lost its Phase-III projection")
    projected = canonical_json_copy(dict(value))
    phase_order = (
        "phase1_parent_shortlist_then_split_then_phase2_children_then_phase3"
    )
    if (
        projected.get("schema")
        == "paper_i_projected_phase3_population_receipt_v2"
    ):
        if not allow_source_projection:
            raise ValueError(
                "terminal Phase-III projection must use the generic sealed schema"
            )
        evaluations = projected.get("phase3_child_evaluations")
        if not isinstance(evaluations, list):
            raise ValueError("terminal Phase-III projection accounting is invalid")
        projected = {
            "schema": COMBINATORIAL_BATCH_TERMINAL_PHASE3_PROJECTION_SCHEMA,
            "source_projection_schema": (
                "paper_i_projected_phase3_population_receipt_v2"
            ),
            "phase_order": projected.get("phase_order"),
            "phase2_retained_child_count": projected.get(
                "phase2_retained_child_count"
            ),
            "phase3_joint_search_input_count": projected.get(
                "phase3_joint_search_input_count"
            ),
            "phase2_to_phase3_population_authority": projected.get(
                "phase2_to_phase3_population_authority"
            ),
            "phase3_evaluated_candidate_count": projected.get(
                "phase3_evaluated_candidate_count"
            ),
            "parent_phase2_measurement_count": projected.get(
                "parent_phase2_measurement_count"
            ),
            "parent_phase3_measurement_count": projected.get(
                "parent_phase3_measurement_count"
            ),
            "child_primitive_reuse_count": projected.get(
                "child_primitive_reuse_count"
            ),
            "child_primitive_reuse_scope": projected.get(
                "child_primitive_reuse_scope"
            ),
            "cross_outer_iteration_reuse_count": projected.get(
                "cross_outer_iteration_reuse_count"
            ),
            "active_scaffold_acquisition_policy": projected.get(
                "active_scaffold_acquisition_policy"
            ),
            "phase3_child_evaluations": evaluations,
        }
    supplied_sha256 = projected.pop("sha256", None)
    expected_fields = {
        "schema",
        "source_projection_schema",
        "phase_order",
        "phase2_retained_child_count",
        "phase3_joint_search_input_count",
        "phase2_to_phase3_population_authority",
        "phase3_evaluated_candidate_count",
        "parent_phase2_measurement_count",
        "parent_phase3_measurement_count",
        "child_primitive_reuse_count",
        "child_primitive_reuse_scope",
        "cross_outer_iteration_reuse_count",
        "active_scaffold_acquisition_policy",
        "phase3_child_evaluations",
        "phase3_evaluated_identities_sha256",
    }
    evaluations = projected.get("phase3_child_evaluations")
    evaluated_count = int(
        projected.get("phase3_evaluated_candidate_count", -1)
    )
    retained_count = int(projected.get("phase2_retained_child_count", -1))
    joint_search_input_count = int(
        projected.get("phase3_joint_search_input_count", -1)
    )
    if (
        projected.get("schema")
        != COMBINATORIAL_BATCH_TERMINAL_PHASE3_PROJECTION_SCHEMA
        or projected.get("source_projection_schema")
        != "paper_i_projected_phase3_population_receipt_v2"
        or projected.get("phase_order") != phase_order
        or not isinstance(evaluations, list)
        or evaluated_count != len(evaluations)
        or not 0 < retained_count <= joint_search_input_count
        or joint_search_input_count != evaluated_count
        or projected.get("phase2_to_phase3_population_authority")
        != COMBINATORIAL_BATCH_PHASE3_POPULATION_AUTHORITY
        or evaluated_count < len(phase3_population)
        or int(projected.get("child_primitive_reuse_count", -1))
        != 3 * evaluated_count
        or projected.get("child_primitive_reuse_scope")
        != "same_outer_iteration_phase2_to_phase3"
        or int(projected.get("cross_outer_iteration_reuse_count", -1)) != 0
        or int(projected.get("parent_phase2_measurement_count", -1)) != 0
        or int(projected.get("parent_phase3_measurement_count", -1)) != 0
        or projected.get("active_scaffold_acquisition_policy")
        != "once_per_outer_iteration"
    ):
        raise ValueError("terminal Phase-III projection accounting is invalid")

    evaluation_identities: list[tuple[int, str, int]] = []
    for row in evaluations:
        if not isinstance(row, Mapping):
            raise ValueError("terminal Phase-III child evaluation is invalid")
        label = row.get("candidate_label")
        child_identity = row.get("child_identity")
        if (
            set(row)
            != {
                "candidate_label",
                "child_identity",
                "child_primitive_reuse_scope",
                "cross_outer_iteration_reuse_count",
                "phase2_child_local_reuse_count",
                "phase_order",
                "schema",
            }
            or row.get("schema")
            != "paper_i_projected_phase3_child_evaluation_v1"
            or row.get("phase_order") != phase_order
            or row.get("child_primitive_reuse_scope")
            != "same_outer_iteration_phase2_to_phase3"
            or int(row.get("cross_outer_iteration_reuse_count", -1)) != 0
            or int(row.get("phase2_child_local_reuse_count", -1)) != 3
            or not isinstance(label, str)
            or not label
            or not isinstance(child_identity, str)
        ):
            raise ValueError("terminal Phase-III child evaluation is invalid")
        pieces = child_identity.split(":", maxsplit=2)
        if len(pieces) != 3 or pieces[2] != label:
            raise ValueError("terminal Phase-III child identity is invalid")
        try:
            pool_index = int(pieces[0])
            insertion_position = int(pieces[1])
        except ValueError as exc:
            raise ValueError(
                "terminal Phase-III child identity is invalid"
            ) from exc
        evaluation_identities.append((pool_index, label, insertion_position))
    if len(set(evaluation_identities)) != len(evaluation_identities):
        raise ValueError("terminal Phase-III projection repeats a child")
    identity_payload = [
        {
            "pool_index": pool_index,
            "candidate_label": label,
            "insertion_position": insertion_position,
        }
        for pool_index, label, insertion_position in evaluation_identities
    ]
    identity_sha256 = canonical_sha256(identity_payload)
    declared_identity_sha256 = projected.get(
        "phase3_evaluated_identities_sha256"
    )
    if declared_identity_sha256 is None:
        projected["phase3_evaluated_identities_sha256"] = identity_sha256
    elif declared_identity_sha256 != identity_sha256:
        raise ValueError("terminal Phase-III projection identity drifted")
    population_identities = {
        (
            int(row["pool_index"]),
            str(row["pool_label"]),
            int(row["insertion_position"]),
        )
        for row in phase3_population
    }
    if not population_identities.issubset(set(evaluation_identities)):
        raise ValueError(
            "terminal Phase-III population escaped its projected evaluation"
        )
    if set(projected) != expected_fields:
        raise ValueError("terminal Phase-III projection fields are invalid")
    derived_sha256 = canonical_sha256(projected)
    if supplied_sha256 is not None and supplied_sha256 != derived_sha256:
        raise ValueError("terminal Phase-III projection digest mismatch")
    projected["sha256"] = derived_sha256
    return projected


def validate_rank_gate_exhaustion_receipt(
    receipt: Mapping[str, Any],
    *,
    route_contract: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate the stable terminal envelope around an exhausted search."""

    if not isinstance(receipt, Mapping):
        raise TypeError("combinatorial exhaustion receipt must be a mapping")
    payload = canonical_json_copy(dict(receipt))
    supplied_sha = payload.pop("sha256", None)
    if supplied_sha is not None and supplied_sha != canonical_sha256(payload):
        raise ValueError("combinatorial exhaustion receipt digest mismatch")
    if (
        payload.get("schema")
        != COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTION_RECEIPT_SCHEMA
        or payload.get("terminal_controller_outcome")
        != COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTED_OUTCOME
        or payload.get("combinatorial_batch_subset_feasibility_policy")
        != COMBINATORIAL_BATCH_SUBSET_FEASIBILITY_POLICY
        or payload.get("combinatorial_batch_empty_feasible_set_policy")
        != COMBINATORIAL_BATCH_EMPTY_FEASIBLE_SET_POLICY
        or int(payload.get("accepted_controller_round", 0)) < 1
        or int(payload.get("attempted_controller_round", -1))
        != int(payload.get("accepted_controller_round", 0)) + 1
        or payload.get("accepted_state_unchanged") is not True
        or payload.get("final_admission_record_ids") != []
        or int(payload.get("phase3_population_count", 0)) < 1
        or int(payload.get("phase3_frontier_count", 0)) < 1
    ):
        raise ValueError("combinatorial exhaustion terminal envelope is invalid")
    maximum = int(payload.get("maximum_size", 0))
    search_window = payload.get("search_window_size")
    if search_window is not None:
        search_window = int(search_window)
    summary = validate_rank_gate_exhaustion_summary(
        payload.get("search_summary", {}),
        maximum_size=maximum,
        search_window_size=search_window,
    )
    if (
        payload.get("search_summary_sha256") != canonical_sha256(summary)
        or payload.get("exhaustion_identity")
        != canonical_sha256(
            {
                "maximum_size": maximum,
                "search_window_size": search_window,
                "summary": summary,
            }
        )
    ):
        raise ValueError("terminal receipt detached its exhaustive search identity")
    for key in (
        "ranked_window_count",
        "subset_counts_considered",
        "subset_counts_evaluated",
        "subset_counts_feasible",
        "rejection_counts",
        "subset_diagnostics",
    ):
        if payload.get(key) != summary.get(key):
            raise ValueError(f"terminal receipt detached {key} from search summary")
    phase_populations = payload.get("phase_populations")
    if not isinstance(phase_populations, list) or len(phase_populations) != 3:
        raise ValueError("terminal receipt omitted Phase-I--III populations")
    expected_phase_names = ("phase_i", "phase_ii", "phase_iii")
    concatenated_event_ids: list[str] = []
    for phase_name, phase_row in zip(
        expected_phase_names,
        phase_populations,
        strict=True,
    ):
        if not isinstance(phase_row, Mapping):
            raise ValueError("terminal phase population must be a mapping")
        population = phase_row.get("population")
        shortlist = phase_row.get("shortlist")
        phase_event_ids = phase_row.get("estimator_event_ids")
        if (
            phase_row.get("phase") != phase_name
            or not isinstance(population, list)
            or not isinstance(shortlist, list)
            or int(phase_row.get("population_count", -1)) != len(population)
            or int(phase_row.get("shortlist_count", -1)) != len(shortlist)
            or not isinstance(phase_event_ids, list)
            or any(not isinstance(value, str) or not value for value in phase_event_ids)
        ):
            raise ValueError("terminal phase population accounting is incomplete")
        population_keys = [
            (row.get("domain_record_id"), row.get("generator_id"))
            for row in population
            if isinstance(row, Mapping)
        ]
        shortlist_keys = [
            (row.get("domain_record_id"), row.get("generator_id"))
            for row in shortlist
            if isinstance(row, Mapping)
        ]
        population_identities = [
            _terminal_phase3_record_identity(row)
            for row in population
            if isinstance(row, Mapping)
        ]
        shortlist_identities = [
            _terminal_phase3_record_identity(row)
            for row in shortlist
            if isinstance(row, Mapping)
        ]
        if (
            len(population_keys) != len(population)
            or len(shortlist_keys) != len(shortlist)
            or len(population_identities) != len(population)
            or len(shortlist_identities) != len(shortlist)
            or len(set(population_keys)) != len(population_keys)
            or len(set(shortlist_keys)) != len(shortlist_keys)
            or len(set(population_identities)) != len(population_identities)
            or len(set(shortlist_identities)) != len(shortlist_identities)
            or not set(shortlist_keys).issubset(set(population_keys))
            or not set(shortlist_identities).issubset(
                set(population_identities)
            )
        ):
            raise ValueError("terminal phase population lineage is invalid")
        concatenated_event_ids.extend(phase_event_ids)
    phase3 = phase_populations[-1]
    if (
        phase3.get("population") != payload.get("phase3_population")
        or phase3.get("shortlist") != payload.get("phase3_frontier")
        or phase3.get("population_count")
        != payload.get("phase3_population_count")
        or phase3.get("shortlist_count")
        != payload.get("phase3_frontier_count")
        or int(summary.get("ranked_population_count", -1))
        != int(payload.get("phase3_population_count", -2))
        or int(summary.get("ranked_window_count", -1))
        > int(payload.get("phase3_frontier_count", -2))
    ):
        raise ValueError("terminal receipt detached its positive Phase-III frontier")
    phase3_population = phase3["population"]
    phase3_frontier = phase3["shortlist"]
    population_identity_set = {
        _terminal_phase3_record_identity(row) for row in phase3_population
    }
    frontier_identity_set = {
        _terminal_phase3_record_identity(row) for row in phase3_frontier
    }
    ranked_frontier_prefix_identity_set = {
        _terminal_phase3_record_identity(row)
        for row in phase3_frontier[: int(summary["ranked_window_count"])]
    }
    workspace = summary["geometry_workspace"]
    workspace_active_depth = int(workspace["active_ansatz_depth"])
    if (
        workspace_active_depth
        != int(payload.get("accepted_operator_count", -1))
    ):
        raise ValueError(
            "terminal geometry workspace is detached from the accepted prefix"
        )
    search_identities: list[tuple[str, int, str, int]] = []
    for row in workspace["search_pool_records"]:
        if row.get("generator_identity_kind") != "generator_id":
            raise ValueError(
                "terminal search window uses an unsupported generator identity"
            )
        search_identities.append(
            (
                str(row["generator_identity"]),
                int(row["candidate_pool_index"]),
                str(row["candidate_label"]),
                int(row["position_id"]),
            )
        )
    if (
        len(set(search_identities)) != len(search_identities)
        or not set(search_identities).issubset(population_identity_set)
        or not set(search_identities).issubset(frontier_identity_set)
        or set(search_identities) != ranked_frontier_prefix_identity_set
    ):
        raise ValueError(
            "terminal search window escaped the positive Phase-III frontier"
        )
    payload["projected_phase3_population_receipt"] = (
        canonical_rank_gate_terminal_phase3_projection(
            payload.get("projected_phase3_population_receipt"),
            phase3_population=phase3_population,
        )
    )
    event_ids = payload.get("estimator_event_ids")
    if (
        not isinstance(event_ids, list)
        or event_ids != concatenated_event_ids
        or len(set(event_ids)) != len(event_ids)
        or int(payload.get("estimator_event_count", -1)) != len(event_ids)
        or payload.get("estimator_event_ids_sha256")
        != canonical_sha256(event_ids)
    ):
        raise ValueError("terminal estimator-event evidence is incomplete")
    terminal_estimator = payload.get("terminal_estimator_prefix_receipt")
    if terminal_estimator is not None and (
        not isinstance(terminal_estimator, Mapping)
        or payload.get("terminal_estimator_prefix_receipt_sha256")
        != canonical_sha256(terminal_estimator)
        or terminal_estimator.get("checkpoint_kind")
        != COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTION_CHECKPOINT_KIND
    ):
        raise ValueError("terminal estimator-prefix receipt is invalid")
    if route_contract is not None:
        invariants = route_contract.get("semantic_invariants")
        if (
            not isinstance(invariants, Mapping)
            or invariants.get("canonical_admission_policy")
            != "combinatorial_batch"
            or invariants.get("admission_policy")
            != "cost_weighted_combinatorial_reduced_plane_v1"
            or invariants.get("admission_cardinality")
            != "one_to_configured_maximum_v1"
            or invariants.get("combinatorial_batch_maximum_size")
            != maximum
            or invariants.get("combinatorial_batch_search_window_size")
            != search_window
            or invariants.get("combinatorial_batch_subset_feasibility_policy")
            != COMBINATORIAL_BATCH_SUBSET_FEASIBILITY_POLICY
            or invariants.get("combinatorial_batch_empty_feasible_set_policy")
            != COMBINATORIAL_BATCH_EMPTY_FEASIBLE_SET_POLICY
            or any(
                invariants.get(key) != expected
                for key, expected in (
                    _TERMINAL_COMBINATORIAL_ROUTE_INVARIANTS.items()
                )
            )
        ):
            raise ValueError("active route does not authorize typed exhaustion")
    payload["sha256"] = canonical_sha256(payload)
    return payload
