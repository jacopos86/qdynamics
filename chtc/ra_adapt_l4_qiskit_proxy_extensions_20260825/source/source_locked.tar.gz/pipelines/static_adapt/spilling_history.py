"""List-compatible run-history container that spills old rows to disk.

CHTC memory diet, second increment (user directive 2026-08-18/19).
Semantics contract: identical to a plain list of dict rows — full
iteration order, random access (positive and negative indices), slices,
and length — so every consumer, including the Paper-I S_alg accounting
readers, sees the complete record. During-run accounting reads live;
post-run deterministic recounts replay the spill file plus the in-RAM
tail. Rows are JSON-serialized on spill; consumers receive dicts either
way.

Equivalence proof: test/test_spilling_history.py.
"""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Iterator


class SpillingHistory:
    """Append-mostly history with a bounded in-RAM tail.

    Rows older than ``tail_rows`` are written to a JSONL spill file with
    a byte-offset index kept in memory (8 bytes per spilled row), so
    random access stays O(1) reads and full iteration is one sequential
    pass. Mutation of already-spilled rows is unsupported and raises —
    run history is append-and-read in practice; the tail (recent rows)
    remains mutable exactly like list entries.
    """

    def __init__(self, spill_path: str | Path, *, tail_rows: int = 64) -> None:
        if int(tail_rows) < 1:
            raise ValueError("tail_rows must be >= 1.")
        self._lock = threading.RLock()
        self._path = Path(spill_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._handle = open(self._path, "a+", encoding="utf-8")
        self._offsets: list[int] = []
        self._tail: list[Any] = []
        self._tail_rows = int(tail_rows)

    # -- list surface -------------------------------------------------
    def append(self, row: Any) -> None:
        with self._lock:
            self._tail.append(row)
            while len(self._tail) > self._tail_rows:
                self._spill_one_locked()

    def __len__(self) -> int:
        with self._lock:
            return len(self._offsets) + len(self._tail)

    def __iter__(self) -> Iterator[Any]:
        with self._lock:
            spilled = len(self._offsets)
            for index in range(spilled):
                yield self._read_spilled_locked(index)
            yield from list(self._tail)

    def __getitem__(self, index: Any) -> Any:
        with self._lock:
            total = len(self)
            if isinstance(index, slice):
                return [self[i] for i in range(*index.indices(total))]
            i = int(index)
            if i < 0:
                i += total
            if not 0 <= i < total:
                raise IndexError("history index out of range")
            spilled = len(self._offsets)
            if i < spilled:
                return self._read_spilled_locked(i)
            return self._tail[i - spilled]

    def __setitem__(self, index: Any, value: Any) -> None:
        with self._lock:
            total = len(self)
            i = int(index)
            if i < 0:
                i += total
            spilled = len(self._offsets)
            if not spilled <= i < total:
                raise ValueError(
                    "SpillingHistory rows already spilled to disk are "
                    "immutable; only tail rows may be replaced."
                )
            self._tail[i - spilled] = value

    def __bool__(self) -> bool:
        return len(self) > 0

    # -- internals ----------------------------------------------------
    def _spill_one_locked(self) -> None:
        row = self._tail.pop(0)
        self._handle.seek(0, 2)
        offset = self._handle.tell()
        self._handle.write(
            json.dumps(row, sort_keys=True, default=str) + "\n"
        )
        self._handle.flush()
        self._offsets.append(offset)

    def _read_spilled_locked(self, index: int) -> Any:
        self._handle.flush()
        self._handle.seek(self._offsets[index])
        return json.loads(self._handle.readline())
