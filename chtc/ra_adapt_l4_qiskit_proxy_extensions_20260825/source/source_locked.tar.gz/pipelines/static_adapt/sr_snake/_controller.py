"""Authoritative controller for the exact default SR-SNAKE route.

The controller owns the public accepted-state machine:

``accepted state -> selection -> accepted transition -> event projection ->
next accepted state -> configured stop``.

Live numerical arrays, compiled executors, optimizer objects, estimator
instrumentation, and checkpoint serializers remain behind the numerical-session
protocol. The session prepares one round operation at a time; it never owns
controller iteration or configured stopping.
"""

from __future__ import annotations

import copy
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, field
import hashlib
import json
import dataclasses
import math
import numpy as np
from types import MappingProxyType
from typing import Any, Callable, Protocol

from pipelines.static_adapt.sr_snake._selection import (
    _PHASE0_STATIONARY_TERMINAL_OUTCOME,
    _PHASE3_NO_POSITIVE_TERMINAL_OUTCOME,
    _CombinatorialBatchAdmissionDecision,
    _ExhaustedCombinatorialBatchSelection,
    _GreedyBatchAdmissionDecision,
    _SRControllerState,
    _SelectionWorkspace,
    _SingletonAdmissionDecision,
    _NoPositivePhaseIIISelection,
    _StationaryPhase0Selection,
    _select_combinatorial_batch,
    _select_greedy_batch,
    _select_singleton,
)
from pipelines.static_adapt.combinatorial_batch_terminal import (
    COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTED_OUTCOME,
    COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTION_STOP_REASON,
    validate_rank_gate_exhaustion_receipt,
)
from pipelines.static_adapt.sr_snake._transition import (
    _AcceptedCombinatorialBatchTransition,
    _AcceptedGreedyBatchTransition,
    _AcceptedSingletonTransition,
    _AcceptedStateSnapshot,
    _CheckpointReadyAcceptedStateEvent,
    _TransitionWorkspace,
    _transition_combinatorial_batch,
    _transition_greedy_batch,
    _transition_singleton,
)
from pipelines.static_adapt.sr_snake.contracts import (
    BEAM_COMPARISON_BRANCH_COMPILED_COST,
    beam_comparison_carries_recorded_score,
    beam_comparison_filters_pareto,
    beam_comparison_prices_branches,
    beam_comparison_diagnostic_label,
    BEAM_COMPARISON_PHASE3_GAIN_OVER_BURDEN,
    resolved_beam_comparison,
    CombinatorialBatchAdmission,
    ForkLocalBeam,
    GreedyBatchAdmission,
    SRStopPolicy,
    SingletonAdmission,
    StopConditionReceipt,
    StopReceipt,
)


@dataclass(frozen=True, slots=True)
class _PreparedSelection:
    """One exact-round selection prepared by the numerical session."""

    controller_state: _SRControllerState
    workspace: _SelectionWorkspace


_BEAM_SIBLING_DIVERSITY_RECEIPT_SCHEMA = (
    "ra_adapt_beam_sibling_horizontal_fs_rank_v1"
)
_BEAM_SIBLING_DIVERSITY_POLICY = (
    "current_state_append_horizontal_fs_real_tangent_rank_v1"
)
_BEAM_SIBLING_DIVERSITY_COORDINATE_CHART = (
    "append_candidate_zero_angle_at_parent_state_v1"
)
_BEAM_SIBLING_DIVERSITY_POPULATION_AUTHORITY = (
    "decision_phase_ii_full_population_v1"
)
_EXPECTED_PARENT_BRANCH_UNSET = object()


def _beam_sibling_diversity_sha256(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        json.dumps(
            dict(payload),
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    ).hexdigest()


def _seal_beam_sibling_diversity_receipt(
    payload: Mapping[str, Any],
) -> dict[str, Any]:
    unsigned = _plain_isolated_copy(dict(payload))
    unsigned.pop("sha256", None)
    return {
        **unsigned,
        "sha256": _beam_sibling_diversity_sha256(unsigned),
    }


def _validate_beam_sibling_diversity_receipt(
    value: Any,
    *,
    expected_controller_round: int | None = None,
    expected_parent_state_fingerprint: str | None = None,
    expected_selected_pool_indices: Sequence[int] | None = None,
    expected_population_pool_indices: Sequence[int] | None = None,
    expected_branch_id: str | None = None,
    expected_parent_branch_id: str | None | object = (
        _EXPECTED_PARENT_BRANCH_UNSET
    ),
) -> dict[str, Any]:
    """Fail closed on one state-bound beam sibling-diversity receipt."""

    from pipelines.static_adapt.ra_adapt.support import (
        validate_retained_support_receipt,
    )

    if not isinstance(value, Mapping):
        raise ValueError("Beam sibling-diversity receipt must be a mapping.")
    payload = _plain_isolated_copy(dict(value))
    expected_keys = {
        "schema",
        "policy",
        "coordinate_chart",
        "population_authority",
        "state_dependent",
        "real_tangent_space",
        "controller_round",
        "parent_state_fingerprint",
        "branch_id",
        "parent_branch_id",
        "selected_records",
        "population_records",
        "rank_relative_tolerance",
        "metric_regularization",
        "selected_span_support",
        "candidate_rank_evaluations",
        "excluded_pool_indices",
        "remaining_population_pool_count",
        "metric_primitive_ids",
        "sha256",
    }
    if set(payload) != expected_keys:
        raise ValueError(
            "Beam sibling-diversity receipt fields are incomplete or unknown."
        )
    observed_sha = str(payload.pop("sha256", ""))
    if observed_sha != _beam_sibling_diversity_sha256(payload):
        raise ValueError("Beam sibling-diversity receipt digest is invalid.")
    if (
        payload.get("schema") != _BEAM_SIBLING_DIVERSITY_RECEIPT_SCHEMA
        or payload.get("policy") != _BEAM_SIBLING_DIVERSITY_POLICY
        or payload.get("coordinate_chart")
        != _BEAM_SIBLING_DIVERSITY_COORDINATE_CHART
        or payload.get("population_authority")
        != _BEAM_SIBLING_DIVERSITY_POPULATION_AUTHORITY
        or payload.get("state_dependent") is not True
        or payload.get("real_tangent_space") is not True
    ):
        raise ValueError("Beam sibling-diversity policy declaration is invalid.")
    controller_round = int(payload.get("controller_round", -1))
    parent_fingerprint = str(payload.get("parent_state_fingerprint", ""))
    branch_id = str(payload.get("branch_id", ""))
    parent_branch_id_raw = payload.get("parent_branch_id")
    parent_branch_id = (
        None
        if parent_branch_id_raw is None
        else str(parent_branch_id_raw)
    )
    if controller_round < 0 or not parent_fingerprint or not branch_id:
        raise ValueError("Beam sibling-diversity parent binding is invalid.")
    if (
        expected_controller_round is not None
        and controller_round != int(expected_controller_round)
    ):
        raise ValueError("Beam sibling-diversity controller round drifted.")
    if (
        expected_parent_state_fingerprint is not None
        and parent_fingerprint != str(expected_parent_state_fingerprint)
    ):
        raise ValueError("Beam sibling-diversity parent state drifted.")
    if expected_branch_id is not None and branch_id != str(expected_branch_id):
        raise ValueError("Beam sibling-diversity branch identity drifted.")
    if expected_parent_branch_id is not _EXPECTED_PARENT_BRANCH_UNSET and (
        parent_branch_id
        != (
            None
            if expected_parent_branch_id is None
            else str(expected_parent_branch_id)
        )
    ):
        raise ValueError("Beam sibling-diversity parent branch drifted.")

    identity_keys = {
        "domain_record_id",
        "generator_id",
        "pool_index",
        "position_id",
    }

    def _identity(raw: Any, *, owner: str) -> dict[str, Any]:
        if not isinstance(raw, Mapping) or set(raw) != identity_keys:
            raise ValueError(f"{owner} identity is incomplete or unknown.")
        row = {
            "domain_record_id": str(raw.get("domain_record_id", "")),
            "generator_id": str(raw.get("generator_id", "")),
            "pool_index": int(raw.get("pool_index", -1)),
            "position_id": int(raw.get("position_id", -1)),
        }
        if (
            not row["domain_record_id"]
            or not row["generator_id"]
            or row["pool_index"] < 0
            or row["position_id"] < 0
        ):
            raise ValueError(f"{owner} identity is invalid.")
        return row

    selected_raw = payload.get("selected_records")
    population_raw = payload.get("population_records")
    if (
        not isinstance(selected_raw, Sequence)
        or isinstance(selected_raw, (str, bytes, bytearray))
        or not isinstance(population_raw, Sequence)
        or isinstance(population_raw, (str, bytes, bytearray))
    ):
        raise ValueError("Beam sibling-diversity identities must be sequences.")
    selected = [
        _identity(row, owner="selected beam sibling") for row in selected_raw
    ]
    population = [
        _identity(row, owner="population beam sibling")
        for row in population_raw
    ]
    if not selected or not population:
        raise ValueError("Beam sibling-diversity identities must be nonempty.")
    selected_ids = [row["domain_record_id"] for row in selected]
    population_ids = [row["domain_record_id"] for row in population]
    if (
        len(selected_ids) != len(set(selected_ids))
        or len(population_ids) != len(set(population_ids))
        or not set(selected_ids).issubset(set(population_ids))
    ):
        raise ValueError("Beam sibling-diversity identities are inconsistent.")
    selected_pools = tuple(int(row["pool_index"]) for row in selected)
    population_pools_ordered = tuple(
        int(row["pool_index"]) for row in population
    )
    if (
        expected_selected_pool_indices is not None
        and selected_pools
        != tuple(int(value) for value in expected_selected_pool_indices)
    ):
        raise ValueError("Beam sibling-diversity selected pools drifted.")
    if (
        expected_population_pool_indices is not None
        and population_pools_ordered
        != tuple(int(value) for value in expected_population_pool_indices)
    ):
        raise ValueError("Beam sibling-diversity Phase-II population drifted.")

    tolerance = float(payload.get("rank_relative_tolerance", math.nan))
    regularization = float(payload.get("metric_regularization", math.nan))
    if (
        not math.isfinite(tolerance)
        or tolerance < 0.0
        or not math.isfinite(regularization)
        or regularization < 0.0
    ):
        raise ValueError("Beam sibling-diversity rank settings are invalid.")
    selected_support = validate_retained_support_receipt(
        payload.get("selected_span_support")
    )
    if (
        selected_support.dimension != len(selected)
        or selected_support.rank < 1
        or float(selected_support.rank_relative_tolerance) != tolerance
        or float(selected_support.metric_regularization) != regularization
    ):
        raise ValueError("Beam selected-span support receipt is inconsistent.")

    evaluations_raw = payload.get("candidate_rank_evaluations")
    if not isinstance(evaluations_raw, Sequence) or isinstance(
        evaluations_raw, (str, bytes, bytearray)
    ):
        raise ValueError("Beam sibling rank evaluations must be a sequence.")
    expected_evaluation_ids = [
        identity
        for identity in population_ids
        if identity not in set(selected_ids)
    ]
    evaluation_ids: list[str] = []
    equivalent_by_pool: dict[int, list[bool]] = {}
    primitive_ids: list[str] = []
    for raw in evaluations_raw:
        if not isinstance(raw, Mapping) or set(raw) != {
            "candidate_record",
            "real_fs_gram",
            "augmented_support",
            "rank_gain",
            "equivalent_to_selected_span",
            "metric_primitive_id",
        }:
            raise ValueError("Beam sibling rank evaluation is malformed.")
        identity = _identity(
            raw.get("candidate_record"),
            owner="evaluated beam sibling",
        )
        evaluation_ids.append(identity["domain_record_id"])
        gram = raw.get("real_fs_gram")
        dimension = len(selected) + 1
        if (
            not isinstance(gram, Sequence)
            or isinstance(gram, (str, bytes, bytearray))
            or len(gram) != dimension
            or any(
                not isinstance(row, Sequence)
                or isinstance(row, (str, bytes, bytearray))
                or len(row) != dimension
                for row in gram
            )
            or any(
                not math.isfinite(float(value))
                for row in gram
                for value in row
            )
            or any(
                not math.isclose(
                    float(gram[left][right]),
                    float(gram[right][left]),
                    rel_tol=1.0e-10,
                    abs_tol=1.0e-12,
                )
                for left in range(dimension)
                for right in range(dimension)
            )
        ):
            raise ValueError("Beam sibling real-FS Gram is invalid.")
        support = validate_retained_support_receipt(
            raw.get("augmented_support")
        )
        rank_gain = int(raw.get("rank_gain", -1))
        equivalent = raw.get("equivalent_to_selected_span")
        primitive_id = str(raw.get("metric_primitive_id", ""))
        if (
            support.dimension != dimension
            or float(support.rank_relative_tolerance) != tolerance
            or float(support.metric_regularization) != regularization
            or rank_gain != int(support.rank - selected_support.rank)
            or rank_gain < 0
            or equivalent is not (rank_gain == 0)
            or not primitive_id
        ):
            raise ValueError("Beam sibling rank decision is inconsistent.")
        equivalent_by_pool.setdefault(
            int(identity["pool_index"]), []
        ).append(bool(equivalent))
        primitive_ids.append(primitive_id)
    if evaluation_ids != expected_evaluation_ids:
        raise ValueError("Beam sibling rank evaluations drifted from population.")

    excluded_raw = payload.get("excluded_pool_indices")
    metric_ids_raw = payload.get("metric_primitive_ids")
    if (
        not isinstance(excluded_raw, Sequence)
        or isinstance(excluded_raw, (str, bytes, bytearray))
        or not isinstance(metric_ids_raw, Sequence)
        or isinstance(metric_ids_raw, (str, bytes, bytearray))
    ):
        raise ValueError("Beam sibling exclusion/accounting must be sequences.")
    excluded = tuple(int(value) for value in excluded_raw)
    expected_excluded = set(selected_pools)
    expected_excluded.update(
        pool_index
        for pool_index, decisions in equivalent_by_pool.items()
        if decisions and all(decisions)
    )
    if (
        excluded != tuple(sorted(set(excluded)))
        or set(excluded) != expected_excluded
        or [str(value) for value in metric_ids_raw]
        != sorted(set(primitive_ids))
    ):
        raise ValueError("Beam sibling exclusion/accounting closure is invalid.")
    population_pools = {int(row["pool_index"]) for row in population}
    if int(payload.get("remaining_population_pool_count", -1)) != len(
        population_pools.difference(excluded)
    ):
        raise ValueError("Beam sibling remaining-population count is invalid.")
    return {**payload, "sha256": observed_sha}


def _plain_isolated_copy(value: Any) -> Any:
    """Copy-isolate one JSON-shaped projection value.

    Projection records are JSON-shaped by construction (they are written
    into checkpoints verbatim), so a direct structural walk produces the
    exact object graph copy.deepcopy produced — same types, same values —
    without deepcopy's memo/dispatch overhead, which dominated whole-run
    profiles. Any non-JSON leaf falls back to copy.deepcopy unchanged.
    """

    kind = type(value)
    if kind is dict:
        return {key: _plain_isolated_copy(item) for key, item in value.items()}
    if kind is list:
        return [_plain_isolated_copy(item) for item in value]
    if kind is tuple:
        return tuple(_plain_isolated_copy(item) for item in value)
    if kind in (str, int, float, bool, complex, bytes, type(None)):
        return value
    return copy.deepcopy(value)


@dataclass(frozen=True, slots=True)
class _ImmutableProjectionRecord(Mapping[str, Any]):
    """Copy-isolated view over one controller projection record."""

    _values: Mapping[str, Any] = field(repr=False)

    def __post_init__(self) -> None:
        if not isinstance(self._values, Mapping):
            raise TypeError("projection record values must be a mapping")
        values = _plain_isolated_copy(dict(self._values))
        if any(not isinstance(key, str) for key in values):
            raise TypeError("projection record keys must be strings")
        object.__setattr__(
            self,
            "_values",
            MappingProxyType(values),
        )

    def __getitem__(self, key: str) -> Any:
        return _plain_isolated_copy(self._values[key])

    def __iter__(self) -> Iterator[str]:
        return iter(self._values)

    def __len__(self) -> int:
        return len(self._values)

    def to_mutable_mapping(self) -> dict[str, Any]:
        """Return one mutable copy of the retained projection fields."""

        return _plain_isolated_copy(dict(self._values))


@dataclass(frozen=True, slots=True)
class _AcceptedCheckpointProjection:
    """Immutable active-prefix checkpoint produced after one acceptance."""

    record: _ImmutableProjectionRecord

    @classmethod
    def from_mapping(
        cls,
        record: Mapping[str, Any],
    ) -> _AcceptedCheckpointProjection:
        return cls(record=_ImmutableProjectionRecord(record))


@dataclass(frozen=True, slots=True)
class _AcceptedReplayProjection:
    """Immutable replay/history row produced after one acceptance."""

    record: _ImmutableProjectionRecord

    @classmethod
    def from_mapping(
        cls,
        record: Mapping[str, Any],
    ) -> _AcceptedReplayProjection:
        return cls(record=_ImmutableProjectionRecord(record))


@dataclass(frozen=True, slots=True)
class _ProjectedAcceptedRound:
    """Observation-independent in-memory projection of one accepted event."""

    controller_round: int
    accepted_state_fingerprint: str
    checkpoint_projection: _AcceptedCheckpointProjection
    replay_projection: _AcceptedReplayProjection

    def __post_init__(self) -> None:
        if self.controller_round <= 0:
            raise ValueError(
                "projected accepted rounds must be one-based and positive"
            )
        if not self.accepted_state_fingerprint:
            raise ValueError(
                "projected accepted-state fingerprint must be non-empty"
            )
        if not isinstance(
            self.checkpoint_projection,
            _AcceptedCheckpointProjection,
        ):
            raise TypeError(
                "accepted-round checkpoint projection has the wrong type"
            )
        if not isinstance(
            self.replay_projection,
            _AcceptedReplayProjection,
        ):
            raise TypeError(
                "accepted-round replay projection has the wrong type"
            )


@dataclass(frozen=True, slots=True)
class _DefaultControllerFinalization:
    """Typed terminal numerical projection consumed by the facade runner."""

    _record: _ImmutableProjectionRecord = field(repr=False)
    route_family: str = field(init=False)
    route_profile: str = field(init=False)
    route_contract: _ImmutableProjectionRecord = field(init=False)
    route_contract_sha256: str = field(init=False)
    history: tuple[_AcceptedReplayProjection, ...] = field(init=False)
    estimator_call_accounting: _ImmutableProjectionRecord = field(init=False)
    continuation: _ImmutableProjectionRecord = field(init=False)

    @classmethod
    def from_mapping(
        cls,
        payload: Mapping[str, Any],
    ) -> _DefaultControllerFinalization:
        return cls(_record=_ImmutableProjectionRecord(payload))

    def __post_init__(self) -> None:
        if not isinstance(self._record, _ImmutableProjectionRecord):
            raise TypeError("finalization requires an immutable record")
        if self._record.get("success") is not True:
            raise ValueError(
                "default controller finalization requires successful output"
            )
        route_family = str(self._record.get("route_family", ""))
        route_profile = str(self._record.get("route_profile", ""))
        route_contract_sha256 = str(
            self._record.get("sr_route_profile_contract_sha256", "")
        )
        if not route_family or not route_profile or not route_contract_sha256:
            raise ValueError(
                "default controller finalization is missing route identity"
            )
        route_contract = self._record.get("sr_route_profile_contract")
        accounting = self._record.get("estimator_call_accounting")
        continuation = self._record.get("continuation")
        history = self._record.get("history")
        if not isinstance(route_contract, Mapping):
            raise TypeError("finalization route contract must be a mapping")
        if not isinstance(accounting, Mapping):
            raise TypeError(
                "finalization estimator accounting must be a mapping"
            )
        if not isinstance(continuation, Mapping):
            raise TypeError("finalization continuation must be a mapping")
        if not isinstance(history, Sequence) or isinstance(
            history,
            (str, bytes),
        ):
            raise TypeError("finalization history must be a sequence")
        replay_rows: list[_AcceptedReplayProjection] = []
        for row in history:
            if not isinstance(row, Mapping):
                raise TypeError("finalization history rows must be mappings")
            replay_rows.append(_AcceptedReplayProjection.from_mapping(row))
        terminal_outcome = self._record.get(
            "terminal_controller_outcome"
        )
        if not replay_rows and terminal_outcome not in {
            _PHASE0_STATIONARY_TERMINAL_OUTCOME,
            _PHASE3_NO_POSITIVE_TERMINAL_OUTCOME,
        }:
            raise ValueError(
                "default controller finalization requires accepted history"
            )
        if terminal_outcome is not None and terminal_outcome not in {
            _PHASE0_STATIONARY_TERMINAL_OUTCOME,
            _PHASE3_NO_POSITIVE_TERMINAL_OUTCOME,
            COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTED_OUTCOME,
        }:
            raise ValueError("default controller terminal outcome is unknown")
        phase3_terminal_receipt = self._record.get(
            "terminal_phase3_selection_receipt"
        )
        continuation_phase3_terminal_receipt = continuation.get(
            "terminal_phase3_selection_receipt"
        )
        if terminal_outcome == _PHASE3_NO_POSITIVE_TERMINAL_OUTCOME:
            if (
                not isinstance(phase3_terminal_receipt, Mapping)
                or continuation_phase3_terminal_receipt
                != phase3_terminal_receipt
                or (
                    not replay_rows
                    and int(
                        phase3_terminal_receipt.get(
                            "accepted_controller_round",
                            -1,
                        )
                    )
                    != 0
                )
            ):
                raise ValueError(
                    "Phase-III terminal receipt is missing or detached from "
                    "continuation."
                )
            native_contract = route_contract.get("native_semantic_contract")
            terminal_checkpoint = self._record.get(
                "terminal_active_prefix_checkpoint"
            )
            if (
                not isinstance(native_contract, Mapping)
                or not isinstance(terminal_checkpoint, Mapping)
            ):
                raise ValueError(
                    "Phase-III terminal finalization requires its authenticated "
                    "V2 route and terminal checkpoint."
                )
            from pipelines.static_adapt.ra_adapt.semantic_closure_routes import (
                validate_semantic_phase3_no_positive_terminal_receipt,
            )

            try:
                validate_semantic_phase3_no_positive_terminal_receipt(
                    phase3_terminal_receipt,
                    route_variant=str(native_contract.get("route_variant", "")),
                    route_contract=route_contract,
                    expected_route_contract_sha256=route_contract_sha256,
                    accepted_round_count=len(replay_rows),
                    terminal_active_prefix_checkpoint=terminal_checkpoint,
                    finalization=self._record.to_mutable_mapping(),
                )
            except (TypeError, ValueError, RuntimeError) as exc:
                raise ValueError(
                    "Phase-III terminal finalization requires independently "
                    "authenticated V2 route and receipt evidence."
                ) from exc
        elif (
            phase3_terminal_receipt is not None
            or continuation_phase3_terminal_receipt is not None
        ):
            raise ValueError(
                "Phase-III terminal receipt requires its exact terminal "
                "outcome."
            )
        combinatorial_terminal_receipt = self._record.get(
            "terminal_combinatorial_batch_exhaustion_receipt"
        )
        continuation_combinatorial_terminal_receipt = continuation.get(
            "terminal_combinatorial_batch_exhaustion_receipt"
        )
        if (
            terminal_outcome
            == COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTED_OUTCOME
        ):
            terminal_checkpoint = self._record.get(
                "terminal_active_prefix_checkpoint"
            )
            if (
                not replay_rows
                or not isinstance(combinatorial_terminal_receipt, Mapping)
                or continuation_combinatorial_terminal_receipt
                != combinatorial_terminal_receipt
                or not isinstance(terminal_checkpoint, Mapping)
            ):
                raise ValueError(
                    "Combinatorial exhaustion finalization lost its accepted "
                    "prefix or terminal receipt."
                )
            try:
                validate_rank_gate_exhaustion_receipt(
                    combinatorial_terminal_receipt,
                    route_contract=route_contract,
                )
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    "Combinatorial exhaustion finalization is not "
                    "independently authenticated."
                ) from exc
        elif (
            combinatorial_terminal_receipt is not None
            or continuation_combinatorial_terminal_receipt is not None
        ):
            raise ValueError(
                "Combinatorial exhaustion receipt requires its exact "
                "terminal outcome."
            )
        object.__setattr__(self, "route_family", route_family)
        object.__setattr__(self, "route_profile", route_profile)
        object.__setattr__(
            self,
            "route_contract",
            _ImmutableProjectionRecord(route_contract),
        )
        object.__setattr__(
            self,
            "route_contract_sha256",
            route_contract_sha256,
        )
        object.__setattr__(self, "history", tuple(replay_rows))
        object.__setattr__(
            self,
            "estimator_call_accounting",
            _ImmutableProjectionRecord(accounting),
        )
        object.__setattr__(
            self,
            "continuation",
            _ImmutableProjectionRecord(continuation),
        )

    def to_serialization_mapping(self) -> dict[str, Any]:
        """Return consumer-required controller fields for observation I/O.

        This is not the historical executor's full diagnostic union.  Reachability
        and retirement of omitted diagnostics remain explicit Issue-20 debt.
        """

        return self._record.to_mutable_mapping()


class _DefaultControllerNumericalRuntime(Protocol):
    """Direct numerical and observation boundary for the exact default."""

    initial_accepted_state: _AcceptedStateSnapshot

    def prepare_selection(
        self,
        state: _AcceptedStateSnapshot,
    ) -> _PreparedSelection: ...

    def prepare_transition(
        self,
        state: _AcceptedStateSnapshot,
        decision: (
            _SingletonAdmissionDecision
            | _GreedyBatchAdmissionDecision
            | _CombinatorialBatchAdmissionDecision
        ),
    ) -> _TransitionWorkspace: ...

    def project_accepted_event(
        self,
        event: _CheckpointReadyAcceptedStateEvent,
        transition: (
            _AcceptedSingletonTransition
            | _AcceptedGreedyBatchTransition
            | _AcceptedCombinatorialBatchTransition
        ),
    ) -> _ProjectedAcceptedRound: ...

    def finalize(
        self,
        *,
        final_state: _AcceptedStateSnapshot,
        transitions: tuple[
            _AcceptedSingletonTransition
            | _AcceptedGreedyBatchTransition
            | _AcceptedCombinatorialBatchTransition,
            ...,
        ],
        events: tuple[_CheckpointReadyAcceptedStateEvent, ...],
        projected_rounds: tuple[_ProjectedAcceptedRound, ...],
        stop: StopReceipt,
    ) -> _DefaultControllerFinalization: ...

    def finalize_stationary_phase0(
        self,
        *,
        final_state: _AcceptedStateSnapshot,
        transitions: tuple[
            _AcceptedSingletonTransition
            | _AcceptedGreedyBatchTransition
            | _AcceptedCombinatorialBatchTransition,
            ...,
        ],
        events: tuple[_CheckpointReadyAcceptedStateEvent, ...],
        projected_rounds: tuple[_ProjectedAcceptedRound, ...],
        phase0: Any,
        stop: StopReceipt,
    ) -> _DefaultControllerFinalization: ...

    def finalize_no_admission(
        self,
        *,
        final_state: _AcceptedStateSnapshot,
        transitions: tuple[
            _AcceptedSingletonTransition
            | _AcceptedGreedyBatchTransition
            | _AcceptedCombinatorialBatchTransition,
            ...,
        ],
        events: tuple[_CheckpointReadyAcceptedStateEvent, ...],
        projected_rounds: tuple[_ProjectedAcceptedRound, ...],
        terminal_selection: _NoPositivePhaseIIISelection,
        stop: StopReceipt,
    ) -> _DefaultControllerFinalization: ...

    def finalize_combinatorial_batch_exhaustion(
        self,
        *,
        final_state: _AcceptedStateSnapshot,
        transitions: tuple[
            _AcceptedSingletonTransition
            | _AcceptedGreedyBatchTransition
            | _AcceptedCombinatorialBatchTransition,
            ...,
        ],
        events: tuple[_CheckpointReadyAcceptedStateEvent, ...],
        projected_rounds: tuple[_ProjectedAcceptedRound, ...],
        terminal_selection: _ExhaustedCombinatorialBatchSelection,
        stop: StopReceipt,
    ) -> _DefaultControllerFinalization: ...

    def fork_beam_branch(
        self,
        state: _AcceptedStateSnapshot,
        *,
        branch_id: str,
        parent_branch_id: str | None,
        excluded_pool_indices: Sequence[int] = (),
    ) -> tuple[
        _DefaultControllerNumericalRuntime,
        _AcceptedStateSnapshot,
    ]: ...

    def beam_sibling_diversity_receipt(
        self,
        state: _AcceptedStateSnapshot,
        decision: (
            _SingletonAdmissionDecision
            | _GreedyBatchAdmissionDecision
            | _CombinatorialBatchAdmissionDecision
        ),
    ) -> Mapping[str, Any] | None: ...

    def clear_beam_branch_context(self) -> None: ...

    def beam_executed_s_alg(self) -> int: ...

    def beam_executed_s_alg_components(
        self,
    ) -> tuple[tuple[str, int], ...]: ...

    def beam_resume_seed(self) -> tuple[tuple[str, ...], int]: ...

    def configure_beam_winner(
        self,
        *,
        winning_branch_ids: Sequence[str],
        diagnostics: Mapping[str, Any],
        observation_owner: _DefaultControllerNumericalRuntime,
    ) -> None: ...

    def close(self) -> None: ...


@dataclass(frozen=True, slots=True)
class _AcceptedPrefixAllWork:
    """Cumulative all-executed estimator work closed after one round."""

    components: tuple[tuple[str, int], ...]
    s_alg: int

    def __post_init__(self) -> None:
        values = dict(self.components)
        if (
            len(values) != len(self.components)
            or any(int(value) < 0 for value in values.values())
            or sum(int(value) for value in values.values()) != int(self.s_alg)
        ):
            raise ValueError(
                "Accepted-prefix all-work components must be unique, "
                "nonnegative, and close to S_alg."
            )

    @classmethod
    def from_transition(
        cls,
        transition: (
            _AcceptedSingletonTransition
            | _AcceptedGreedyBatchTransition
            | _AcceptedCombinatorialBatchTransition
        ),
    ) -> "_AcceptedPrefixAllWork":
        return cls(
            components=tuple(
                (str(name), int(value))
                for name, value in (
                    transition.ledger.cumulative_s_alg_components
                )
            ),
            s_alg=int(transition.ledger.cumulative_s_alg),
        )


@dataclass(frozen=True, slots=True)
class _ControllerOutcome:
    """Frozen in-memory outcome consumed by the default facade runner."""

    initial_state: _AcceptedStateSnapshot
    final_state: _AcceptedStateSnapshot
    accepted_states: tuple[_AcceptedStateSnapshot, ...]
    transitions: tuple[
        _AcceptedSingletonTransition
        | _AcceptedGreedyBatchTransition
        | _AcceptedCombinatorialBatchTransition,
        ...,
    ]
    events: tuple[_CheckpointReadyAcceptedStateEvent, ...]
    projected_rounds: tuple[_ProjectedAcceptedRound, ...]
    accepted_prefix_all_work: tuple[_AcceptedPrefixAllWork, ...]
    stop: StopReceipt
    finalization: _DefaultControllerFinalization

    def __post_init__(self) -> None:
        if not isinstance(
            self.finalization,
            _DefaultControllerFinalization,
        ):
            raise TypeError(
                "controller outcome requires its typed finalization"
            )
        cardinalities = {
            len(self.accepted_states),
            len(self.transitions),
            len(self.events),
            len(self.projected_rounds),
            len(self.accepted_prefix_all_work),
        }
        if len(cardinalities) != 1:
            raise ValueError(
                "accepted states, transitions, events, and projections must "
                "be one-to-one"
            )
        if self.accepted_states:
            if self.accepted_states[-1] != self.final_state:
                raise ValueError(
                    "final state must be the last accepted trajectory state"
                )
        elif self.final_state != self.initial_state:
            raise ValueError(
                "an empty controller trajectory must retain its initial state"
            )


@dataclass(frozen=True, slots=True)
class _ForkLocalBeamBranch:
    """One live accepted lineage in the canonical bounded beam."""

    runtime: _DefaultControllerNumericalRuntime = field(repr=False)
    state: _AcceptedStateSnapshot
    accepted_states: tuple[_AcceptedStateSnapshot, ...]
    transitions: tuple[
        _AcceptedSingletonTransition
        | _AcceptedGreedyBatchTransition
        | _AcceptedCombinatorialBatchTransition,
        ...,
    ]
    events: tuple[_CheckpointReadyAcceptedStateEvent, ...]
    projected_rounds: tuple[_ProjectedAcceptedRound, ...]
    branch_ids: tuple[str, ...]
    lineage_s_alg: int
    comparison_score: float
    stop: StopReceipt | None

    def __post_init__(self) -> None:
        cardinalities = {
            len(self.accepted_states),
            len(self.transitions),
            len(self.events),
            len(self.projected_rounds),
            len(self.branch_ids),
        }
        if len(cardinalities) != 1:
            raise ValueError(
                "Beam lineage states, transitions, events, projections, and "
                "branch IDs must be one-to-one."
            )
        if self.lineage_s_alg < 0:
            raise ValueError("Beam lineage S_alg must be nonnegative.")


def _selection_state_matches_accepted(
    selection: _SRControllerState,
    accepted: _AcceptedStateSnapshot,
) -> bool:
    """Compare the shared immutable cursor fields across the two seams."""

    return (
        selection.controller_round == accepted.controller_round
        and selection.accepted_operator_ids == accepted.accepted_operator_ids
        and selection.accepted_insertion_positions
        == accepted.accepted_insertion_positions
        and selection.logical_parameter_ids == accepted.logical_parameter_ids
        and selection.logical_parameter_values
        == accepted.logical_parameter_values
        and selection.runtime_parameter_ids == accepted.runtime_parameter_ids
        and selection.runtime_parameter_values
        == accepted.runtime_parameter_values
        and math.isclose(
            selection.accepted_energy,
            accepted.accepted_energy,
            rel_tol=0.0,
            abs_tol=(
                128.0
                * math.ulp(
                    max(
                        1.0,
                        abs(selection.accepted_energy),
                        abs(accepted.accepted_energy),
                    )
                )
            ),
        )
        and selection.accepted_state_fingerprint
        == accepted.accepted_state_fingerprint
        and selection.available_generator_ids
        == accepted.available_generator_ids
        and selection.selection_counts == accepted.selection_counts
        and selection.trust_state_identity == accepted.trust_state_identity
        and selection.optimizer_memory_identity
        == accepted.optimizer_memory_identity
        and selection.estimator_prefix_identity
        == accepted.estimator_prefix_identity
    )


def _configured_stop_receipt(
    policy: SRStopPolicy,
    accepted_state: _AcceptedStateSnapshot,
    *,
    accepted_states: tuple[_AcceptedStateSnapshot, ...] = (),
) -> StopReceipt:
    """Evaluate every configured condition on one post-transition state."""

    completed = int(accepted_state.controller_round)
    maximum_fired = completed >= int(policy.maximum_controller_rounds)
    exact = policy.exact_ed_target
    exact_difference = (
        None
        if exact is None
        else abs(
            float(accepted_state.accepted_energy)
            - float(exact.energy)
        )
    )
    exact_hit_rounds = (
        ()
        if exact is None
        else tuple(
            int(state.controller_round)
            for state in accepted_states
            if int(state.controller_round) > 0
            and abs(float(state.accepted_energy) - float(exact.energy))
            <= float(exact.absolute_tolerance)
        )
    )
    exact_first_hit_round = (
        None if not exact_hit_rounds else min(exact_hit_rounds)
    )
    exact_fired = bool(
        exact is not None
        and exact_first_hit_round is not None
        and exact_difference is not None
        and exact_difference <= float(exact.absolute_tolerance)
        and completed
        >= exact_first_hit_round
        + int(exact.confirmation_controller_rounds)
    )

    conditions = [
        StopConditionReceipt(
            reason="maximum_controller_rounds",
            active=True,
            fired=maximum_fired,
        )
    ]
    if exact is not None:
        conditions.append(
            StopConditionReceipt(
                reason="exact_ed_target_reached",
                active=True,
                fired=exact_fired,
            )
        )

    fired_reasons: list[str] = []
    if exact_fired:
        fired_reasons.append("exact_ed_target_reached")
    if maximum_fired:
        fired_reasons.append("maximum_controller_rounds")
    primary_reason = (
        fired_reasons[0] if fired_reasons else "controller_continues"
    )
    return StopReceipt(
        conditions=tuple(conditions),
        completed_controller_rounds=completed,
        accepted_operator_count=len(
            accepted_state.accepted_operator_ids
        ),
        primary_reason=primary_reason,
        fired_reasons=tuple(fired_reasons),
        accepted_energy=float(accepted_state.accepted_energy),
        exact_target_energy=(None if exact is None else float(exact.energy)),
        exact_absolute_tolerance=(
            None
            if exact is None
            else float(exact.absolute_tolerance)
        ),
        exact_observed_absolute_difference=exact_difference,
        exact_source=(None if exact is None else exact.source),
        exact_confirmation_controller_rounds=(
            None
            if exact is None
            else int(exact.confirmation_controller_rounds)
        ),
        exact_first_hit_controller_round=exact_first_hit_round,
    )


def _phase0_stationary_stop_receipt(
    accepted_state: _AcceptedStateSnapshot,
    *,
    phase0: Any,
) -> StopReceipt:
    """Close a valid empty Phase-0 competition without a fake transition."""

    if (
        getattr(phase0, "terminal_outcome", None)
        != _PHASE0_STATIONARY_TERMINAL_OUTCOME
        or tuple(getattr(phase0, "shortlist", ()))
    ):
        raise RuntimeError("stationary controller stop lost its Phase0 receipt")
    return StopReceipt(
        conditions=(
            StopConditionReceipt(
                reason="phase0_stationary",
                active=True,
                fired=True,
            ),
        ),
        completed_controller_rounds=int(accepted_state.controller_round),
        accepted_operator_count=len(accepted_state.accepted_operator_ids),
        primary_reason="phase0_stationary",
        fired_reasons=("phase0_stationary",),
        accepted_energy=float(accepted_state.accepted_energy),
        terminal_controller_outcome=(
            _PHASE0_STATIONARY_TERMINAL_OUTCOME
        ),
    )


def _phase3_no_positive_stop_receipt(
    accepted_state: _AcceptedStateSnapshot,
    *,
    terminal_selection: _NoPositivePhaseIIISelection,
) -> StopReceipt:
    """Close an authenticated Phase-III competition without admission."""

    terminal_selection.validate_natural_terminal_authority()
    phase3 = terminal_selection.phase_iii
    if (
        phase3.terminal_outcome
        != _PHASE3_NO_POSITIVE_TERMINAL_OUTCOME
        or phase3.shortlist
        or phase3.adaptive_shortlist is None
        or phase3.adaptive_shortlist.status != "no_positive_population"
        or phase3.adaptive_shortlist.retained_record_ids
    ):
        raise RuntimeError(
            "no-admission controller stop lost its Phase-III receipt"
        )
    reason = "phase_iii_no_positive_feasible_candidate"
    return StopReceipt(
        conditions=(
            StopConditionReceipt(
                reason=reason,
                active=True,
                fired=True,
            ),
        ),
        completed_controller_rounds=int(accepted_state.controller_round),
        accepted_operator_count=len(accepted_state.accepted_operator_ids),
        primary_reason=reason,
        fired_reasons=(reason,),
        accepted_energy=float(accepted_state.accepted_energy),
        terminal_controller_outcome=(
            _PHASE3_NO_POSITIVE_TERMINAL_OUTCOME
        ),
    )


def _combinatorial_rank_gate_exhaustion_stop_receipt(
    accepted_state: _AcceptedStateSnapshot,
    *,
    terminal_selection: _ExhaustedCombinatorialBatchSelection,
) -> StopReceipt:
    """Close an exhaustive post-Phase-III joint rank-gate search."""

    if (
        not terminal_selection.phase_iii.population
        or not terminal_selection.phase_iii.shortlist
        or terminal_selection.phase_iii.terminal_outcome is not None
        or not terminal_selection.exhaustion.identity
    ):
        raise RuntimeError(
            "combinatorial exhaustion stop lost its positive Phase-III "
            "frontier or exhaustive-search receipt"
        )
    reason = COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTION_STOP_REASON
    return StopReceipt(
        conditions=(
            StopConditionReceipt(reason=reason, active=True, fired=True),
        ),
        completed_controller_rounds=int(accepted_state.controller_round),
        accepted_operator_count=len(accepted_state.accepted_operator_ids),
        primary_reason=reason,
        fired_reasons=(reason,),
        accepted_energy=float(accepted_state.accepted_energy),
        terminal_controller_outcome=(
            COMBINATORIAL_BATCH_RANK_GATE_EXHAUSTED_OUTCOME
        ),
    )


def _assert_projected_event(
    projection: _ProjectedAcceptedRound,
    event: _CheckpointReadyAcceptedStateEvent,
) -> None:
    if (
        int(projection.controller_round) != int(event.controller_round)
        or projection.accepted_state_fingerprint
        != event.accepted_state_fingerprint
    ):
        raise RuntimeError(
            "accepted-event projection identifies a different controller state"
        )


_BRANCH_COMPILED_COST_CACHE: dict[tuple[str, ...], float] = {}


def _branch_compiled_cost_contract(runtime: Any) -> dict[str, Any]:
    """Read the beam's pricing settings off the route contract.

    The branch price has to be the same quantity Phase III scores records by
    and the same quantity the paper reports, so the backend, optimization
    level, transpiler seed and the three weights are taken from the route
    contract rather than restated here -- otherwise a contract change would
    silently leave the beam optimizing the old cost.
    """

    context = getattr(runtime, "context", None)
    contract = getattr(context, "route_contract", None)
    execution = (
        contract.get("execution_settings")
        if isinstance(contract, Mapping)
        else None
    )
    if not isinstance(execution, Mapping):
        raise RuntimeError(
            "Branch-compiled-cost beam requires the route contract's "
            "execution settings."
        )
    backend = str(execution.get("phase3_backend_name") or "")
    if not backend:
        raise RuntimeError(
            "Branch-compiled-cost beam requires a declared compile backend."
        )
    return {
        "backend": backend,
        "optimization_level": int(
            execution["phase3_backend_optimization_level"]
        ),
        "seed_transpiler": int(execution["phase3_backend_transpile_seed"]),
        "weights": {
            "N2q": float(execution["phase3_backend_w_2q"]),
            "D2q": float(execution["phase3_backend_w_depth_2q"]),
            "Dc": float(execution["phase3_backend_w_depth"]),
        },
    }


def _branch_compiled_cost(branch: Any) -> float:
    """Total weighted FakeMarrakesh cost of one branch's accepted prefix.

    This is a branch-versus-branch quantity, not the Phase-III per-record
    factor: it prices the whole compiled prefix a branch has built, so a beam
    that buys the same energy with a cheaper circuit is preferred.
    """

    runtime = branch.runtime
    cursor = getattr(runtime, "cursor", None)
    operators = list(getattr(cursor, "selected_ops", ()) or ())
    if not operators:
        return 0.0
    settings = _branch_compiled_cost_contract(runtime)
    key = (
        settings["backend"],
        str(settings["optimization_level"]),
        str(settings["seed_transpiler"]),
        *(str(op.label) for op in operators),
    )
    cached = _BRANCH_COMPILED_COST_CACHE.get(key)
    if cached is not None:
        return cached
    from pipelines.hardcoded.adapt_circuit_execution import (
        build_structural_ansatz_circuit,
    )
    from pipelines.qiskit_backend_tools import (
        compile_circuit_for_backend,
        compiled_gate_stats,
        resolve_backend_targets,
        safe_circuit_depth,
    )

    context = getattr(runtime, "context", None)
    reference_state = np.asarray(
        getattr(context, "reference_state", None), dtype=complex
    ).reshape(-1)
    num_qubits = int(round(math.log2(reference_state.size)))
    targets, _audit = resolve_backend_targets(
        requested_names=(settings["backend"],),
        preferred_fake_backends=(settings["backend"],),
        allow_preferred_fallback=False,
        fallback_mode="single",
        allow_runtime_lookup=False,
    )
    _layout, circuit = build_structural_ansatz_circuit(
        operators,
        nq=num_qubits,
        ref_state=reference_state,
        structure_theta_value=1.0,
    )
    compiled = compile_circuit_for_backend(
        circuit,
        targets[0].backend_obj,
        seed_transpiler=settings["seed_transpiler"],
        optimization_level=settings["optimization_level"],
        initial_layout=None,
    )["compiled"]
    stats = compiled_gate_stats(compiled)
    weights = settings["weights"]
    total = (
        weights["N2q"] * float(stats["compiled_count_2q"])
        + weights["D2q"] * float(stats["compiled_depth_2q"])
        + weights["Dc"] * float(safe_circuit_depth(compiled))
    )
    _BRANCH_COMPILED_COST_CACHE[key] = total
    return total


def _branch_relative_cost_factors(costs: list[float]) -> list[float]:
    """Paper-I K construction applied across sibling branches.

    Median-centred, MAD-scaled, squashed through arctan into [-1, 1], then
    K = 2 / (2 - Cbar): unity at the median branch, 2/3 for the cheapest and
    2 for the dearest, so the factor discounts cheap branches and penalises
    expensive ones exactly as the phase scores do for records.
    """

    if not costs:
        return []
    ordered = sorted(costs)
    middle = len(ordered) // 2
    median = (
        ordered[middle]
        if len(ordered) % 2
        else 0.5 * (ordered[middle - 1] + ordered[middle])
    )
    deviations = sorted(abs(value - median) for value in costs)
    mid = len(deviations) // 2
    scale = (
        deviations[mid]
        if len(deviations) % 2
        else 0.5 * (deviations[mid - 1] + deviations[mid])
    )
    if not math.isfinite(scale) or scale <= 0.0:
        # Siblings tie often -- many generators compile to the same cost --
        # and a majority tie drives the median absolute deviation to zero.
        # Falling straight through to "no discrimination" would silently
        # switch the whole cost comparison off for that round, so fall back
        # to the mean absolute deviation, which only vanishes when every
        # branch really does cost the same.
        scale = sum(deviations) / len(deviations)
    if not math.isfinite(scale) or scale <= 0.0:
        return [1.0] * len(costs)
    factors = []
    for value in costs:
        c_bar = (2.0 / math.pi) * math.atan((value - median) / scale)
        factors.append(2.0 / (2.0 - c_bar))
    return factors


def _run_default_singleton_controller(
    runtime: _DefaultControllerNumericalRuntime,
    stop_policy: SRStopPolicy,
) -> _ControllerOutcome:
    """Run the exact singleton controller to a configured stop."""

    if not isinstance(stop_policy, SRStopPolicy):
        raise TypeError("stop_policy must be an SRStopPolicy")

    initial_state = runtime.initial_accepted_state
    state = initial_state
    accepted_states: list[_AcceptedStateSnapshot] = []
    transitions: list[_AcceptedSingletonTransition] = []
    events: list[_CheckpointReadyAcceptedStateEvent] = []
    projected_rounds: list[_ProjectedAcceptedRound] = []

    try:
        while True:
            prepared_selection = runtime.prepare_selection(state)
            if not _selection_state_matches_accepted(
                prepared_selection.controller_state,
                state,
            ):
                raise RuntimeError(
                    "prepared selection identifies a different accepted state"
                )
            try:
                decision = _select_singleton(
                    prepared_selection.controller_state,
                    prepared_selection.workspace,
                )
            except _StationaryPhase0Selection as stationary:
                stop = _phase0_stationary_stop_receipt(
                    state,
                    phase0=stationary.receipt,
                )
                transitions_tuple = tuple(transitions)
                events_tuple = tuple(events)
                projected_tuple = tuple(projected_rounds)
                finalization = runtime.finalize_stationary_phase0(
                    final_state=state,
                    transitions=transitions_tuple,
                    events=events_tuple,
                    projected_rounds=projected_tuple,
                    phase0=stationary.receipt,
                    stop=stop,
                )
                return _ControllerOutcome(
                    initial_state=initial_state,
                    final_state=state,
                    accepted_states=tuple(accepted_states),
                    transitions=transitions_tuple,
                    events=events_tuple,
                    projected_rounds=projected_tuple,
                    accepted_prefix_all_work=tuple(
                        _AcceptedPrefixAllWork.from_transition(transition)
                        for transition in transitions_tuple
                    ),
                    stop=stop,
                    finalization=finalization,
                )
            except _NoPositivePhaseIIISelection as exhausted:
                stop = _phase3_no_positive_stop_receipt(
                    state,
                    terminal_selection=exhausted,
                )
                transitions_tuple = tuple(transitions)
                events_tuple = tuple(events)
                projected_tuple = tuple(projected_rounds)
                finalization = runtime.finalize_no_admission(
                    final_state=state,
                    transitions=transitions_tuple,
                    events=events_tuple,
                    projected_rounds=projected_tuple,
                    terminal_selection=exhausted,
                    stop=stop,
                )
                return _ControllerOutcome(
                    initial_state=initial_state,
                    final_state=state,
                    accepted_states=tuple(accepted_states),
                    transitions=transitions_tuple,
                    events=events_tuple,
                    projected_rounds=projected_tuple,
                    accepted_prefix_all_work=tuple(
                        _AcceptedPrefixAllWork.from_transition(transition)
                        for transition in transitions_tuple
                    ),
                    stop=stop,
                    finalization=finalization,
                )
            transition_workspace = runtime.prepare_transition(
                state,
                decision,
            )
            transition = _transition_singleton(
                state,
                decision,
                transition_workspace,
            )

            # The projection must complete before the round becomes public.
            # This preserves event -> history -> active-prefix projection
            # ordering and prevents a partial observation failure from
            # publishing a transition.
            projection = runtime.project_accepted_event(
                transition.checkpoint_event,
                transition,
            )
            _assert_projected_event(
                projection,
                transition.checkpoint_event,
            )

            state = transition.next_state
            accepted_states.append(state)
            transitions.append(transition)
            events.append(transition.checkpoint_event)
            projected_rounds.append(projection)

            stop = _configured_stop_receipt(
                stop_policy,
                state,
                accepted_states=tuple(accepted_states),
            )
            if stop.fired_reasons:
                break

        transitions_tuple = tuple(transitions)
        events_tuple = tuple(events)
        projected_tuple = tuple(projected_rounds)
        finalization = runtime.finalize(
            final_state=state,
            transitions=transitions_tuple,
            events=events_tuple,
            projected_rounds=projected_tuple,
            stop=stop,
        )
        return _ControllerOutcome(
            initial_state=initial_state,
            final_state=state,
            accepted_states=tuple(accepted_states),
            transitions=transitions_tuple,
            events=events_tuple,
            projected_rounds=projected_tuple,
            accepted_prefix_all_work=tuple(
                _AcceptedPrefixAllWork.from_transition(transition)
                for transition in transitions_tuple
            ),
            stop=stop,
            finalization=finalization,
        )
    finally:
        runtime.close()


def _run_default_batch_controller(
    runtime: _DefaultControllerNumericalRuntime,
    stop_policy: SRStopPolicy,
    *,
    select_batch: Callable[
        [_SRControllerState, _SelectionWorkspace],
        _GreedyBatchAdmissionDecision
        | _CombinatorialBatchAdmissionDecision,
    ],
    transition_batch: Callable[
        [
            _AcceptedStateSnapshot,
            _GreedyBatchAdmissionDecision
            | _CombinatorialBatchAdmissionDecision,
            _TransitionWorkspace,
        ],
        _AcceptedGreedyBatchTransition
        | _AcceptedCombinatorialBatchTransition,
    ],
    allow_rank_gate_exhaustion: bool = False,
) -> _ControllerOutcome:
    """Run one ordered-batch strategy as one transition per round."""

    if not isinstance(stop_policy, SRStopPolicy):
        raise TypeError("stop_policy must be an SRStopPolicy")

    initial_state = runtime.initial_accepted_state
    state = initial_state
    accepted_states: list[_AcceptedStateSnapshot] = []
    transitions: list[
        _AcceptedGreedyBatchTransition
        | _AcceptedCombinatorialBatchTransition
    ] = []
    events: list[_CheckpointReadyAcceptedStateEvent] = []
    projected_rounds: list[_ProjectedAcceptedRound] = []

    try:
        while True:
            prepared_selection = runtime.prepare_selection(state)
            if not _selection_state_matches_accepted(
                prepared_selection.controller_state,
                state,
            ):
                raise RuntimeError(
                    "prepared selection identifies a different accepted state"
                )
            try:
                decision = select_batch(
                    prepared_selection.controller_state,
                    prepared_selection.workspace,
                )
            except _ExhaustedCombinatorialBatchSelection as exhausted:
                if not allow_rank_gate_exhaustion:
                    raise
                stop = _combinatorial_rank_gate_exhaustion_stop_receipt(
                    state,
                    terminal_selection=exhausted,
                )
                transitions_tuple = tuple(transitions)
                events_tuple = tuple(events)
                projected_tuple = tuple(projected_rounds)
                finalization = (
                    runtime.finalize_combinatorial_batch_exhaustion(
                        final_state=state,
                        transitions=transitions_tuple,
                        events=events_tuple,
                        projected_rounds=projected_tuple,
                        terminal_selection=exhausted,
                        stop=stop,
                    )
                )
                return _ControllerOutcome(
                    initial_state=initial_state,
                    final_state=state,
                    accepted_states=tuple(accepted_states),
                    transitions=transitions_tuple,
                    events=events_tuple,
                    projected_rounds=projected_tuple,
                    accepted_prefix_all_work=tuple(
                        _AcceptedPrefixAllWork.from_transition(transition)
                        for transition in transitions_tuple
                    ),
                    stop=stop,
                    finalization=finalization,
                )
            transition_workspace = runtime.prepare_transition(
                state,
                decision,
            )
            transition = transition_batch(
                state,
                decision,
                transition_workspace,
            )

            projection = runtime.project_accepted_event(
                transition.checkpoint_event,
                transition,
            )
            _assert_projected_event(
                projection,
                transition.checkpoint_event,
            )

            state = transition.next_state
            accepted_states.append(state)
            transitions.append(transition)
            events.append(transition.checkpoint_event)
            projected_rounds.append(projection)

            stop = _configured_stop_receipt(
                stop_policy,
                state,
                accepted_states=tuple(accepted_states),
            )
            if stop.fired_reasons:
                break

        transitions_tuple = tuple(transitions)
        events_tuple = tuple(events)
        projected_tuple = tuple(projected_rounds)
        finalization = runtime.finalize(
            final_state=state,
            transitions=transitions_tuple,
            events=events_tuple,
            projected_rounds=projected_tuple,
            stop=stop,
        )
        return _ControllerOutcome(
            initial_state=initial_state,
            final_state=state,
            accepted_states=tuple(accepted_states),
            transitions=transitions_tuple,
            events=events_tuple,
            projected_rounds=projected_tuple,
            accepted_prefix_all_work=tuple(
                _AcceptedPrefixAllWork.from_transition(transition)
                for transition in transitions_tuple
            ),
            stop=stop,
            finalization=finalization,
        )
    finally:
        runtime.close()


def _run_default_greedy_batch_controller(
    runtime: _DefaultControllerNumericalRuntime,
    stop_policy: SRStopPolicy,
    admission: GreedyBatchAdmission,
) -> _ControllerOutcome:
    """Run the greedy route with one atomic batch transition per round."""

    if not isinstance(stop_policy, SRStopPolicy):
        raise TypeError("stop_policy must be an SRStopPolicy")
    if not isinstance(admission, GreedyBatchAdmission):
        raise TypeError("admission must be a GreedyBatchAdmission")

    def _select(
        state: _SRControllerState,
        workspace: _SelectionWorkspace,
    ) -> _GreedyBatchAdmissionDecision:
        return _select_greedy_batch(
            state,
            workspace,
            maximum_size=admission.maximum_size,
            search_window_size=admission.search_window_size,
        )

    return _run_default_batch_controller(
        runtime,
        stop_policy,
        select_batch=_select,
        transition_batch=_transition_greedy_batch,
    )


def _run_default_combinatorial_batch_controller(
    runtime: _DefaultControllerNumericalRuntime,
    stop_policy: SRStopPolicy,
    admission: CombinatorialBatchAdmission,
) -> _ControllerOutcome:
    """Run the exhaustive-subset route with one atomic round transition."""

    if not isinstance(stop_policy, SRStopPolicy):
        raise TypeError("stop_policy must be an SRStopPolicy")
    if not isinstance(admission, CombinatorialBatchAdmission):
        raise TypeError(
            "admission must be a CombinatorialBatchAdmission"
        )

    def _select(
        state: _SRControllerState,
        workspace: _SelectionWorkspace,
    ) -> _CombinatorialBatchAdmissionDecision:
        return _select_combinatorial_batch(
            state,
            workspace,
            maximum_size=admission.maximum_size,
            search_window_size=(
                admission.resolved_search_window_size
            ),
        )

    return _run_default_batch_controller(
        runtime,
        stop_policy,
        select_batch=_select,
        transition_batch=_transition_combinatorial_batch,
        allow_rank_gate_exhaustion=True,
    )


def _beam_branch_sort_key(
    branch: _ForkLocalBeamBranch,
) -> tuple[float, float, int, tuple[str, ...]]:
    """Return the deterministic settled fork-local comparison key."""

    return (
        float(branch.comparison_score),
        float(branch.state.accepted_energy),
        int(branch.lineage_s_alg),
        tuple(branch.branch_ids),
    )


def _run_default_fork_local_beam_controller(
    runtime: _DefaultControllerNumericalRuntime,
    stop_policy: SRStopPolicy,
    admission: (
        SingletonAdmission
        | GreedyBatchAdmission
        | CombinatorialBatchAdmission
    ),
    beam: ForkLocalBeam,
) -> _ControllerOutcome:
    """Run the bounded direct-controller beam with global work accounting.

    Every parent is replaced by accepted children.  No unchanged parent is
    retained, every evaluated child remains in the shared estimator ledger,
    and only the selected lineage is projected as the scientific trajectory.
    """

    if not isinstance(stop_policy, SRStopPolicy):
        raise TypeError("stop_policy must be an SRStopPolicy")
    if not isinstance(
        admission,
        (
            SingletonAdmission,
            GreedyBatchAdmission,
            CombinatorialBatchAdmission,
        ),
    ):
        raise TypeError("beam admission policy has the wrong type")
    if not isinstance(beam, ForkLocalBeam):
        raise TypeError("beam must be a ForkLocalBeam")

    initial_state = runtime.initial_accepted_state
    _beam_comparison_mode = resolved_beam_comparison(beam)
    initial_s_alg = int(runtime.beam_executed_s_alg())
    resume_branch_ids, resume_lineage_s_alg = runtime.beam_resume_seed()
    frontier = [
        _ForkLocalBeamBranch(
            runtime=runtime,
            state=initial_state,
            accepted_states=(),
            transitions=(),
            events=(),
            projected_rounds=(),
            branch_ids=(),
            lineage_s_alg=int(resume_lineage_s_alg),
            comparison_score=(
                0.0
                if beam_comparison_carries_recorded_score(beam)
                else float(
                    initial_state.accepted_energy
                    + float(beam.s_alg_weight) * resume_lineage_s_alg
                )
            ),
            stop=None,
        )
    ]
    branch_counter = 0
    round_audits: list[dict[str, Any]] = []
    accepted_prefix_all_work: list[_AcceptedPrefixAllWork] = []
    winner: _ForkLocalBeamBranch | None = None
    owned_children: list[_DefaultControllerNumericalRuntime] = []

    def _close_owned_child(
        child: _DefaultControllerNumericalRuntime,
    ) -> None:
        if child is runtime:
            return
        for index, owned_child in enumerate(owned_children):
            if owned_child is child:
                del owned_children[index]
                child.close()
                return

    def _select(
        prepared: _PreparedSelection,
    ) -> (
        _SingletonAdmissionDecision
        | _GreedyBatchAdmissionDecision
        | _CombinatorialBatchAdmissionDecision
    ):
        if isinstance(admission, GreedyBatchAdmission):
            return _select_greedy_batch(
                prepared.controller_state,
                prepared.workspace,
                maximum_size=admission.maximum_size,
                search_window_size=admission.search_window_size,
            )
        if isinstance(admission, CombinatorialBatchAdmission):
            return _select_combinatorial_batch(
                prepared.controller_state,
                prepared.workspace,
                maximum_size=admission.maximum_size,
                search_window_size=(
                    admission.resolved_search_window_size
                ),
            )
        return _select_singleton(
            prepared.controller_state,
            prepared.workspace,
        )

    def _transition(
        state: _AcceptedStateSnapshot,
        decision: (
            _SingletonAdmissionDecision
            | _GreedyBatchAdmissionDecision
            | _CombinatorialBatchAdmissionDecision
        ),
        workspace: _TransitionWorkspace,
    ) -> (
        _AcceptedSingletonTransition
        | _AcceptedGreedyBatchTransition
        | _AcceptedCombinatorialBatchTransition
    ):
        if isinstance(decision, _GreedyBatchAdmissionDecision):
            return _transition_greedy_batch(state, decision, workspace)
        if isinstance(decision, _CombinatorialBatchAdmissionDecision):
            return _transition_combinatorial_batch(
                state,
                decision,
                workspace,
            )
        return _transition_singleton(state, decision, workspace)

    try:
        while winner is None:
            children: list[_ForkLocalBeamBranch] = []
            child_audit_rows: list[dict[str, Any]] = []
            parent_rows: list[dict[str, Any]] = []
            for parent_index, parent in enumerate(
                sorted(frontier, key=_beam_branch_sort_key)
            ):
                if (
                    len(children)
                    >= beam.maximum_admission_children_per_round
                ):
                    break
                excluded_pool_indices: set[int] = set()
                parent_child_count = 0
                parent_id = (
                    (
                        *resume_branch_ids,
                        *parent.branch_ids,
                    )[-1]
                    if resume_branch_ids or parent.branch_ids
                    else None
                )
                for child_ordinal in range(
                    beam.admission_children_per_parent
                ):
                    if (
                        len(children)
                        >= beam.maximum_admission_children_per_round
                    ):
                        break
                    branch_counter += 1
                    branch_id = (
                        f"canonical_beam:r{int(parent.state.controller_round) + 1}:"
                        f"p{parent_index}:c{child_ordinal}:n{branch_counter}"
                    )
                    before_s_alg = int(runtime.beam_executed_s_alg())
                    child_runtime, child_input_state = (
                        parent.runtime.fork_beam_branch(
                            parent.state,
                            branch_id=branch_id,
                            parent_branch_id=parent_id,
                            excluded_pool_indices=tuple(
                                sorted(excluded_pool_indices)
                            ),
                        )
                    )
                    owned_children.append(child_runtime)
                    try:
                        prepared = child_runtime.prepare_selection(
                            child_input_state
                        )
                        if not _selection_state_matches_accepted(
                            prepared.controller_state,
                            child_input_state,
                        ):
                            raise RuntimeError(
                                "Beam child selection identifies a different "
                                "accepted fork state."
                            )
                        try:
                            decision = _select(prepared)
                        except _StationaryPhase0Selection:
                            # This branch's Phase-0 screen retained nothing:
                            # every generator is non-competitive at the
                            # child's state.  The branch cannot spawn, which
                            # exhausts this parent's sibling population; it is
                            # not an error of the beam.
                            # _close_owned_child also removes the runtime
                            # from owned_children.
                            _close_owned_child(child_runtime)
                            break
                        selected = (
                            decision.selected
                            if isinstance(
                                decision,
                                (
                                    _GreedyBatchAdmissionDecision,
                                    _CombinatorialBatchAdmissionDecision,
                                ),
                            )
                            else (decision.selected,)
                        )
                        selected_pool_indices = tuple(
                            int(value.pool_index) for value in selected
                        )
                        if excluded_pool_indices.intersection(
                            selected_pool_indices
                        ):
                            raise RuntimeError(
                                "Beam siblings selected an excluded admission."
                            )
                        sibling_diversity_receipt_raw = (
                            child_runtime.beam_sibling_diversity_receipt(
                                child_input_state,
                                decision,
                            )
                        )
                        sibling_diversity_receipt = (
                            None
                            if sibling_diversity_receipt_raw is None
                            else _validate_beam_sibling_diversity_receipt(
                                sibling_diversity_receipt_raw,
                                expected_controller_round=int(
                                    child_input_state.controller_round
                                ),
                                expected_parent_state_fingerprint=str(
                                    child_input_state.accepted_state_fingerprint
                                ),
                                expected_selected_pool_indices=(
                                    selected_pool_indices
                                ),
                                expected_population_pool_indices=tuple(
                                    int(record.pool_index)
                                    for record in decision.phase_ii.population
                                ),
                                expected_branch_id=branch_id,
                                expected_parent_branch_id=parent_id,
                            )
                        )
                        sibling_population_exhausted = (
                            sibling_diversity_receipt is not None
                            and int(
                                sibling_diversity_receipt[
                                    "remaining_population_pool_count"
                                ]
                            )
                            == 0
                        )
                        if (
                            sibling_diversity_receipt is not None
                            and sibling_diversity_receipt["parent_branch_id"]
                            != parent_id
                        ):
                            raise RuntimeError(
                                "Beam sibling-diversity parent lineage drifted."
                            )
                        sibling_equivalent_pool_indices = set(
                            selected_pool_indices
                            if sibling_diversity_receipt is None
                            else sibling_diversity_receipt[
                                "excluded_pool_indices"
                            ]
                        )
                        if not sibling_equivalent_pool_indices.issuperset(
                            selected_pool_indices
                        ):
                            raise RuntimeError(
                                "Beam sibling-diversity projection lost the "
                                "selected admission."
                            )
                        transition_workspace = (
                            child_runtime.prepare_transition(
                                child_input_state,
                                decision,
                            )
                        )
                        transition = _transition(
                            child_input_state,
                            decision,
                            transition_workspace,
                        )
                        projection = child_runtime.project_accepted_event(
                            transition.checkpoint_event,
                            transition,
                        )
                        _assert_projected_event(
                            projection,
                            transition.checkpoint_event,
                        )
                    except Exception:
                        child_runtime.clear_beam_branch_context()
                        _close_owned_child(child_runtime)
                        raise
                    child_runtime.clear_beam_branch_context()
                    excluded_pool_indices.update(
                        sibling_equivalent_pool_indices
                    )
                    after_s_alg = int(runtime.beam_executed_s_alg())
                    fork_local_delta = int(after_s_alg - before_s_alg)
                    if fork_local_delta <= 0:
                        raise RuntimeError(
                            "A measured beam child performed no estimator work."
                        )
                    lineage_s_alg = int(
                        parent.lineage_s_alg + fork_local_delta
                    )
                    next_state = transition.next_state
                    if (
                        _beam_comparison_mode
                        == BEAM_COMPARISON_PHASE3_GAIN_OVER_BURDEN
                    ):
                        # Rank by this route's own Phase-III rule: the
                        # trust-region energy gain the admitted generator
                        # bought, per unit compiled burden (1 + K3).  Lower
                        # is better, so the score is the negated ratio.
                        burden = float(decision.predictive_cost.value)
                        if not math.isfinite(burden) or burden <= 0.0:
                            raise RuntimeError(
                                "A beam child has no positive Phase-III "
                                "compiled burden to rank by."
                            )
                        gain = float(
                            parent.state.accepted_energy
                            - next_state.accepted_energy
                        )
                        comparison_score = float(-(gain / burden))
                    else:
                        comparison_score = float(
                            next_state.accepted_energy
                            + float(beam.s_alg_weight) * lineage_s_alg
                        )
                    stop = _configured_stop_receipt(
                        stop_policy,
                        next_state,
                        accepted_states=(
                            *parent.accepted_states,
                            next_state,
                        ),
                    )
                    child = _ForkLocalBeamBranch(
                        runtime=child_runtime,
                        state=next_state,
                        accepted_states=(
                            *parent.accepted_states,
                            next_state,
                        ),
                        transitions=(
                            *parent.transitions,
                            transition,
                        ),
                        events=(
                            *parent.events,
                            transition.checkpoint_event,
                        ),
                        projected_rounds=(
                            *parent.projected_rounds,
                            projection,
                        ),
                        branch_ids=(
                            *parent.branch_ids,
                            branch_id,
                        ),
                        lineage_s_alg=lineage_s_alg,
                        comparison_score=comparison_score,
                        stop=stop,
                    )
                    children.append(child)
                    parent_child_count += 1
                    child_audit_rows.append(
                        {
                            "branch_id": branch_id,
                            "parent_branch_id": parent_id,
                            "accepted_energy": float(
                                next_state.accepted_energy
                            ),
                            "fork_local_s_alg_delta": fork_local_delta,
                            "lineage_s_alg": lineage_s_alg,
                            "comparison_score": comparison_score,
                            "selected_pool_indices": list(
                                selected_pool_indices
                            ),
                            "sibling_diversity_receipt": (
                                None
                                if sibling_diversity_receipt is None
                                else _plain_isolated_copy(
                                    sibling_diversity_receipt
                                )
                            ),
                            "stop_reasons": list(stop.fired_reasons),
                        }
                    )
                    if sibling_population_exhausted:
                        break
                parent_rows.append(
                    {
                        "parent_branch_id": parent_id,
                        "children_executed": parent_child_count,
                        "unchanged_parent_retained": False,
                    }
                )
                if parent.runtime is not runtime:
                    _close_owned_child(parent.runtime)

            if not children:
                raise RuntimeError(
                    "Fork-local beam produced no accepted child."
                )
            pareto_filtered = False
            if beam_comparison_prices_branches(beam):
                # Rank siblings by energy gain per relative compiled burden of
                # the whole branch prefix.  The normalisation needs every
                # sibling, so it happens once the round's children exist.
                costs = [_branch_compiled_cost(child) for child in children]
                # A branch is strictly Pareto dominated when another sibling
                # reaches an energy at least as low through a circuit at least
                # as cheap and is strictly better in one of the two.  Ties
                # survive together, so the undominated set is never empty.
                # Dominated branches stay in the receipt -- they were executed
                # and their work is charged -- but they are excluded from the
                # ranking, so they can neither win the round nor survive it.
                filters_pareto = beam_comparison_filters_pareto(beam)
                undominated = [
                    filters_pareto is False
                    or not any(
                        other != index
                        and children[other].state.accepted_energy
                        <= child.state.accepted_energy
                        and costs[other] <= costs[index]
                        and (
                            children[other].state.accepted_energy
                            < child.state.accepted_energy
                            or costs[other] < costs[index]
                        )
                        for other in range(len(children))
                    )
                    for index, child in enumerate(children)
                ]
                if not any(undominated):
                    raise RuntimeError(
                        "Pareto filtering removed every beam child."
                    )
                factors = _branch_relative_cost_factors(costs)
                rescored = []
                for index, (child, factor) in enumerate(
                    zip(children, factors, strict=True)
                ):
                    # Descent from the run's initial state, not from this
                    # child's own parent: siblings sit under different
                    # parents, and a per-parent gain would flatter the
                    # children of the weakest lineages.  Every branch shares
                    # the initial state, so cumulative descent is the one
                    # quantity comparable across the whole round.
                    gain = float(
                        initial_state.accepted_energy
                        - child.state.accepted_energy
                    )
                    score = float(-(gain / factor))
                    rescored.append(
                        dataclasses.replace(child, comparison_score=score)
                    )
                    # The audit row was written with the energy-ordered score;
                    # restate it so the receipt matches the ranking actually
                    # used, and carry the priced quantities with it.
                    child_audit_rows[index]["comparison_score"] = score
                    child_audit_rows[index]["branch_compiled_cost"] = float(
                        costs[index]
                    )
                    child_audit_rows[index]["branch_cost_factor"] = float(
                        factor
                    )
                    child_audit_rows[index]["branch_energy_gain"] = gain
                    if filters_pareto:
                        child_audit_rows[index]["pareto_dominated"] = (
                            not undominated[index]
                        )
                children = rescored
                ranked_children = sorted(
                    (
                        child
                        for child, keep in zip(
                            children, undominated, strict=True
                        )
                        if keep
                    ),
                    key=_beam_branch_sort_key,
                )
                pareto_filtered = True
            if not pareto_filtered:
                ranked_children = sorted(
                    children, key=_beam_branch_sort_key
                )
            exact_hits = [
                child
                for child in ranked_children
                if child.stop is not None
                and "exact_ed_target_reached"
                in child.stop.fired_reasons
            ]
            maximum_hits = [
                child
                for child in ranked_children
                if child.stop is not None
                and "maximum_controller_rounds"
                in child.stop.fired_reasons
            ]
            if exact_hits:
                winner = exact_hits[0]
                survivor_ids = {id(winner.runtime)}
                terminal_reason = "exact_ed_target_reached"
            elif len(maximum_hits) == len(ranked_children):
                winner = ranked_children[0]
                survivor_ids = {id(winner.runtime)}
                terminal_reason = "maximum_controller_rounds"
            else:
                frontier = ranked_children[
                    : beam.live_parent_branches
                ]
                survivor_ids = {
                    id(branch.runtime) for branch in frontier
                }
                terminal_reason = None
            for child in children:
                if id(child.runtime) not in survivor_ids:
                    _close_owned_child(child.runtime)
            round_audits.append(
                {
                    "controller_round": int(
                        ranked_children[0].state.controller_round
                    ),
                    "parent_rows": parent_rows,
                    "children": child_audit_rows,
                    "children_executed": len(children),
                    "survivor_branch_ids": [
                        branch.branch_ids[-1]
                        for branch in (
                            (winner,) if winner is not None else frontier
                        )
                    ],
                    "terminal_reason": terminal_reason,
                }
            )
            all_work_components = (
                runtime.beam_executed_s_alg_components()
            )
            accepted_prefix_all_work.append(
                _AcceptedPrefixAllWork(
                    components=all_work_components,
                    s_alg=int(runtime.beam_executed_s_alg()),
                )
            )

        if winner.stop is None or not winner.stop.fired_reasons:
            raise RuntimeError("Beam winner lacks a configured stop receipt.")
        diagnostics = {
            "schema": "paper_i_canonical_fork_local_beam_search_v1",
            "comparison": beam_comparison_diagnostic_label(beam),
            "s_alg_scope": "fork_local_cumulative_lineage",
            "s_alg_weight": float(beam.s_alg_weight),
            "calibration_status": str(beam.calibration_status),
            "live_parent_branches": int(beam.live_parent_branches),
            "admission_children_per_parent": int(
                beam.admission_children_per_parent
            ),
            "maximum_admission_children_per_round": int(
                beam.maximum_admission_children_per_round
            ),
            "unchanged_parent_survival": False,
            "phase_live_hysteresis": False,
            "initial_unbranched_s_alg": initial_s_alg,
            "resume_winning_branch_ids": list(resume_branch_ids),
            "resume_winning_lineage_s_alg": int(
                resume_lineage_s_alg
            ),
            "all_executed_s_alg": int(runtime.beam_executed_s_alg()),
            "winning_branch_ids": [
                *resume_branch_ids,
                *winner.branch_ids,
            ],
            "winning_lineage_s_alg": int(winner.lineage_s_alg),
            "winning_comparison_score": float(
                winner.comparison_score
            ),
            "rounds": round_audits,
        }
        winner.runtime.configure_beam_winner(
            winning_branch_ids=(
                *resume_branch_ids,
                *winner.branch_ids,
            ),
            diagnostics=diagnostics,
            observation_owner=runtime,
        )
        finalization = winner.runtime.finalize(
            final_state=winner.state,
            transitions=winner.transitions,
            events=winner.events,
            projected_rounds=winner.projected_rounds,
            stop=winner.stop,
        )
        _close_owned_child(winner.runtime)
        return _ControllerOutcome(
            initial_state=initial_state,
            final_state=winner.state,
            accepted_states=winner.accepted_states,
            transitions=winner.transitions,
            events=winner.events,
            projected_rounds=winner.projected_rounds,
            accepted_prefix_all_work=tuple(accepted_prefix_all_work),
            stop=winner.stop,
            finalization=finalization,
        )
    finally:
        for child_runtime in tuple(owned_children):
            try:
                _close_owned_child(child_runtime)
            except Exception:
                # Preserve the controller's scientific/implementation failure;
                # cleanup is best-effort once a fork close itself fails.
                pass
        runtime.clear_beam_branch_context()
        runtime.close()


__all__: list[str] = []
