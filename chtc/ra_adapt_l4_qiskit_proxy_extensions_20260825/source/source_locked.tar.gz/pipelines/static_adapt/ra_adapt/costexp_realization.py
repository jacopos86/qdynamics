"""Tamper-evident receipts for cost-expanded insertion realization.

The commutation reducer authenticates each response class.  This module binds
the member-level routed costs to that partition and proves that the materialized
position is the minimum-penalty member, with the earliest position winning an
exact tie.
"""

from __future__ import annotations

import math
from typing import Any, Mapping

from pipelines.static_adapt.ra_adapt.contracts import canonical_sha256
from pipelines.static_adapt.hh_backend_compile_oracle import (
    BACKEND_COMPILE_SCOPE_PHASE123_QISKIT_V1,
)


COSTEXP_MIN_COST_REALIZATION_EQUIVALENCE = (
    "termwise_cross_component_commutation_min_cost_realization_v1"
)
COSTEXP_CLASS_REALIZATION_RECEIPT_KEY = (
    "costexp_class_realization_receipt"
)
COSTEXP_CLASS_REALIZATION_RECEIPT_SCHEMA = (
    "ra_adapt_costexp_class_realization_receipt_v1"
)
COSTEXP_CLASS_REALIZATION_TIE_BREAK = (
    "minimum_penalty_then_earliest_position_exact_ties_v1"
)
EXPLICIT_DEPTH_QISKIT_COST_POLICY_V1 = "explicit_depth_qiskit_cost_v1"
COSTEXP_PHASE123_QISKIT_SELECTOR_POLICY = (
    "qiskit_full_trial_ansatz_signed_marginal_phase1_phase2_phase3_v1"
)
COSTEXP_SIGNED_POPULATION_NORMALIZATION = "zero_centered_signed_arctan_v1"

# The two cost-expanded campaign arms intentionally inherit the long-standing
# selector penalty rather than the explicit-depth overlay.  Those routes omit
# numeric weights from their contract, so validation must close against these
# source defaults instead of trusting values copied into a scientific receipt.
COSTEXP_INHERITED_SIGNED_PENALTY_WEIGHTS = {
    "penalty_weight_2q": 1.0,
    "penalty_weight_depth_2q": 0.0,
    "penalty_weight_depth": 0.1,
    "penalty_weight_1q": 0.0,
    "penalty_weight_size": 0.01,
}

_ROUTED_INPUT_TO_WEIGHT = {
    "raw_delta_compiled_count_2q": "penalty_weight_2q",
    "raw_delta_compiled_depth_2q": "penalty_weight_depth_2q",
    "raw_delta_compiled_depth": "penalty_weight_depth",
    "raw_delta_compiled_count_1q": "penalty_weight_1q",
    "raw_delta_compiled_size": "penalty_weight_size",
}
_ROUTE_WEIGHT_TO_RECEIPT_WEIGHT = {
    "weight_2q": "penalty_weight_2q",
    "weight_depth_2q": "penalty_weight_depth_2q",
    "weight_depth": "penalty_weight_depth",
    "weight_1q": "penalty_weight_1q",
    "weight_size": "penalty_weight_size",
}


def costexp_penalty_weights_from_route_contract(
    route_contract: Mapping[str, Any],
) -> dict[str, float]:
    """Return the authenticated signed-penalty weights for a costexp route."""

    invariants = route_contract.get("semantic_invariants")
    execution = route_contract.get("execution_settings")
    if not isinstance(invariants, Mapping) or not isinstance(execution, Mapping):
        raise ValueError("Costexp route penalty authority is incomplete.")
    if (
        invariants.get("insertion_equivalence_policy")
        != COSTEXP_MIN_COST_REALIZATION_EQUIVALENCE
        or invariants.get(
            "phase_i_phase_ii_phase_iii_qiskit_negative_delta_reward_enabled"
        )
        is not True
        or invariants.get("phase_i_compile_cost_source")
        != "backend_transpile_v1"
        or invariants.get("phase_ii_compile_cost_source")
        != "backend_transpile_v1"
        or invariants.get("phase_iii_compile_cost_source")
        != "backend_transpile_v1"
        or invariants.get("selector_compile_cost_scope")
        != BACKEND_COMPILE_SCOPE_PHASE123_QISKIT_V1
        or invariants.get("selector_compile_cost_policy")
        != COSTEXP_PHASE123_QISKIT_SELECTOR_POLICY
        or invariants.get(
            "phase_i_phase_ii_phase_iii_qiskit_population_normalization_policy"
        )
        != COSTEXP_SIGNED_POPULATION_NORMALIZATION
        or invariants.get(
            "phase_i_phase_ii_phase_iii_qiskit_backend_fallback_allowed"
        )
        is not False
        or invariants.get(
            "phase_i_phase_ii_phase_iii_qiskit_full_base_trial_ansatz_transpile"
        )
        is not True
        or execution.get("phase3_backend_cost_scope")
        != BACKEND_COMPILE_SCOPE_PHASE123_QISKIT_V1
        or execution.get("phase3_backend_cost_mode")
        != "marrakesh_graph_span_v1"
        or execution.get("phase3_backend_name") != "FakeMarrakesh"
        or execution.get("phase3_backend_optimization_level") != 1
        or execution.get("phase3_backend_transpile_seed") != 7
    ):
        raise ValueError("Costexp route penalty authority is invalid.")

    policy = invariants.get("compile_cost_policy")
    raw_route_weights = invariants.get("compile_cost_weights")
    execution_weight_keys = {
        "phase3_backend_w_2q": "penalty_weight_2q",
        "phase3_backend_w_depth_2q": "penalty_weight_depth_2q",
        "phase3_backend_w_depth": "penalty_weight_depth",
        "phase3_backend_w_1q": "penalty_weight_1q",
        "phase3_backend_w_size": "penalty_weight_size",
    }
    if policy is None:
        if raw_route_weights is not None or any(
            key in execution for key in execution_weight_keys
        ):
            raise ValueError(
                "Inherited costexp penalty must not declare overlay weights."
            )
        return dict(COSTEXP_INHERITED_SIGNED_PENALTY_WEIGHTS)
    if (
        policy != EXPLICIT_DEPTH_QISKIT_COST_POLICY_V1
        or not isinstance(raw_route_weights, Mapping)
        or set(raw_route_weights) != set(_ROUTE_WEIGHT_TO_RECEIPT_WEIGHT)
    ):
        raise ValueError("Costexp compile-cost overlay is invalid.")
    try:
        expected = {
            receipt_key: float(raw_route_weights[route_key])
            for route_key, receipt_key in _ROUTE_WEIGHT_TO_RECEIPT_WEIGHT.items()
        }
    except (TypeError, ValueError) as exc:
        raise ValueError("Costexp routed penalty weights are non-numeric.") from exc
    if any(
        execution.get(execution_key) != expected[receipt_key]
        for execution_key, receipt_key in execution_weight_keys.items()
    ):
        raise ValueError("Costexp execution penalty weights drifted.")
    if not all(
        math.isfinite(value) and value >= 0.0 for value in expected.values()
    ):
        raise ValueError("Costexp routed penalty weights are invalid.")
    return expected


def costexp_signed_penalty_total(
    routed_cost_inputs: Mapping[str, float],
    penalty_weights: Mapping[str, float],
) -> float:
    """Recompute the oracle's signed penalty in its exact operation order."""

    return float(
        penalty_weights["penalty_weight_2q"]
        * routed_cost_inputs["raw_delta_compiled_count_2q"]
        + penalty_weights["penalty_weight_depth"]
        * routed_cost_inputs["raw_delta_compiled_depth"]
        + penalty_weights["penalty_weight_size"]
        * routed_cost_inputs["raw_delta_compiled_size"]
        + penalty_weights["penalty_weight_depth_2q"]
        * routed_cost_inputs["raw_delta_compiled_depth_2q"]
        + penalty_weights["penalty_weight_1q"]
        * routed_cost_inputs["raw_delta_compiled_count_1q"]
    )


def seal_costexp_class_realization_receipt(
    class_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    """Return the canonical digested envelope for normalized class rows."""

    sealed_rows: list[dict[str, Any]] = []
    for raw_row in class_rows:
        row = dict(raw_row)
        member_costs = row.get("member_costs")
        if not isinstance(member_costs, list):
            raise ValueError("Costexp class member costs are missing.")
        row["ordered_member_costs_sha256"] = canonical_sha256(member_costs)
        row["sha256"] = canonical_sha256(row)
        sealed_rows.append(row)
    payload: dict[str, Any] = {
        "schema": COSTEXP_CLASS_REALIZATION_RECEIPT_SCHEMA,
        "equivalence_policy": COSTEXP_MIN_COST_REALIZATION_EQUIVALENCE,
        "selection_rule": COSTEXP_CLASS_REALIZATION_TIE_BREAK,
        "class_count": len(sealed_rows),
        "classes": sealed_rows,
        "ordered_classes_sha256": canonical_sha256(sealed_rows),
    }
    return {**payload, "sha256": canonical_sha256(payload)}


def _integer(value: object, *, owner: str) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{owner} must be an integer.")
    try:
        normalized = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{owner} must be an integer.") from exc
    if normalized < 0:
        raise ValueError(f"{owner} must be non-negative.")
    return normalized


def _position_list(value: object, *, owner: str) -> list[int]:
    if not isinstance(value, list):
        raise ValueError(f"{owner} must be a list.")
    positions = [_integer(item, owner=owner) for item in value]
    if positions != sorted(positions) or len(positions) != len(set(positions)):
        raise ValueError(f"{owner} must be strictly ordered and unique.")
    return positions


def validate_costexp_class_realization_receipt(
    scored_population: Mapping[str, Any],
    reduction_receipt: Mapping[str, Any] | None,
    *,
    route_contract: Mapping[str, Any],
    phase_i_qiskit_receipt: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Validate the realized member argmin against the sealed class partition.

    Activation is derived exclusively from the caller's authenticated route
    equivalence policy.  Non-cost-expanded routes must not carry this receipt.
    The reduction receipt is expected to have passed the full commutation
    certificate validator before this narrower binding is called.
    """

    if not isinstance(scored_population, Mapping):
        raise ValueError("Costexp scored population must be a mapping.")
    raw_receipt = scored_population.get(COSTEXP_CLASS_REALIZATION_RECEIPT_KEY)
    invariants = route_contract.get("semantic_invariants")
    if not isinstance(invariants, Mapping):
        raise ValueError("Costexp route semantic invariants are missing.")
    active = bool(
        str(invariants.get("insertion_equivalence_policy", ""))
        == COSTEXP_MIN_COST_REALIZATION_EQUIVALENCE
    )
    if not active:
        if raw_receipt is not None:
            raise ValueError(
                "A non-cost-expanded route carries costexp realization evidence."
            )
        return None
    if not isinstance(raw_receipt, Mapping):
        raise ValueError("Costexp realization evidence is missing.")
    if not isinstance(reduction_receipt, Mapping):
        raise ValueError(
            "Costexp realization lacks its authenticated class partition."
        )
    expected_weights = costexp_penalty_weights_from_route_contract(
        route_contract
    )

    qiskit_rows: list[Mapping[str, Any]] = []
    if not isinstance(phase_i_qiskit_receipt, Mapping):
        raise ValueError("Costexp Phase-I Qiskit evidence is missing.")
    raw_qiskit_rows = phase_i_qiskit_receipt.get("rows")
    if (
        phase_i_qiskit_receipt.get("schema")
        != "paper_i_phase123_qiskit_population_normalization_v1"
        or phase_i_qiskit_receipt.get("phase") != "phase_i"
        or not isinstance(raw_qiskit_rows, list)
        or not raw_qiskit_rows
        or phase_i_qiskit_receipt.get("rows_sha256")
        != canonical_sha256(raw_qiskit_rows)
    ):
        raise ValueError("Costexp Phase-I Qiskit evidence is invalid.")
    qiskit_rows = [
        row for row in raw_qiskit_rows if isinstance(row, Mapping)
    ]
    if len(qiskit_rows) != len(raw_qiskit_rows):
        raise ValueError("Costexp Phase-I Qiskit row is malformed.")

    receipt = dict(raw_receipt)
    receipt_sha256 = receipt.pop("sha256", None)
    classes = receipt.get("classes")
    if (
        receipt.get("schema") != COSTEXP_CLASS_REALIZATION_RECEIPT_SCHEMA
        or receipt.get("equivalence_policy")
        != COSTEXP_MIN_COST_REALIZATION_EQUIVALENCE
        or receipt.get("selection_rule")
        != COSTEXP_CLASS_REALIZATION_TIE_BREAK
        or not isinstance(classes, list)
        or not classes
        or int(receipt.get("class_count", -1)) != len(classes)
        or receipt.get("ordered_classes_sha256")
        != canonical_sha256(classes)
        or receipt_sha256 != canonical_sha256(receipt)
    ):
        raise ValueError("Costexp realization receipt envelope is invalid.")

    raw_plans = reduction_receipt.get("candidate_position_plans")
    if not isinstance(raw_plans, list) or not raw_plans:
        raise ValueError("Costexp class partition plans are missing.")
    plans_by_pool_index: dict[int, Mapping[str, Any]] = {}
    for raw_plan in raw_plans:
        if not isinstance(raw_plan, Mapping):
            raise ValueError("Costexp class partition plan is malformed.")
        pool_index = _integer(
            raw_plan.get("candidate_pool_index"),
            owner="Costexp plan pool index",
        )
        if pool_index in plans_by_pool_index:
            raise ValueError("Costexp class partition repeats a candidate.")
        plans_by_pool_index[pool_index] = raw_plan

    phases = scored_population.get("phases")
    phase_i_rows = (
        [
            phase
            for phase in phases
            if isinstance(phase, Mapping) and phase.get("phase") == "phase_i"
        ]
        if isinstance(phases, list)
        else []
    )
    if len(phase_i_rows) != 1 or not isinstance(
        phase_i_rows[0].get("records"), list
    ):
        raise ValueError("Costexp realization lacks one Phase-I population.")
    phase_i_records = phase_i_rows[0]["records"]
    phase_i_by_coordinate: dict[tuple[int, int], Mapping[str, Any]] = {}
    for raw_record in phase_i_records:
        if not isinstance(raw_record, Mapping):
            raise ValueError("Costexp Phase-I record is malformed.")
        coordinate = (
            _integer(
                raw_record.get("pool_index"),
                owner="Costexp Phase-I pool index",
            ),
            _integer(
                raw_record.get("insertion_position"),
                owner="Costexp Phase-I position",
            ),
        )
        if coordinate in phase_i_by_coordinate:
            raise ValueError("Costexp Phase-I population repeats a coordinate.")
        phase_i_by_coordinate[coordinate] = raw_record

    observed_classes: set[tuple[int, int]] = set()
    observed_phase_i: set[tuple[int, int]] = set()
    canonical_order: list[tuple[int, int]] = []
    for raw_class in classes:
        if not isinstance(raw_class, Mapping):
            raise ValueError("Costexp realization class is malformed.")
        class_row = dict(raw_class)
        class_sha256 = class_row.pop("sha256", None)
        member_costs = class_row.get("member_costs")
        if (
            not isinstance(member_costs, list)
            or not member_costs
            or class_row.get("ordered_member_costs_sha256")
            != canonical_sha256(member_costs)
            or class_sha256 != canonical_sha256(class_row)
        ):
            raise ValueError("Costexp realization class digest is invalid.")
        pool_index = _integer(
            class_row.get("candidate_pool_index"),
            owner="Costexp class pool index",
        )
        representative = _integer(
            class_row.get("representative_position"),
            owner="Costexp class representative",
        )
        chosen = _integer(
            class_row.get("chosen_position"),
            owner="Costexp chosen position",
        )
        class_key = (pool_index, representative)
        if class_key in observed_classes:
            raise ValueError("Costexp realization repeats a response class.")
        observed_classes.add(class_key)
        canonical_order.append(class_key)

        plan = plans_by_pool_index.get(pool_index)
        raw_members_by_representative = (
            plan.get("members_by_representative")
            if isinstance(plan, Mapping)
            else None
        )
        if not isinstance(raw_members_by_representative, Mapping):
            raise ValueError("Costexp response class is not authenticated.")
        raw_expected_members = raw_members_by_representative.get(
            representative,
            raw_members_by_representative.get(str(representative)),
        )
        expected_members = _position_list(
            raw_expected_members,
            owner="Costexp authenticated class members",
        )
        declared_members = _position_list(
            class_row.get("member_positions"),
            owner="Costexp declared class members",
        )
        if declared_members != expected_members:
            raise ValueError(
                "Costexp realization members differ from the authenticated class."
            )

        cost_positions: list[int] = []
        penalties: dict[int, float] = {}
        member_rows_by_position: dict[int, Mapping[str, Any]] = {}
        generator_id = str(class_row.get("generator_id", ""))
        compile_cache_generator_id = str(
            class_row.get("compile_cache_generator_id", "")
        )
        pool_label = str(class_row.get("candidate_label", ""))
        if (
            not generator_id
            or not compile_cache_generator_id
            or not pool_label
            or compile_cache_generator_id
            != f"{generator_id}::pool[{pool_index}]"
        ):
            raise ValueError("Costexp realization class identity is incomplete.")
        identity_stem = str(
            class_row.get("representative_domain_record_id", "")
        )
        suffix = f"@{representative}"
        if not identity_stem.endswith(suffix):
            raise ValueError("Costexp representative record identity drifted.")
        identity_stem = identity_stem[: -len(suffix)]
        if identity_stem != compile_cache_generator_id:
            raise ValueError("Costexp controller identity drifted.")
        for raw_cost in member_costs:
            if not isinstance(raw_cost, Mapping):
                raise ValueError("Costexp member cost row is malformed.")
            position = _integer(
                raw_cost.get("position_id"),
                owner="Costexp member position",
            )
            if position in penalties:
                raise ValueError("Costexp member costs repeat a position.")
            try:
                penalty = float(raw_cost.get("penalty_total"))
                c_hat_2q = float(raw_cost.get("c_hat_2q"))
                c_hat_d = float(raw_cost.get("c_hat_d"))
                routed_cost_inputs = {
                    str(key): float(value)
                    for key, value in dict(
                        raw_cost.get("routed_cost_inputs")
                    ).items()
                }
                penalty_weights = {
                    str(key): float(value)
                    for key, value in dict(
                        raw_cost.get("penalty_weights")
                    ).items()
                }
            except (TypeError, ValueError) as exc:
                raise ValueError("Costexp member routed cost is non-numeric.") from exc
            if (
                set(routed_cost_inputs) != set(_ROUTED_INPUT_TO_WEIGHT)
                or penalty_weights != expected_weights
                or raw_cost.get("negative_delta_reward_enabled") is not True
                or not all(
                    math.isfinite(value)
                    for value in (
                        penalty,
                        c_hat_2q,
                        c_hat_d,
                        *routed_cost_inputs.values(),
                    )
                )
            ):
                raise ValueError("Costexp member routed cost is non-finite.")
            recomputed_penalty = costexp_signed_penalty_total(
                routed_cost_inputs,
                expected_weights,
            )
            if (
                not math.isclose(
                    penalty,
                    recomputed_penalty,
                    rel_tol=0.0,
                    abs_tol=1.0e-12,
                )
                or not math.isclose(
                    c_hat_2q,
                    max(
                        0.0,
                        routed_cost_inputs[
                            "raw_delta_compiled_count_2q"
                        ],
                    ),
                    rel_tol=0.0,
                    abs_tol=1.0e-12,
                )
                or not math.isclose(
                    c_hat_d,
                    max(
                        0.0,
                        routed_cost_inputs[
                            "raw_delta_compiled_depth_2q"
                        ],
                    ),
                    rel_tol=0.0,
                    abs_tol=1.0e-12,
                )
            ):
                raise ValueError(
                    "Costexp member penalty does not close its sealed "
                    "routed-cost law."
                )
            if str(raw_cost.get("domain_record_id", "")) != (
                f"{identity_stem}@{position}"
            ):
                raise ValueError("Costexp member record identity drifted.")
            compile_identity = raw_cost.get("compile_cache_identity")
            base_structure_key = str(raw_cost.get("base_structure_key", ""))
            trial_structure_key = str(raw_cost.get("trial_structure_key", ""))
            if (
                not isinstance(compile_identity, Mapping)
                or dict(compile_identity)
                != {
                    "schema": (
                        "phase123_qiskit_candidate_position_compile_cache_v1"
                    ),
                    "scope": BACKEND_COMPILE_SCOPE_PHASE123_QISKIT_V1,
                    "candidate_label": pool_label,
                    "generator_id": compile_cache_generator_id,
                    "position_id": position,
                    "base_structure_key": base_structure_key,
                    "trial_structure_key": trial_structure_key,
                }
                or raw_cost.get("compile_cache_identity_sha256")
                != canonical_sha256(dict(compile_identity))
                or len(base_structure_key) != 64
                or len(trial_structure_key) != 64
                or base_structure_key == trial_structure_key
            ):
                raise ValueError("Costexp member compile identity is invalid.")
            cost_positions.append(position)
            penalties[position] = penalty
            member_rows_by_position[position] = raw_cost
        if cost_positions != declared_members:
            raise ValueError(
                "Costexp realization omits or adds an authenticated member cost."
            )

        expected_chosen = min(
            declared_members,
            key=lambda position: (penalties[position], position),
        )
        if chosen != expected_chosen:
            raise ValueError(
                "Costexp realized position is not the minimum-cost member "
                "with the earliest exact-tie break."
            )
        if str(class_row.get("chosen_domain_record_id", "")) != (
            f"{identity_stem}@{chosen}"
        ):
            raise ValueError("Costexp chosen record identity drifted.")
        phase_i_record = phase_i_by_coordinate.get((pool_index, chosen))
        if (
            phase_i_record is None
            or str(phase_i_record.get("domain_record_id", ""))
            != str(class_row.get("chosen_domain_record_id", ""))
            or str(phase_i_record.get("generator_id", "")) != generator_id
            or str(phase_i_record.get("pool_label", "")) != pool_label
        ):
            raise ValueError(
                "Costexp chosen member does not bind to its Phase-I record."
            )
        chosen_cost = member_rows_by_position[chosen]
        matching_qiskit_rows = [
            row
            for row in qiskit_rows
            if int(row.get("candidate_pool_index", -1)) == pool_index
            and int(row.get("position_id", -1)) == chosen
            and str(row.get("candidate_label", "")) == pool_label
            and str(row.get("generator_id", "")) == generator_id
            and str(row.get("compile_cache_generator_id", ""))
            == compile_cache_generator_id
        ]
        if len(matching_qiskit_rows) != 1:
            raise ValueError(
                "Costexp chosen member lacks one exact Phase-I Qiskit row."
            )
        qiskit_row = matching_qiskit_rows[0]
        if (
            qiskit_row.get("compile_cache_identity")
            != chosen_cost.get("compile_cache_identity")
            or qiskit_row.get("compile_cache_identity_sha256")
            != chosen_cost.get("compile_cache_identity_sha256")
            or qiskit_row.get("base_structure_key")
            != chosen_cost.get("base_structure_key")
            or qiskit_row.get("trial_structure_key")
            != chosen_cost.get("trial_structure_key")
            or int(qiskit_row.get("costexp_representative_position", -1))
            != representative
            or qiskit_row.get("costexp_routed_cost_inputs")
            != chosen_cost.get("routed_cost_inputs")
            or qiskit_row.get("costexp_penalty_weights")
            != expected_weights
            or qiskit_row.get(
                "costexp_negative_delta_reward_enabled"
            )
            is not True
            or not math.isclose(
                float(qiskit_row.get("costexp_penalty_total", math.nan)),
                penalties[chosen],
                rel_tol=0.0,
                abs_tol=1.0e-12,
            )
            or not math.isclose(
                float(qiskit_row.get("costexp_c_hat_2q", math.nan)),
                float(chosen_cost["c_hat_2q"]),
                rel_tol=0.0,
                abs_tol=1.0e-12,
            )
            or not math.isclose(
                float(qiskit_row.get("costexp_c_hat_d", math.nan)),
                float(chosen_cost["c_hat_d"]),
                rel_tol=0.0,
                abs_tol=1.0e-12,
            )
        ):
            raise ValueError(
                "Costexp chosen member drifted from Phase-I Qiskit evidence."
            )
        observed_phase_i.add((pool_index, chosen))

    if canonical_order != sorted(canonical_order):
        raise ValueError("Costexp realization classes are not canonical ordered.")
    if observed_phase_i != set(phase_i_by_coordinate):
        raise ValueError(
            "Costexp realization classes do not close the Phase-I population."
        )
    return dict(raw_receipt)
