"""Named pure-Hubbard applications for the RA-ADAPT appendix evidence.

The interface deliberately exposes only the fixed physics builder, the four
paired method arms, and one preflight.  The existing Hubbard--Holstein and
Page-12 pure-Hubbard applications remain closed to these study-only points.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, ClassVar

from pipelines.contracts.problem import ProblemRequest, ResolvedProblemContext
from pipelines.static_adapt.builders.problem_registry import (
    resolve_problem_context,
)
from pipelines.static_adapt.ra_adapt.adapters import (
    GLOBAL_SINGLETON_ABSOLUTE_GRADIENT_PHASE0_POLICY,
    GlobalSinglePauliWordCandidateAdapter,
)
from pipelines.static_adapt.ra_adapt.contracts import (
    CANDIDATE_REPRESENTATION_MACRO,
    CANDIDATE_REPRESENTATION_SINGLE_PAULI,
    RAAdaptRequest,
    ResolvedRAAdaptProtocol,
    canonical_sha256,
)
from pipelines.scaffold.hh_continuation_generators import (
    serialize_polynomial_terms_exyz,
)
from pipelines.static_adapt.ra_adapt.pools import (
    RA_ADAPT_APPENDIX_PURE_HUBBARD_APPLICATION_ID,
    build_ra_adapt_appendix_pure_hubbard_guarded_single_pauli_pool,
    build_ra_adapt_appendix_pure_hubbard_parent_template_inventory,
    build_ra_adapt_appendix_pure_hubbard_sector_guarded_macro_pool,
    require_ra_adapt_appendix_pure_hubbard_problem,
)
from pipelines.static_adapt.sr_snake.contracts import (
    BEAM_COMPARISON_BRANCH_COMPILED_COST,
    BEAM_COMPARISON_BRANCH_COMPILED_COST_UNFILTERED,
    BEAM_COMPARISON_ENERGY_PLUS_S_ALG,
    BEAM_COMPARISON_PHASE3_GAIN_OVER_BURDEN,
    resolved_beam_comparison,
    AcceptedStateResume,
    AppendOnlyInsertion,
    BeamOff,
    CheckpointObservation,
    CombinatorialBatchAdmission,
    EstimatorLedgerObservation,
    ExplicitDepthQiskitCompileCost,
    ForkLocalBeam,
    FreshStart,
    MetricPruning,
    PruningOff,
    SingletonAdmission,
    SRExecutionPolicy,
    SRMethodPolicy,
    SRObservationPolicy,
    ResolvedProblemReceipt,
    SRStopPolicy,
)


RA_ADAPT_APPENDIX_PURE_HUBBARD_ADAPTER_ID = (
    "ra_adapt_appendix_pure_hubbard_global_single_pauli_adapter_v1"
)
RA_ADAPT_APPENDIX_ARMS = (
    "baseline",
    "batching",
    "metric_ablation",
    "metric_ablation_protect0",
    "metric_ablation_protect1",
    "metric_ablation_gated",
    "metric_ablation_gated_norefit",
    "beam",
    "beam_wide",
    "beam_cost",
    "beam_escalated",
    "beam_escalated_unfiltered",
)
# Named prune ablation: the canonical route protects a freshly admitted
# generator from deletion for two controller rounds, so prune can only
# recover the admission stage's slack two rounds late.  This arm sets that
# window to zero and changes nothing else.
RA_ADAPT_APPENDIX_PRUNE_PROTECT_STEPS_ABLATIONS = (0, 1)
# Gated prune: shorten the protection window and screen nominees by angle
# magnitude, so a delete-and-refit measurement is only paid for on a
# coordinate that is already numerically inert.  Generators carrying real
# weight sit three orders of magnitude above this screen.
RA_ADAPT_APPENDIX_PRUNE_GATED_PROTECT_STEPS = 1
# Nomination tolerance floor.  The canonical 1e-8 sits six orders above
# a converged trajectory's own error, so it masks the observed gain term
# and lets the energy model nominate a deletion that costs far more than
# the round it is deleting from.
# Batch shapes admitted for the diagnostic size/window sweep.  These are
# named variants, not new defaults; the canonical arm stays (3, 6).
RA_ADAPT_APPENDIX_BATCH_SWEEP_SHAPES = frozenset(
    {(2, 4), (2, 6), (2, 8), (3, 4), (3, 8), (3, 10), (4, 8)}
)
# Nomination-screen sweep: theta thresholds and protection windows admitted
# as named diagnostic arms.  The canonical gated arm stays (1e-3, 1).
RA_ADAPT_APPENDIX_PRUNE_THETA_SWEEP = frozenset(
    {1.0e-1, 5.0e-2, 1.0e-2, 5.0e-3, 1.0e-3, 1.0e-4}
)
RA_ADAPT_APPENDIX_PRUNE_PROTECT_SWEEP = frozenset({0, 1, 2, 3, 4})
RA_ADAPT_APPENDIX_PRUNE_MAX_REGRESSION = 1.0e-8
RA_ADAPT_APPENDIX_PRUNE_GATED_SMALL_THETA_ABS = 1.0e-3
# Do not pay for a delete--refit sibling when the local nomination model
# predicts too much deletion loss per unit of relieved compiled burden.  This
# is separate from the amplitude screen: one detects a small coordinate, the
# other tests modeled recoverability relative to the resource it would remove.
RA_ADAPT_APPENDIX_PRUNE_GATED_MAX_PREDICTED_LOSS_PER_COST = 1.0e-8
# Named beam shapes.  ``beam`` is the established two-parent/two-child
# appendix shape.  ``beam_wide`` keeps every other setting and only widens
# the fork, so a beam that fails to help cannot be blamed on a narrow search.
RA_ADAPT_APPENDIX_BEAM_SHAPES = {
    "beam": (2, 2, 4, 0.0),
    "beam_wide": (4, 3, 12, 0.0),
    "beam_cost": (2, 2, 4, 0.0),
    # Escalated: wider fork AND ranked by whole-branch compiled cost, so the
    # extra exploration is spent finding cheaper circuits rather than chasing
    # energy into expensive ones.
    "beam_escalated": (4, 3, 12, 0.0),
    # Identical shape and pricing, Pareto pre-filter off, so the appendix can
    # report what the filter costs and saves instead of asserting it.
    "beam_escalated_unfiltered": (4, 3, 12, 0.0),
}
# ``beam_cost`` keeps the established two-parent/two-child shape and changes
# only how siblings are ranked: by this route's own Phase-III rule, trust
# gain per unit compiled burden (1 + K3), instead of accepted energy plus a
# weighted estimator-query count.  Widening the fork does not help while the
# ranking is blind to circuit cost; this makes it cost-aware at fixed width.
RA_ADAPT_APPENDIX_BEAM_COST_COMPARISON = (
    BEAM_COMPARISON_PHASE3_GAIN_OVER_BURDEN
)
RA_ADAPT_APPENDIX_MAXIMUM_HORIZON = 20
RA_ADAPT_APPENDIX_GENERATOR_REPRESENTATIONS = frozenset(
    {
        CANDIDATE_REPRESENTATION_SINGLE_PAULI,
        CANDIDATE_REPRESENTATION_MACRO,
    }
)
# The guarded single-Pauli exposure is sector-degenerate at L=3 (every
# off-diagonal word leaves the fixed-count sector, leaving nine diagonal Z
# directions with zero Hartree--Fock gradient and zero tangent self-metric).
# L=3 therefore runs the intact multi-Pauli parent generators under the same
# hard sector guard.  See ``docs/adr`` and the appendix L=3 tests.
RA_ADAPT_APPENDIX_SITE_GENERATOR_REPRESENTATION = {
    2: CANDIDATE_REPRESENTATION_SINGLE_PAULI,
    3: CANDIDATE_REPRESENTATION_MACRO,
}
RA_ADAPT_APPENDIX_NOISE_HORIZONS = (10, 15, 20)
RA_ADAPT_APPENDIX_NOISELESS_APPLICATION_LANE = (
    "ra_adapt_appendix_pure_hubbard_append_explicit_depth_v1"
)
RA_ADAPT_APPENDIX_NOISE_APPLICATION_LANE = (
    "ra_adapt_appendix_pure_hubbard_append_explicit_depth_noise_v1"
)
RA_ADAPT_APPENDIX_PURE_HUBBARD_LOCKS: dict[int, dict[str, Any]] = {
    2: {
        "problem_request_sha256": (
            "ef92916a3ccf423577f07992602bd5074f436a6f69b83ff19f95abd917eb1d17"
        ),
        "hamiltonian_terms_sha256": (
            "834ad26c1864e1989f0619a68e7ce32978eaaa9251b8aeafe32dbe602a8ab27b"
        ),
        "exact_energy": -1.470381826780026,
        "sector_num_particles": (1, 1),
        "parent_count": 18,
        "parent_labels_sha256": (
            "6cb20d596cc56fe434502bf838b220ac921451837ee919485e8dc70b84bb6043"
        ),
        "parent_pool_sha256": (
            "2689c43959fc7e8f0466703c47694bfe112ddb463b51a8d73c98984e4611efef"
        ),
        "singleton_count": 22,
        "singleton_labels_sha256": (
            "9b897c94e722799f24485aeb23dca7d37cd935125361a1f505306a6f6a6c5af5"
        ),
        "singleton_pool_sha256": (
            "669770203f3453a62b15e3347565e88ee604aeac4d3dc06da3a18eb5e936358a"
        ),
        "macro_count": 13,
        "macro_labels_sha256": (
            "cd838b7373c74d9fb36bc6834506c36dfa9c5a2e03a13c1ba07a16e830ebafea"
        ),
        "macro_pool_sha256": (
            "d28247556066b59d162df14041d19d73cfdd22f7e7816d5111574b34d047f5d2"
        ),
    },
    3: {
        "problem_request_sha256": (
            "8683393436ac82fd353d5f0469a904a22111e38d98168b50e852490cf25dc4f8"
        ),
        "hamiltonian_terms_sha256": (
            "7346c56a6800006025a4ed092ec921bec447d6849748f29f1fc35e38300b131c"
        ),
        "exact_energy": -2.1414935642714075,
        "sector_num_particles": (2, 1),
        "parent_count": 33,
        "parent_labels_sha256": (
            "8a2500d8320609dc84cd7574721e11952bb64dfc950cf31d6cfe9b708634baa1"
        ),
        "parent_pool_sha256": (
            "c048d204caea894209d80799bab7745f7c16125efd09b67abdbe44f3e304d860"
        ),
        "singleton_count": 9,
        "singleton_labels_sha256": (
            "db97409498d09f2318cffc84f536cef8797d5c692c5cc6ce60406d1cc5c073a3"
        ),
        "singleton_pool_sha256": (
            "254ae95b9596178b8eb582753b81a60f9b197f6ec0aa3410e5755e8c4fa470a2"
        ),
        "macro_count": 24,
        "macro_labels_sha256": (
            "80f30f02dcf0585eba094f0174ef00e67b47299255828c415c52e50ece7ed574"
        ),
        "macro_pool_sha256": (
            "7e2f848979ecb779076c5f46ad9edef7a90608332cc05236be55f79fad03e03c"
        ),
    },
}
RA_ADAPT_APPENDIX_PURE_HUBBARD_NOISE_LOCKS: dict[float, dict[str, Any]] = {
    1.5: {
        "problem_request_sha256": (
            "40e9ffeedc1fc97936df2ae3a131227fa1c9ac490cd91a54a626d15c69b88268"
        ),
        "hamiltonian_terms_sha256": (
            "4b32ab906b632526813236c2e968f162397c1531faee78ea3a3931fad21dfbce"
        ),
        "exact_energy": -1.3860009363293817,
        "sector_num_particles": (1, 1),
        "parent_count": 18,
        "parent_labels_sha256": (
            "6cb20d596cc56fe434502bf838b220ac921451837ee919485e8dc70b84bb6043"
        ),
        "parent_pool_sha256": (
            "6503a864b9b5aeb5599e27f8ccad8669291cf9d97d385198b63090def98a7e82"
        ),
        "singleton_count": 22,
        "singleton_labels_sha256": (
            "9b897c94e722799f24485aeb23dca7d37cd935125361a1f505306a6f6a6c5af5"
        ),
        "singleton_pool_sha256": (
            "67fea41930d827a740adb16785627853fc4422699123c9eeabfda21617a9fea2"
        ),
    },
    8.0: {
        "problem_request_sha256": (
            "d7e015d7544e26bd3ed9e702d35088ed1e57ac5ae13d3aafa57d4c6063a97a5a"
        ),
        "hamiltonian_terms_sha256": (
            "8ae034ff2a9c72672eb8f1606941515f7fd7a6afe0af56bc12c499606adcd7aa"
        ),
        "exact_energy": -0.47213595499957944,
        "sector_num_particles": (1, 1),
        "parent_count": 18,
        "parent_labels_sha256": (
            "6cb20d596cc56fe434502bf838b220ac921451837ee919485e8dc70b84bb6043"
        ),
        "parent_pool_sha256": (
            "9580a349333b124267302458aebb72f902f336c4ffb3d59363d8bcdf05280b22"
        ),
        "singleton_count": 22,
        "singleton_labels_sha256": (
            "9b897c94e722799f24485aeb23dca7d37cd935125361a1f505306a6f6a6c5af5"
        ),
        "singleton_pool_sha256": (
            "8c335fb77760b705bfbaad00b10549c9eb137425d64b1c0434f6a39ba19ef105"
        ),
    },
}


@dataclass(frozen=True)
class RAAdaptAppendixPureHubbardCandidateAdapter(
    GlobalSinglePauliWordCandidateAdapter
):
    """Global guarded-singleton supply for the named pure-Hubbard study."""

    application_family_key: ClassVar[str] = "hubbard"
    application_id: ClassVar[str] = (
        RA_ADAPT_APPENDIX_PURE_HUBBARD_APPLICATION_ID
    )
    candidate_representation_id: str = CANDIDATE_REPRESENTATION_SINGLE_PAULI
    adapter_id: str = RA_ADAPT_APPENDIX_PURE_HUBBARD_ADAPTER_ID
    noise_level_id: str | None = None
    # The appendix route refits in native coordinates while the canonical
    # Paper-I RA route whitens against the supported Fubini--Study metric.
    # This opts one appendix run into the whitened chart so the two can be
    # compared with nothing else changed -- in particular the refit
    # initialization stays off, so this is not a warm start by another name.
    accepted_refit_whitened: bool = False
    # The appendix route ships fixed phase shortlist widths (Phase I keeps the
    # whole 24-generator pool, Phase II a flat top-12) while the canonical
    # Paper-I route sizes each phase by the inverse-Simpson effective
    # competition of its own score population.  This opts one appendix run
    # into that adaptive width with nothing else changed; the selector is
    # pure cardinality, so it performs no estimator, metric, or compile work.
    adaptive_phase_shortlists: bool = False
    # Phase 0 is a pre-screen: one absolute-gradient pass over the whole
    # guarded-singleton supply, shortlisted to the effective-competition
    # width before Phase I sees anything.  The appendix route ships without
    # it; the canonical Paper-I route runs it.  Activation is the route
    # declaration, not this identity string, which is inert on its own.
    phase0_gradient_screen: bool = False
    # Frontier ratio for the adaptive widths.  The canonical 0.9 keeps only
    # near-ties with the leader, which on a peaked ADAPT score population
    # truncates to a single candidate and hands Phase III nothing to choose
    # between.  None leaves the canonical value in place.
    adaptive_frontier_ratio: float | None = None
    phase0_shortlist_policy_id: ClassVar[str] = (
        GLOBAL_SINGLETON_ABSOLUTE_GRADIENT_PHASE0_POLICY
    )

    def __post_init__(self) -> None:
        if (
            self.candidate_representation_id
            not in RA_ADAPT_APPENDIX_GENERATOR_REPRESENTATIONS
            or self.adapter_id
            != RA_ADAPT_APPENDIX_PURE_HUBBARD_ADAPTER_ID
        ):
            raise ValueError(
                "The RA-ADAPT appendix pure-Hubbard adapter identity is fixed."
            )

        if self.noise_level_id is not None:
            from pipelines.static_adapt.ra_adapt.pure_hubbard_noise_page12 import (
                pure_hubbard_noise_level_contract,
            )

            pure_hubbard_noise_level_contract(self.noise_level_id)

    def parent_inventory(self, problem: ResolvedProblemContext) -> Any:
        return build_ra_adapt_appendix_pure_hubbard_parent_template_inventory(
            problem,
            representation_id=self.candidate_representation_id,
        )

    def executable_pool(self, problem: ResolvedProblemContext) -> Any:
        if (
            self.candidate_representation_id
            == CANDIDATE_REPRESENTATION_MACRO
        ):
            return (
                build_ra_adapt_appendix_pure_hubbard_sector_guarded_macro_pool(
                    problem
                )
            )
        return build_ra_adapt_appendix_pure_hubbard_guarded_single_pauli_pool(
            problem
        )


def _require_appendix_problem_lock(
    problem: ResolvedProblemContext,
) -> dict[str, Any]:
    require_ra_adapt_appendix_pure_hubbard_problem(problem)
    sites = int(problem.request.num_sites)
    lock = RA_ADAPT_APPENDIX_PURE_HUBBARD_LOCKS.get(sites)
    if lock is None:
        # L=2 U/t=1.5 and 8 are admitted only by the later noise-specific
        # contract and deliberately do not share the U/t=1.25 problem lock.
        raise ValueError("The noiseless appendix problem lock is L=2/L=3 U/t=1.25.")
    receipt = ResolvedProblemReceipt.from_problem(problem)
    observed_hamiltonian = canonical_sha256(
        serialize_polynomial_terms_exyz(problem.hamiltonian)
    )
    if (
        float(problem.request.u) != 1.25
        or receipt.problem_request_sha256 != lock["problem_request_sha256"]
        or observed_hamiltonian != lock["hamiltonian_terms_sha256"]
        or tuple(problem.sector.num_particles)
        != tuple(lock["sector_num_particles"])
    ):
        raise ValueError(
            "The pure-Hubbard appendix problem drifted from its locked "
            "problem, Hamiltonian, or sector identity."
        )
    return lock


def _require_appendix_noise_problem_lock(
    problem: ResolvedProblemContext,
) -> dict[str, Any]:
    require_ra_adapt_appendix_pure_hubbard_problem(problem)
    request = problem.request
    u = float(request.u)
    if int(request.num_sites) == 3:
        # Noise is a controller overlay, not a Hamiltonian change, so the
        # L=3 noise lane runs the identical U/t=1.25 physics point as the
        # noiseless L=3 arms and reuses its lock.
        return _require_appendix_problem_lock(problem)
    lock = RA_ADAPT_APPENDIX_PURE_HUBBARD_NOISE_LOCKS.get(u)
    if int(request.num_sites) != 2 or lock is None:
        raise ValueError(
            "The corrected appendix noise lane is fixed to L=2 U/t in "
            "{1.5, 8} or the named L=3 U/t=1.25 point."
        )
    receipt = ResolvedProblemReceipt.from_problem(problem)
    observed_hamiltonian = canonical_sha256(
        serialize_polynomial_terms_exyz(problem.hamiltonian)
    )
    if (
        receipt.problem_request_sha256 != lock["problem_request_sha256"]
        or observed_hamiltonian != lock["hamiltonian_terms_sha256"]
        or tuple(problem.sector.num_particles)
        != tuple(lock["sector_num_particles"])
    ):
        raise ValueError(
            "The corrected appendix noise problem drifted from its locked "
            "problem, Hamiltonian, or sector identity."
        )
    return lock


def _require_appendix_inventory_lock(
    protocol: ResolvedRAAdaptProtocol,
    *,
    lock: dict[str, Any],
) -> None:
    parent = protocol.parent_inventory
    executable = protocol.executable_pool
    macro = (
        str(executable.candidate_representation)
        == CANDIDATE_REPRESENTATION_MACRO
    )
    if macro:
        expected_count = lock.get("macro_count")
        expected_labels = lock.get("macro_labels_sha256")
        expected_pool = lock.get("macro_pool_sha256")
        if expected_count is None:
            raise ValueError(
                "This appendix physics point has no locked composite "
                "generator inventory."
            )
    else:
        expected_count = lock["singleton_count"]
        expected_labels = lock["singleton_labels_sha256"]
        expected_pool = lock["singleton_pool_sha256"]
    if (
        parent.count != lock["parent_count"]
        or parent.ordered_labels_sha256 != lock["parent_labels_sha256"]
        or parent.ordered_pool_sha256 != lock["parent_pool_sha256"]
        or executable.count != expected_count
        or executable.ordered_labels_sha256 != expected_labels
        or executable.ordered_pool_sha256 != expected_pool
    ):
        raise ValueError(
            "The pure-Hubbard appendix candidate inventory drifted from its "
            "locked count, ordering, or generator bytes."
        )


def build_ra_adapt_appendix_pure_hubbard_problem(
    *,
    num_sites: int,
) -> ResolvedProblemContext:
    """Build the fixed U/t=1.25 L=2 point or its L=3 escalation."""

    sites = int(num_sites)
    if isinstance(num_sites, bool) or sites not in {2, 3}:
        raise ValueError("num_sites must be exactly 2 or 3.")
    problem = resolve_problem_context(
        ProblemRequest(
            problem_key="hubbard",
            num_sites=sites,
            t=1.0,
            u=1.25,
            dv=0.0,
            omega0=0.0,
            g_ep=0.0,
            n_ph_max=0,
            boson_encoding="binary",
            ordering="blocked",
            boundary="open",
            include_zero_point=False,
            v_nn=0.0,
            t_prime=0.0,
            n_fermions=sites,
        )
    )
    require_ra_adapt_appendix_pure_hubbard_problem(problem)
    _require_appendix_problem_lock(problem)
    return problem


def build_ra_adapt_appendix_noise_problem(
    *,
    u: float,
) -> ResolvedProblemContext:
    """Build one of the two fixed L=2 pure-Hubbard noise physics points."""

    interaction = float(u)
    if interaction not in RA_ADAPT_APPENDIX_PURE_HUBBARD_NOISE_LOCKS:
        raise ValueError("The noise problem requires U/t to be exactly 1.5 or 8.")
    problem = resolve_problem_context(
        ProblemRequest(
            problem_key="hubbard",
            num_sites=2,
            t=1.0,
            u=interaction,
            dv=0.0,
            omega0=0.0,
            g_ep=0.0,
            n_ph_max=0,
            boson_encoding="binary",
            ordering="blocked",
            boundary="open",
            include_zero_point=False,
            v_nn=0.0,
            t_prime=0.0,
            n_fermions=2,
        )
    )
    _require_appendix_noise_problem_lock(problem)
    return problem


def _observation_policy(
    output_dir: Path | None,
    *,
    horizon: int,
) -> SRObservationPolicy:
    if output_dir is None:
        return SRObservationPolicy()
    root = Path(output_dir)
    return SRObservationPolicy(
        checkpoint=CheckpointObservation(
            path=root / "current.json",
            every_controller_rounds=1,
            keep_history_tail=max(100, horizon),
        ),
        estimator_ledger=EstimatorLedgerObservation(
            path=root / "estimator_ledger.json"
        ),
    )


def ra_adapt_appendix_generator_representation(num_sites: int) -> str:
    """Return the appendix generator representation for one lattice size.

    ``L=2`` keeps the established guarded single-Pauli exposure.  ``L=3``
    uses the intact multi-Pauli parent generators under the same hard sector
    guard, because the single-Pauli exposure is sector-degenerate there.
    """

    sites = int(num_sites)
    if isinstance(num_sites, bool) or sites not in (
        RA_ADAPT_APPENDIX_SITE_GENERATOR_REPRESENTATION
    ):
        raise ValueError("num_sites must be exactly 2 or 3.")
    return RA_ADAPT_APPENDIX_SITE_GENERATOR_REPRESENTATION[sites]


def build_ra_adapt_appendix_request(
    *,
    arm: str,
    accepted_refit_whitened: bool = False,
    adaptive_phase_shortlists: bool = False,
    phase0_gradient_screen: bool = False,
    adaptive_frontier_ratio: float | None = None,
    maximum_controller_rounds: int,
    num_sites: int = 2,
    output_dir: Path | None = None,
    resume: FreshStart | AcceptedStateResume | None = None,
) -> RAAdaptRequest:
    """Build one fixed paired appendix arm on the corrected append route."""

    representation = ra_adapt_appendix_generator_representation(num_sites)
    arm_id = str(arm).strip().lower()
    if arm_id not in RA_ADAPT_APPENDIX_ARMS:
        raise ValueError(
            "arm must be one of baseline, batching, metric_ablation, "
            "metric_ablation_protect0, metric_ablation_protect1, or beam."
        )
    horizon = int(maximum_controller_rounds)
    if (
        isinstance(maximum_controller_rounds, bool)
        or horizon < 1
        or horizon > RA_ADAPT_APPENDIX_MAXIMUM_HORIZON
    ):
        raise ValueError("maximum_controller_rounds must be in [1, 20].")
    admission = (
        CombinatorialBatchAdmission(
            maximum_size=3,
            search_window_size=6,
        )
        if arm_id == "batching"
        else SingletonAdmission()
    )
    pruning = (
        MetricPruning()
        if arm_id == "metric_ablation"
        else MetricPruning(protect_steps=0)
        if arm_id == "metric_ablation_protect0"
        else MetricPruning(protect_steps=1)
        if arm_id == "metric_ablation_protect1"
        else MetricPruning(
            protect_steps=RA_ADAPT_APPENDIX_PRUNE_GATED_PROTECT_STEPS,
            small_theta_abs=RA_ADAPT_APPENDIX_PRUNE_GATED_SMALL_THETA_ABS,
            max_predicted_loss_per_cost=(
                RA_ADAPT_APPENDIX_PRUNE_GATED_MAX_PREDICTED_LOSS_PER_COST
            ),
            max_regression=RA_ADAPT_APPENDIX_PRUNE_MAX_REGRESSION,
        )
        if arm_id == "metric_ablation_gated"
        else MetricPruning(
            protect_steps=RA_ADAPT_APPENDIX_PRUNE_GATED_PROTECT_STEPS,
            small_theta_abs=RA_ADAPT_APPENDIX_PRUNE_GATED_SMALL_THETA_ABS,
            max_predicted_loss_per_cost=(
                RA_ADAPT_APPENDIX_PRUNE_GATED_MAX_PREDICTED_LOSS_PER_COST
            ),
            refit_after_delete=False,
        )
        if arm_id == "metric_ablation_gated_norefit"
        else PruningOff()
    )
    beam = (
        ForkLocalBeam(
            live_parent_branches=2,
            admission_children_per_parent=2,
            maximum_admission_children_per_round=4,
            s_alg_weight=0.0,
        )
        if arm_id == "beam"
        else ForkLocalBeam(
            live_parent_branches=RA_ADAPT_APPENDIX_BEAM_SHAPES[
                "beam_wide"
            ][0],
            admission_children_per_parent=RA_ADAPT_APPENDIX_BEAM_SHAPES[
                "beam_wide"
            ][1],
            maximum_admission_children_per_round=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_wide"][2]
            ),
            s_alg_weight=RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_wide"][3],
        )
        if arm_id == "beam_wide"
        else ForkLocalBeam(
            live_parent_branches=RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_cost"][0],
            admission_children_per_parent=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_cost"][1]
            ),
            maximum_admission_children_per_round=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_cost"][2]
            ),
            s_alg_weight=RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_cost"][3],
            comparison=RA_ADAPT_APPENDIX_BEAM_COST_COMPARISON,
        )
        if arm_id == "beam_cost"
        else ForkLocalBeam(
            live_parent_branches=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_escalated"][0]
            ),
            admission_children_per_parent=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_escalated"][1]
            ),
            maximum_admission_children_per_round=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_escalated"][2]
            ),
            s_alg_weight=RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_escalated"][3],
            comparison=BEAM_COMPARISON_BRANCH_COMPILED_COST,
        )
        if arm_id == "beam_escalated"
        else ForkLocalBeam(
            live_parent_branches=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_escalated_unfiltered"][0]
            ),
            admission_children_per_parent=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_escalated_unfiltered"][1]
            ),
            maximum_admission_children_per_round=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_escalated_unfiltered"][2]
            ),
            s_alg_weight=(
                RA_ADAPT_APPENDIX_BEAM_SHAPES["beam_escalated_unfiltered"][3]
            ),
            comparison=BEAM_COMPARISON_BRANCH_COMPILED_COST_UNFILTERED,
        )
        if arm_id == "beam_escalated_unfiltered"
        else BeamOff()
    )
    request = RAAdaptRequest(
        adapter=RAAdaptAppendixPureHubbardCandidateAdapter(
            candidate_representation_id=representation,
            accepted_refit_whitened=bool(accepted_refit_whitened),
            adaptive_phase_shortlists=bool(adaptive_phase_shortlists),
            phase0_gradient_screen=bool(phase0_gradient_screen),
            adaptive_frontier_ratio=(
                None if adaptive_frontier_ratio is None
                else float(adaptive_frontier_ratio)
            ),
        ),
        method=SRMethodPolicy(
            admission=admission,
            insertion=AppendOnlyInsertion(),
            pruning=pruning,
            beam=beam,
            compile_cost=ExplicitDepthQiskitCompileCost(),
        ),
        execution=SRExecutionPolicy(
            stop=SRStopPolicy(maximum_controller_rounds=horizon),
            resume=FreshStart() if resume is None else resume,
        ),
        observation=_observation_policy(output_dir, horizon=horizon),
    )
    require_ra_adapt_appendix_request(request)
    return request


def build_ra_adapt_appendix_noise_request(
    *,
    noise_level: str,
    maximum_controller_rounds: int,
    num_sites: int = 2,
    adaptive_phase_shortlists: bool = False,
    phase0_gradient_screen: bool = False,
    adaptive_frontier_ratio: float | None = None,
    output_dir: Path | None = None,
    resume: FreshStart | AcceptedStateResume | None = None,
) -> RAAdaptRequest:
    """Build one fixed corrected-route baseline noise request."""

    representation = ra_adapt_appendix_generator_representation(num_sites)
    horizon = int(maximum_controller_rounds)
    if (
        isinstance(maximum_controller_rounds, bool)
        or horizon not in RA_ADAPT_APPENDIX_NOISE_HORIZONS
    ):
        raise ValueError(
            "The appendix noise horizon must be one of "
            f"{RA_ADAPT_APPENDIX_NOISE_HORIZONS}."
        )
    request = RAAdaptRequest(
        adapter=RAAdaptAppendixPureHubbardCandidateAdapter(
            candidate_representation_id=representation,
            noise_level_id=str(noise_level).strip().lower(),
            adaptive_phase_shortlists=bool(adaptive_phase_shortlists),
            phase0_gradient_screen=bool(phase0_gradient_screen),
            adaptive_frontier_ratio=(
                None if adaptive_frontier_ratio is None
                else float(adaptive_frontier_ratio)
            ),
        ),
        method=SRMethodPolicy(
            admission=SingletonAdmission(),
            insertion=AppendOnlyInsertion(),
            pruning=PruningOff(),
            beam=BeamOff(),
            compile_cost=ExplicitDepthQiskitCompileCost(),
        ),
        execution=SRExecutionPolicy(
            stop=SRStopPolicy(maximum_controller_rounds=horizon),
            resume=FreshStart() if resume is None else resume,
        ),
        observation=_observation_policy(output_dir, horizon=horizon),
    )
    require_ra_adapt_appendix_request(request)
    return request


def ra_adapt_appendix_arm_id(request: RAAdaptRequest) -> str:
    """Resolve the exact paired arm or reject an unnamed method mixture."""

    method = request.method
    common = bool(
        isinstance(method.insertion, AppendOnlyInsertion)
        and method.compile_cost == ExplicitDepthQiskitCompileCost()
    )
    if not common:
        raise ValueError(
            "The RA-ADAPT appendix requires append-only insertion and the "
            "exact three-term explicit-depth compile cost."
        )
    if (
        isinstance(method.admission, SingletonAdmission)
        and isinstance(method.pruning, PruningOff)
        and isinstance(method.beam, BeamOff)
    ):
        return "baseline"
    if (
        isinstance(method.admission, CombinatorialBatchAdmission)
        and method.admission.maximum_size == 3
        and method.admission.resolved_search_window_size == 6
        and isinstance(method.pruning, PruningOff)
        and isinstance(method.beam, BeamOff)
    ):
        return "batching"
    if (
        isinstance(method.admission, CombinatorialBatchAdmission)
        and isinstance(method.pruning, PruningOff)
        and isinstance(method.beam, BeamOff)
    ):
        # Named batch-shape sweep.  The canonical (3, 6) mixture keeps its own
        # arm identity above; every other authorized shape carries its size
        # and window in the arm name so a swept run can never be mistaken for
        # the canonical batching arm in a results table.
        size = int(method.admission.maximum_size)
        window = int(method.admission.resolved_search_window_size)
        if (size, window) in RA_ADAPT_APPENDIX_BATCH_SWEEP_SHAPES:
            return f"batching_size{size}_win{window}"
        raise ValueError(
            "Only the named batch-shape sweep mixtures "
            f"{sorted(RA_ADAPT_APPENDIX_BATCH_SWEEP_SHAPES)} are authorized."
        )
    if (
        isinstance(method.admission, SingletonAdmission)
        and isinstance(method.pruning, MetricPruning)
        and isinstance(method.beam, BeamOff)
    ):
        if (
            method.pruning.protect_steps
            == RA_ADAPT_APPENDIX_PRUNE_GATED_PROTECT_STEPS
            and method.pruning.small_theta_abs
            == RA_ADAPT_APPENDIX_PRUNE_GATED_SMALL_THETA_ABS
            and method.pruning.max_predicted_loss_per_cost
            == (
                RA_ADAPT_APPENDIX_PRUNE_GATED_MAX_PREDICTED_LOSS_PER_COST
            )
        ):
            return (
                "metric_ablation_gated"
                if getattr(method.pruning, "refit_after_delete", True)
                else "metric_ablation_gated_norefit"
            )
        if method.pruning.small_theta_abs is not None:
            # Named nomination-screen sweep.  The canonical gated arm keeps
            # its own identity above; every other authorized screen carries
            # its threshold and protection window in the arm name.
            theta = float(method.pruning.small_theta_abs)
            protect = method.pruning.protect_steps
            if (
                theta in RA_ADAPT_APPENDIX_PRUNE_THETA_SWEEP
                and protect in RA_ADAPT_APPENDIX_PRUNE_PROTECT_SWEEP
            ):
                return f"metric_ablation_theta{theta:g}_protect{int(protect)}"
            raise ValueError(
                "Only the named gated prune ablation and the named screen "
                f"sweep {sorted(RA_ADAPT_APPENDIX_PRUNE_THETA_SWEEP)} x "
                f"{sorted(RA_ADAPT_APPENDIX_PRUNE_PROTECT_SWEEP)} may screen "
                "nominees."
            )
        if method.pruning.protect_steps is None:
            return "metric_ablation"
        protect_steps = int(method.pruning.protect_steps)
        if protect_steps in RA_ADAPT_APPENDIX_PRUNE_PROTECT_STEPS_ABLATIONS:
            return f"metric_ablation_protect{protect_steps}"
        raise ValueError(
            "Only the shortened prune protection ablations "
            f"{RA_ADAPT_APPENDIX_PRUNE_PROTECT_STEPS_ABLATIONS} "
            "are authorized."
        )
    if (
        isinstance(method.admission, SingletonAdmission)
        and isinstance(method.pruning, PruningOff)
        and isinstance(method.beam, ForkLocalBeam)
        and (
            method.beam.live_parent_branches,
            method.beam.admission_children_per_parent,
            method.beam.maximum_admission_children_per_round,
            method.beam.s_alg_weight,
        )
        in set(RA_ADAPT_APPENDIX_BEAM_SHAPES.values())
    ):
        observed = (
            method.beam.live_parent_branches,
            method.beam.admission_children_per_parent,
            method.beam.maximum_admission_children_per_round,
            method.beam.s_alg_weight,
        )
        mode = resolved_beam_comparison(method.beam)
        expected_mode_by_name = {
            "beam": BEAM_COMPARISON_ENERGY_PLUS_S_ALG,
            "beam_wide": BEAM_COMPARISON_ENERGY_PLUS_S_ALG,
            "beam_cost": RA_ADAPT_APPENDIX_BEAM_COST_COMPARISON,
            "beam_escalated": BEAM_COMPARISON_BRANCH_COMPILED_COST,
            "beam_escalated_unfiltered": (
                BEAM_COMPARISON_BRANCH_COMPILED_COST_UNFILTERED
            ),
        }
        for name, shape in RA_ADAPT_APPENDIX_BEAM_SHAPES.items():
            if observed != shape:
                continue
            if expected_mode_by_name.get(name) != mode:
                continue
            return name
    raise ValueError("The RA-ADAPT appendix method mixture is not authorized.")


def require_ra_adapt_appendix_request(request: RAAdaptRequest) -> str:
    """Authenticate the adapter, execution envelope, and exact method arm."""

    if not isinstance(request, RAAdaptRequest):
        raise TypeError("request must be an RAAdaptRequest.")
    if type(request.adapter) is not RAAdaptAppendixPureHubbardCandidateAdapter:
        raise ValueError(
            "The RA-ADAPT appendix request requires its named pure-Hubbard adapter."
        )
    horizon = int(request.execution.stop.maximum_controller_rounds)
    noise_active = request.adapter.noise_level_id is not None
    if noise_active and horizon not in RA_ADAPT_APPENDIX_NOISE_HORIZONS:
        raise ValueError(
            "The appendix noise horizon must be one of "
            f"{RA_ADAPT_APPENDIX_NOISE_HORIZONS}."
        )
    if not noise_active and not 1 <= horizon <= RA_ADAPT_APPENDIX_MAXIMUM_HORIZON:
        raise ValueError("The RA-ADAPT appendix horizon must be in [1, 20].")
    if request.execution.stop.exact_ed_target is not None:
        raise ValueError("Appendix ED is reporting-only, not controller input.")
    arm = ra_adapt_appendix_arm_id(request)
    if noise_active and arm != "baseline":
        raise ValueError(
            "The corrected appendix noise lane requires the baseline arm."
        )
    return arm


def is_ra_adapt_appendix_application(
    problem: ResolvedProblemContext | None,
    request: RAAdaptRequest,
) -> bool:
    """Return true only after authenticating the named appendix application."""

    if type(request.adapter) is not RAAdaptAppendixPureHubbardCandidateAdapter:
        return False
    if problem is None:
        raise ValueError("The RA-ADAPT appendix adapter requires its problem.")
    require_ra_adapt_appendix_pure_hubbard_problem(problem)
    require_ra_adapt_appendix_request(request)
    if request.adapter.noise_level_id is None:
        if float(problem.request.u) != 1.25:
            raise ValueError(
                "The U/t=1.5/8 appendix points require a fixed noise level."
            )
        expected_representation = (
            ra_adapt_appendix_generator_representation(
                int(problem.request.num_sites)
            )
        )
        if (
            str(request.adapter.candidate_representation_id)
            != expected_representation
        ):
            raise ValueError(
                "The appendix generator representation must match the "
                "lattice size: guarded single-Pauli at L=2 and sector-"
                "guarded composite generators at L=3."
            )
        _require_appendix_problem_lock(problem)
    else:
        sites = int(problem.request.num_sites)
        if sites not in {2, 3}:
            raise ValueError(
                "The corrected appendix noise lane requires L=2 or L=3."
            )
        if sites == 2 and float(problem.request.u) == 1.25:
            raise ValueError(
                "The corrected noise lane does not admit the L=2 U/t=1.25 "
                "noiseless comparison point."
            )
        if sites == 3:
            expected_representation = (
                ra_adapt_appendix_generator_representation(sites)
            )
            if (
                str(request.adapter.candidate_representation_id)
                != expected_representation
            ):
                raise ValueError(
                    "The L=3 noise lane requires the sector-guarded "
                    "composite generator supply."
                )
        _require_appendix_noise_problem_lock(problem)
    return True


def is_ra_adapt_appendix_noise_application(
    problem: ResolvedProblemContext | None,
    request: RAAdaptRequest,
) -> bool:
    """Authenticate only the corrected append-only controller-noise lane."""

    if type(request.adapter) is not RAAdaptAppendixPureHubbardCandidateAdapter:
        return False
    if request.adapter.noise_level_id is None:
        return False
    is_ra_adapt_appendix_application(problem, request)
    return True


def preflight_ra_adapt_appendix(
    problem: ResolvedProblemContext,
    request: RAAdaptRequest,
) -> ResolvedRAAdaptProtocol:
    """Resolve the active RA protocol after named-application validation."""

    is_ra_adapt_appendix_application(problem, request)
    from pipelines.static_adapt.ra_adapt.engine import (
        build_resolved_ra_protocol,
    )

    protocol = build_resolved_ra_protocol(problem, request)
    lock = (
        _require_appendix_noise_problem_lock(problem)
        if request.adapter.noise_level_id is not None
        else _require_appendix_problem_lock(problem)
    )
    _require_appendix_inventory_lock(protocol, lock=lock)
    return protocol


def ra_adapt_appendix_application_source_contract(
    problem: ResolvedProblemContext,
    request: RAAdaptRequest,
) -> dict[str, Any]:
    """Bind one cell to exact physics, pool, route, and optional noise."""

    protocol = preflight_ra_adapt_appendix(problem, request)
    noise_active = request.adapter.noise_level_id is not None
    lock = (
        _require_appendix_noise_problem_lock(problem)
        if noise_active
        else _require_appendix_problem_lock(problem)
    )
    route = protocol.route_contract
    if route is None:
        raise RuntimeError("The appendix protocol lost its route contract.")
    payload = {
        "schema": (
            "ra_adapt_appendix_pure_hubbard_noise_application_source_v1"
            if noise_active
            else "ra_adapt_appendix_pure_hubbard_application_source_v1"
        ),
        "application_id": RA_ADAPT_APPENDIX_PURE_HUBBARD_APPLICATION_ID,
        "arm": ra_adapt_appendix_arm_id(request),
        "problem_lock": dict(lock),
        "parent_inventory": protocol.parent_inventory.to_dict(),
        "singleton_inventory": protocol.executable_pool.to_dict(),
        "method": request.method.to_dict(),
        "horizon": int(request.execution.stop.maximum_controller_rounds),
        "algorithm_id": protocol.algorithm_id,
        "protocol_sha256": protocol.sha256,
        "route_profile": str(route["route_profile"]),
        "route_contract_sha256": str(route["sha256"]),
        "noise": (
            None
            if not noise_active
            else dict(
                route["execution_settings"]["ra_controller_noise_contract"]
            )
        ),
        "exact_reference": {
            "energy": float(problem.exact_target.resolve_energy()),
            "controller_input": False,
            "comparison_space": str(problem.exact_comparison_space_label),
        },
    }
    return {**payload, "sha256": canonical_sha256(payload)}


__all__ = [
    "RA_ADAPT_APPENDIX_ARMS",
    "RA_ADAPT_APPENDIX_NOISE_APPLICATION_LANE",
    "RA_ADAPT_APPENDIX_NOISE_HORIZONS",
    "RA_ADAPT_APPENDIX_NOISELESS_APPLICATION_LANE",
    "RA_ADAPT_APPENDIX_GENERATOR_REPRESENTATIONS",
    "RA_ADAPT_APPENDIX_BEAM_COST_COMPARISON",
    "RA_ADAPT_APPENDIX_BEAM_SHAPES",
    "RA_ADAPT_APPENDIX_PRUNE_GATED_PROTECT_STEPS",
    "RA_ADAPT_APPENDIX_PRUNE_GATED_SMALL_THETA_ABS",
    "RA_ADAPT_APPENDIX_PRUNE_GATED_MAX_PREDICTED_LOSS_PER_COST",
    "RA_ADAPT_APPENDIX_PRUNE_PROTECT_STEPS_ABLATIONS",
    "RA_ADAPT_APPENDIX_PURE_HUBBARD_ADAPTER_ID",
    "RA_ADAPT_APPENDIX_SITE_GENERATOR_REPRESENTATION",
    "RA_ADAPT_APPENDIX_PURE_HUBBARD_LOCKS",
    "RA_ADAPT_APPENDIX_PURE_HUBBARD_NOISE_LOCKS",
    "RAAdaptAppendixPureHubbardCandidateAdapter",
    "build_ra_adapt_appendix_noise_problem",
    "build_ra_adapt_appendix_noise_request",
    "build_ra_adapt_appendix_pure_hubbard_problem",
    "build_ra_adapt_appendix_request",
    "is_ra_adapt_appendix_application",
    "is_ra_adapt_appendix_noise_application",
    "preflight_ra_adapt_appendix",
    "ra_adapt_appendix_application_source_contract",
    "ra_adapt_appendix_arm_id",
    "ra_adapt_appendix_generator_representation",
    "require_ra_adapt_appendix_request",
]
