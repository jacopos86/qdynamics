"""Neutral accepted-prefix evidence for the RA-ADAPT appendix studies.

The selector's Qiskit rows are marginal, pre-prune trial costs.  They are not
the resources of the accepted circuit.  This module instead reconstructs each
already-authenticated post-prune prefix, compiles it under one exact backend
convention, and joins it to the pruning and fork-local beam decisions that
produced that accepted state.
"""

from __future__ import annotations

import copy
from importlib import metadata as importlib_metadata
import math
from typing import Any, Mapping, Sequence

import numpy as np

from pipelines.hardcoded.adapt_circuit_execution import (
    build_structural_ansatz_circuit,
)
from pipelines.qiskit_backend_tools import (
    compile_circuit_for_backend,
    compiled_gate_stats,
    resolve_backend_targets,
    safe_circuit_depth,
)
from pipelines.static_adapt.ra_adapt.appendix_demos import (
    RA_ADAPT_APPENDIX_NOISE_APPLICATION_LANE,
    RA_ADAPT_APPENDIX_NOISELESS_APPLICATION_LANE,
)
from pipelines.static_adapt.ra_adapt.contracts import canonical_sha256
from pipelines.static_adapt.ra_adapt.replay_evidence import (
    validate_controller_replay_evidence,
)
from pipelines.static_adapt.estimator_call_ledger import (
    projective_state_fingerprint,
)
from pipelines.static_adapt.selector_query_closure import (
    projective_state_fingerprint as selector_state_fingerprint,
)
from pipelines.static_adapt.sr_snake.contracts import (
    BEAM_COMPARISON_BRANCH_COMPILED_COST,
    BEAM_DIAGNOSTIC_LABELS_WITH_RECORDED_SCORE,
    BEAM_PRICED_CHILD_FIELDS_BY_LABEL,
    beam_comparison_priced_child_fields,
    BEAM_COMPARISON_PHASE3_GAIN_OVER_BURDEN,
    beam_comparison_carries_recorded_score,
    beam_comparison_diagnostic_label,
    resolved_beam_comparison,
    BeamOff,
    ForkLocalBeam,
    MetricPruning,
    PruningOff,
    RecoverabilityPruneReceipt,
)
from pipelines.static_adapt.sr_snake._controller import (
    _BEAM_SIBLING_DIVERSITY_POLICY,
    _validate_beam_sibling_diversity_receipt,
)
from src.quantum.ansatz_parameterization import serialize_layout
from src.quantum.compiled_ansatz import CompiledAnsatzExecutor
from src.quantum.pauli_polynomial_class import PauliPolynomial
from src.quantum.qubitization_module import PauliTerm
from src.quantum.vqe_latex_python_pairs import AnsatzTerm


RA_ADAPT_ACCEPTED_RUN_EVIDENCE_SCHEMA = "ra_adapt_accepted_run_evidence_v1"
RA_ADAPT_ACCEPTED_PREFIX_COMPILE_SCHEMA = (
    "ra_adapt_accepted_prefix_fake_marrakesh_compile_v1"
)
RA_ADAPT_ACCEPTED_RUN_IDENTITY_SCHEMA = (
    "ra_adapt_accepted_run_scientific_identity_v1"
)
_APPENDIX_APPLICATION_LANES = {
    RA_ADAPT_APPENDIX_NOISELESS_APPLICATION_LANE,
    RA_ADAPT_APPENDIX_NOISE_APPLICATION_LANE,
}
_COMPILE_CACHE: dict[str, dict[str, Any]] = {}
_COMPILE_CACHE_MAXIMUM = 512
_TARGET_CACHE: tuple[Any, dict[str, Any]] | None = None


def _mapping(value: Any, *, owner: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{owner} must be a mapping.")
    return value


def _sequence(value: Any, *, owner: str) -> Sequence[Any]:
    if not isinstance(value, Sequence) or isinstance(
        value, (str, bytes, bytearray)
    ):
        raise ValueError(f"{owner} must be a sequence.")
    return value


def _signed(payload: Mapping[str, Any]) -> dict[str, Any]:
    unsigned = copy.deepcopy(dict(payload))
    unsigned.pop("sha256", None)
    return {**unsigned, "sha256": canonical_sha256(unsigned)}


def _verify_signed(
    value: Any,
    *,
    owner: str,
    signature_field: str = "sha256",
) -> dict[str, Any]:
    payload = dict(_mapping(value, owner=owner))
    observed = payload.pop(signature_field, None)
    if observed != canonical_sha256(payload):
        raise ValueError(f"{owner} digest is invalid.")
    return {**payload, signature_field: observed}


def _package_version(name: str) -> str:
    try:
        return str(importlib_metadata.version(name))
    except importlib_metadata.PackageNotFoundError:
        return "unavailable"


def _compile_target() -> tuple[Any, dict[str, Any]]:
    global _TARGET_CACHE
    if _TARGET_CACHE is not None:
        return _TARGET_CACHE
    targets, audit = resolve_backend_targets(
        requested_names=("FakeMarrakesh",),
        preferred_fake_backends=("FakeMarrakesh",),
        allow_preferred_fallback=False,
        fallback_mode="single",
        allow_runtime_lookup=False,
    )
    if len(targets) != 1:
        raise RuntimeError(
            "Accepted-prefix evidence requires exactly one FakeMarrakesh target."
        )
    target = targets[0]
    if (
        target.requested_name != "FakeMarrakesh"
        or target.resolved_name != "FakeMarrakesh"
        or target.resolution_kind != "fake_exact"
        or target.using_fake_backend is not True
        or len(audit) != 1
        or audit[0].get("success") is not True
        or audit[0].get("resolution_kind") != "fake_exact"
    ):
        raise RuntimeError(
            "Accepted-prefix evidence refused a non-exact backend resolution."
        )
    snapshot = copy.deepcopy(dict(target.target_snapshot))
    compile_contract = _signed(
        {
            "schema": RA_ADAPT_ACCEPTED_PREFIX_COMPILE_SCHEMA,
            "requested_backend": "FakeMarrakesh",
            "resolved_backend": "FakeMarrakesh",
            "resolution_kind": "fake_exact",
            "preferred_backend_fallback_allowed": False,
            "runtime_lookup_allowed": False,
            "optimization_level": 1,
            "seed_transpiler": 7,
            "structure_theta_value": 1.0,
            "reference_state_included": True,
            "initial_layout": None,
            "N2q_semantics": (
                "post_transpile_two_qubit_quantum_ops_excluding_"
                "barrier_delay_id_measure_reset"
            ),
            "D2q_semantics": "post_transpile_two_qubit_layer_depth",
            "Dc_semantics": "post_transpile_total_circuit_depth",
            "target_snapshot": snapshot,
            "target_snapshot_sha256": canonical_sha256(snapshot),
            "qiskit_version": _package_version("qiskit"),
        }
    )
    _TARGET_CACHE = (target.backend_obj, compile_contract)
    return _TARGET_CACHE


def _reference_state(run: Any) -> tuple[np.ndarray, dict[str, Any]]:
    canonical_reporting = getattr(run, "canonical_reporting", None)
    receipt = getattr(canonical_reporting, "reference_state", None)
    if receipt is None or not hasattr(receipt, "to_dict"):
        raise ValueError("Accepted-run evidence requires a typed reference state.")
    payload = dict(receipt.to_dict())
    real = np.asarray(payload.get("amplitudes_real", ()), dtype=float)
    imaginary = np.asarray(
        payload.get("amplitudes_imaginary", ()), dtype=float
    )
    qubits = int(payload.get("qubit_count", 0))
    state = real.astype(complex) + 1.0j * imaginary.astype(complex)
    if (
        qubits < 1
        or state.size != 1 << qubits
        or not np.all(np.isfinite(state))
        or not math.isclose(
            float(np.vdot(state, state).real),
            1.0,
            rel_tol=0.0,
            abs_tol=1.0e-10,
        )
    ):
        raise ValueError("Accepted-run reference-state payload is invalid.")
    return state, payload


def _pool_manifest_from_inventory(
    *,
    protocol: Any,
    executable_pool: Any,
) -> list[dict[str, Any]]:
    candidates = getattr(executable_pool, "candidates", None)
    receipt = getattr(executable_pool, "receipt", None)
    if not isinstance(candidates, tuple) or receipt != protocol.executable_pool:
        raise ValueError(
            "Accepted-run evidence received a foreign executable pool."
        )
    rows: list[dict[str, Any]] = []
    for candidate in candidates:
        manifest_row = getattr(candidate, "manifest_row", None)
        if not callable(manifest_row):
            raise TypeError(
                "Accepted-run executable candidates require manifest rows."
            )
        row = copy.deepcopy(dict(manifest_row()))
        if row.pop("representation_id", None) != (
            protocol.candidate_representation
        ):
            raise ValueError(
                "Accepted-run executable candidate representation drifted."
            )
        rows.append(row)
    _authenticated_pool_manifest(protocol=protocol, value=rows)
    return rows


def _authenticated_pool_manifest(
    *,
    protocol: Any,
    value: Any,
) -> dict[str, dict[str, Any]]:
    rows = [
        dict(_mapping(row, owner="accepted-run executable-pool row"))
        for row in _sequence(
            value,
            owner="accepted-run executable-pool manifest",
        )
    ]
    expected_keys = {
        "label",
        "generator_identity",
        "parent_identities",
        "family_id",
        "stage_family",
        "construction",
        "execution_mode",
        "serialized_terms_exyz",
        "symmetry_receipt",
    }
    labels = [str(row.get("label", "")) for row in rows]
    generator_ids = [
        str(row.get("generator_identity", "")) for row in rows
    ]
    receipt = protocol.executable_pool
    if (
        any(set(row) != expected_keys for row in rows)
        or not rows
        or any(not value for value in labels)
        or any(not value for value in generator_ids)
        or len(labels) != len(set(labels))
        or len(generator_ids) != len(set(generator_ids))
        or len(rows) != int(receipt.count)
        or tuple(labels) != tuple(receipt.ordered_labels)
        or canonical_sha256(labels) != receipt.ordered_labels_sha256
        or canonical_sha256(rows) != receipt.ordered_pool_sha256
    ):
        raise ValueError(
            "Accepted-run executable-pool manifest disagrees with its "
            "protocol content address."
        )
    return {
        generator_id: copy.deepcopy(row)
        for generator_id, row in zip(generator_ids, rows, strict=True)
    }


def _checkpoint_operators(
    checkpoint: Mapping[str, Any],
    *,
    num_qubits: int,
    pool_by_generator_id: Mapping[str, Mapping[str, Any]],
) -> tuple[AnsatzTerm, ...]:
    labels = [
        str(value)
        for value in _sequence(
            checkpoint.get("ordered_active_operator_labels"),
            owner="accepted prefix labels",
        )
    ]
    rows = list(
        _sequence(
            checkpoint.get("ordered_active_operators"),
            owner="accepted prefix operators",
        )
    )
    active_depth = int(checkpoint.get("active_ansatz_depth", -1))
    if active_depth < 1 or len(labels) != active_depth or len(rows) != active_depth:
        raise ValueError("Accepted-prefix depth and operator rows disagree.")
    operators: list[AnsatzTerm] = []
    for index, (label, raw_row) in enumerate(zip(labels, rows, strict=True)):
        row = _mapping(raw_row, owner=f"accepted prefix operator {index}")
        generator_id = str(row.get("generator_id", ""))
        pool_row = pool_by_generator_id.get(generator_id)
        terms = _sequence(
            row.get("serialized_terms_exyz_in_execution_order"),
            owner=f"accepted prefix operator {index} terms",
        )
        if (
            int(row.get("active_position", -1)) != index
            or row.get("label") != label
            or not terms
            or not isinstance(pool_row, Mapping)
            or pool_row.get("label") != label
            or pool_row.get("execution_mode") != row.get("execution_mode")
            or list(terms) != list(pool_row.get("serialized_terms_exyz", ()))
        ):
            raise ValueError(
                "Accepted-prefix operator escaped its executable-pool "
                "identity."
            )
        polynomial = PauliPolynomial("JW")
        for term_index, raw_term in enumerate(terms):
            term = _mapping(
                raw_term,
                owner=f"accepted prefix operator {index} term {term_index}",
            )
            raw_pauli = str(term.get("pauli_exyz", ""))
            pauli = raw_pauli.lower()
            nq = int(term.get("nq", -1))
            coefficient = complex(
                float(term.get("coeff_re", 0.0)),
                float(term.get("coeff_im", 0.0)),
            )
            if (
                nq != num_qubits
                or raw_pauli != pauli
                or len(pauli) != num_qubits
                or set(pauli).difference({"e", "x", "y", "z"})
                or set(pauli) == {"e"}
                or not math.isfinite(coefficient.real)
                or not math.isfinite(coefficient.imag)
                or abs(coefficient) <= 1.0e-12
            ):
                raise ValueError("Accepted-prefix serialized Pauli term is invalid.")
            polynomial.add_term(
                PauliTerm(nq, ps=pauli, pc=coefficient)
            )
        operators.append(
            AnsatzTerm(
                label=label,
                polynomial=polynomial,
                execution_mode=str(
                    row.get("execution_mode") or "termwise_product"
                ),
            )
        )
    return tuple(operators)


def _compile_prefix(
    *,
    wrapper: Mapping[str, Any],
    run: Any,
    compile_contract: Mapping[str, Any],
    backend: Any,
    pool_by_generator_id: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    checkpoint = _verify_signed(
        wrapper.get("active_prefix_checkpoint"),
        owner="accepted active-prefix checkpoint",
        signature_field="checkpoint_sha256",
    )
    controller_round = int(wrapper.get("controller_round", -1))
    if (
        checkpoint.get("schema")
        != "paper_i_signed_active_prefix_checkpoint_v1"
        or int(checkpoint.get("outer_iteration", -1)) != controller_round
        or wrapper.get("source_checkpoint_sha256")
        != checkpoint.get("checkpoint_sha256")
    ):
        raise ValueError("Accepted prefix wrapper and checkpoint disagree.")
    reference_state, reference_payload = _reference_state(run)
    num_qubits = int(reference_payload["qubit_count"])
    operators = _checkpoint_operators(
        checkpoint,
        num_qubits=num_qubits,
        pool_by_generator_id=pool_by_generator_id,
    )
    layout, circuit = build_structural_ansatz_circuit(
        operators,
        nq=num_qubits,
        ref_state=reference_state,
        structure_theta_value=1.0,
    )
    if serialize_layout(layout) != checkpoint.get("parameterization"):
        raise ValueError(
            "Accepted-prefix serialized layout disagrees with its operators."
        )
    parameterization_mode = str(
        checkpoint.get("parameterization_mode", "")
    )
    if parameterization_mode not in {"logical_shared", "per_pauli_term"}:
        raise ValueError("Accepted-prefix parameterization mode is invalid.")
    replay_theta = np.asarray(
        checkpoint[
            "signed_unwrapped_runtime_parameters"
            if parameterization_mode == "per_pauli_term"
            else "signed_unwrapped_logical_parameters"
        ],
        dtype=float,
    )
    executor = CompiledAnsatzExecutor(
        operators,
        ignore_identity=True,
        sort_terms=True,
        parameterization_mode=parameterization_mode,
        parameterization_layout=layout,
    )
    replayed_state = executor.prepare_state(replay_theta, reference_state)
    if projective_state_fingerprint(replayed_state) != checkpoint.get(
        "projective_state_fingerprint"
    ):
        raise ValueError(
            "Accepted-prefix physical operators do not replay its state."
        )
    prune_state_fingerprint = selector_state_fingerprint(replayed_state)
    prune_receipt = _mapping(
        checkpoint.get("post_admission_prune"),
        owner="accepted-prefix post-admission prune receipt",
    )
    if prune_receipt.get("final_state_fingerprint") not in {
        None,
        prune_state_fingerprint,
    }:
        raise ValueError(
            "Accepted-prefix prune endpoint does not replay its state."
        )
    input_payload = {
        "schema": "ra_adapt_accepted_prefix_compile_input_v1",
        "controller_round": controller_round,
        "source_checkpoint_sha256": checkpoint["checkpoint_sha256"],
        "ordered_active_operators": copy.deepcopy(
            checkpoint["ordered_active_operators"]
        ),
        "parameterization": copy.deepcopy(checkpoint["parameterization"]),
        "reference_state": reference_payload,
        "structure_theta_value": 1.0,
        "reference_state_included": True,
        "compile_contract_sha256": compile_contract["sha256"],
    }
    input_sha256 = canonical_sha256(input_payload)
    cached = _COMPILE_CACHE.get(input_sha256)
    if cached is not None:
        return copy.deepcopy(cached)
    compiled_info = compile_circuit_for_backend(
        circuit,
        backend,
        seed_transpiler=7,
        optimization_level=1,
        initial_layout=None,
    )
    compiled = compiled_info["compiled"]
    stats = compiled_gate_stats(compiled)
    result = {
        "status": "available",
        "compile_input_sha256": input_sha256,
        "post_admission_prune_state_fingerprint": prune_state_fingerprint,
        "N2q": int(stats["compiled_count_2q"]),
        "D2q": int(stats["compiled_depth_2q"]),
        "Dc": int(safe_circuit_depth(compiled)),
    }
    if (
        min(result["N2q"], result["D2q"], result["Dc"]) < 0
        or result["Dc"] < result["D2q"]
    ):
        raise RuntimeError("Accepted-prefix compiled metrics are invalid.")
    if len(_COMPILE_CACHE) >= _COMPILE_CACHE_MAXIMUM:
        _COMPILE_CACHE.pop(next(iter(_COMPILE_CACHE)))
    _COMPILE_CACHE[input_sha256] = copy.deepcopy(result)
    return result


def _pruning_projection(
    *,
    protocol: Any,
    checkpoint: Mapping[str, Any],
    transition: Any,
    accepted_energy: float,
    accepted_prune_state_fingerprint: str,
) -> dict[str, Any]:
    raw = dict(
        _mapping(
            checkpoint.get("post_admission_prune"),
            owner="accepted-prefix post-admission prune receipt",
        )
    )
    candidate_count = int(raw.get("candidate_count", -1))
    accepted_count = int(raw.get("accepted_count", -1))
    deleted_indices = list(raw.get("deleted_indices", ()))
    deleted_labels = list(raw.get("deleted_labels", ()))
    pruning = protocol.request.method.pruning
    if isinstance(pruning, PruningOff):
        if (
            raw.get("enabled") is not False
            or raw.get("executed") is not False
            or raw.get("post_refit_executed") is not False
            or candidate_count != 0
            or accepted_count != 0
            or deleted_indices
            or deleted_labels
            or raw.get("decisions") not in ([], ())
            or raw.get("trial") is not None
            or raw.get("rolled_back") is not False
            or raw.get("live_mode_enabled") is not False
            or raw.get("final_mode_enabled") is not False
            or raw.get("permission_open") is not False
            or raw.get("metric_prune_route_active") is not False
            or raw.get("affine_deletion_fs_trust_route_active") is not False
            or raw.get("surrogate_used_for_acceptance") is not False
            or int(raw.get("nfev_phase1_prune_delete_refit", -1)) != 0
            or int(raw.get("nfev_phase1_prune_frozen_energy_probes", -1))
            != 0
            or any(
                not math.isclose(
                    float(raw.get(key, math.nan)),
                    float(accepted_energy),
                    rel_tol=0.0,
                    abs_tol=1.0e-12,
                )
                for key in (
                    "energy_before",
                    "energy_after_post_refit",
                    "energy_after_prune",
                )
            )
            or (
                hasattr(transition, "pruning")
                and transition.pruning is not None
            )
        ):
            raise ValueError("Pruning-off accepted prefix carries prune work.")
        typed_receipt = None
    elif isinstance(pruning, MetricPruning):
        trial_executed = raw.get("trial_executed") is True
        nomination_index = raw.get("nomination_index")
        nomination_label = raw.get("nomination_label")
        deleted_index = deleted_indices[0] if deleted_indices else None
        deleted_label = deleted_labels[0] if deleted_labels else None
        work = raw.get("phase1_prune_exact_refit_work_accounting")
        if (
            raw.get("schema") != "direct_recoverability_prune_transition_v1"
            or raw.get("enabled") is not True
            or raw.get("executed") is not trial_executed
            or raw.get("prune_policy") != "recoverability_ladder_v1"
            or raw.get("policy") != "recoverability_ladder_v1"
            or raw.get("permission_reason") != raw.get("reason")
            or candidate_count not in {0, 1}
            or accepted_count not in {0, 1}
            or accepted_count > candidate_count
            or len(deleted_indices) != accepted_count
            or len(deleted_labels) != accepted_count
            or candidate_count != int(nomination_index is not None)
            or (nomination_index is None) != (nomination_label is None)
            or (candidate_count == 1 and not trial_executed)
            or raw.get("endpoint_overlap_query_charge") != 0
            or raw.get("terminal_prune_active") is not False
            or raw.get("final_state_fingerprint")
            != str(accepted_prune_state_fingerprint)
            or float(raw.get("metric_damping", math.nan)) != 0.0
            or (
                trial_executed
                and accepted_count == 1
                and not math.isclose(
                    float(raw.get("energy_after", math.nan)),
                    float(accepted_energy),
                    rel_tol=0.0,
                    abs_tol=1.0e-12,
                )
            )
            or (
                trial_executed
                and accepted_count == 0
                and not math.isclose(
                    float(raw.get("energy_before", math.nan)),
                    float(accepted_energy),
                    rel_tol=0.0,
                    abs_tol=1.0e-12,
                )
            )
            or (
                trial_executed
                and (
                    not isinstance(work, Mapping)
                    or work.get("schema")
                    != "sr_v4_prune_exact_refit_work_accounting_v1"
                    or work.get("classification")
                    != (
                        "committed_prune"
                        if accepted_count == 1
                        else "discarded_prune"
                    )
                    or work.get("estimator_trial_branch_id")
                    != raw.get("trial_branch_id")
                    or work.get("included_in_all_branch_search_work")
                    is not True
                    or work.get("included_in_winning_lineage")
                    is not (accepted_count == 1)
                    or int(work.get("nfev", -1)) < 0
                )
            )
            or (not trial_executed and work is not None)
        ):
            raise ValueError("Metric-pruning accepted-prefix receipt is invalid.")
        typed_receipt = RecoverabilityPruneReceipt(
            status=str(raw.get("status", "")),
            reason=str(raw.get("reason", "")),
            policy="recoverability_ladder_v1",
            nomination_policy="metric_regularized_v1",
            source_state_fingerprint=str(
                raw.get("source_state_fingerprint", "")
            ),
            trust_radius_before=float(raw.get("trust_radius_before", math.nan)),
            trust_radius_after=float(raw.get("trust_radius_after", math.nan)),
            metric_damping=float(raw.get("metric_damping", math.nan)),
            endpoint_overlap_query_charge=int(
                raw.get("endpoint_overlap_query_charge", -1)
            ),
            terminal_prune_active=bool(raw.get("terminal_prune_active")),
            nomination_index=(
                None if nomination_index is None else int(nomination_index)
            ),
            nomination_label=(
                None if nomination_label is None else str(nomination_label)
            ),
            predicted_energy_change=raw.get("predicted_energy_change"),
            surrogate_used_for_acceptance=raw.get(
                "surrogate_used_for_acceptance"
            ),
            trial_executed=trial_executed,
            trial_branch_id=raw.get("trial_branch_id"),
            trial_classification=raw.get("trial_classification"),
            trial_s_alg=(
                int(raw.get("trial_s_alg", -1)) if trial_executed else None
            ),
            measured_energy_before=raw.get("energy_before"),
            measured_energy_after=raw.get("energy_after"),
            accepted=(accepted_count == 1 if trial_executed else None),
            deleted_index=(
                None if deleted_index is None else int(deleted_index)
            ),
            deleted_label=(
                None if deleted_label is None else str(deleted_label)
            ),
            final_state_fingerprint=str(
                raw.get("final_state_fingerprint", "")
            ),
        )
        if hasattr(transition, "pruning"):
            public_pruning = transition.pruning
            if (
                public_pruning is None
                or public_pruning.to_dict() != typed_receipt.to_dict()
            ):
                raise ValueError(
                    "Metric-pruning checkpoint disagrees with its typed "
                    "transition receipt."
                )
    else:
        raise ValueError("Accepted-run evidence has an unauthorized pruning policy.")
    return {
        "nomination_count": candidate_count,
        "accepted_deletion_count": accepted_count,
        "status": str(raw.get("status", "off")),
        "nomination_label": raw.get("nomination_label"),
        "deleted_labels": [str(value) for value in deleted_labels],
        "typed_receipt": (
            None if typed_receipt is None else typed_receipt.to_dict()
        ),
        "source_post_admission_prune_sha256": canonical_sha256(raw),
    }


def _transition_pool_indices(transition: Any) -> tuple[int, ...]:
    if hasattr(transition, "selected_pool_indices"):
        return tuple(int(value) for value in transition.selected_pool_indices)
    if hasattr(transition, "pool_index"):
        return (int(transition.pool_index),)
    admission = getattr(transition, "admission", None)
    members = getattr(admission, "members", ())
    return tuple(int(member.pool_index) for member in members)


def _transition_selected_operators(transition: Any) -> tuple[str, ...]:
    if hasattr(transition, "selected_operators"):
        return tuple(str(value) for value in transition.selected_operators)
    if hasattr(transition, "selected_operator"):
        return (str(transition.selected_operator),)
    admission = getattr(transition, "admission", None)
    members = getattr(admission, "members", ())
    return tuple(str(member.selected_operator) for member in members)


def _priced_value(value: Any) -> Any:
    """Priced child fields are numeric except the Pareto flag, which is a bool."""

    return bool(value) if isinstance(value, bool) else float(value)


def _beam_execution_projection(value: Any) -> dict[str, Any] | None:
    """Retain beam topology while retiring unauthenticated child work splits."""

    if value in (None, {}):
        return None
    source = _mapping(value, owner="accepted-run source beam diagnostics")
    _label = str(source.get("comparison"))
    _beam_carries_comparison_score = (
        _label in BEAM_DIAGNOSTIC_LABELS_WITH_RECORDED_SCORE
    )
    _priced_fields = BEAM_PRICED_CHILD_FIELDS_BY_LABEL.get(_label, ())
    rounds = []
    for raw_round in _sequence(
        source.get("rounds"),
        owner="accepted-run source beam rounds",
    ):
        round_row = _mapping(
            raw_round,
            owner="accepted-run source beam round",
        )
        parent_rows = []
        for raw_parent in _sequence(
            round_row.get("parent_rows"),
            owner="beam source parent rows",
        ):
            parent = _mapping(raw_parent, owner="beam source parent")
            parent_rows.append(
                {
                    "parent_branch_id": parent.get("parent_branch_id"),
                    "children_executed": int(parent["children_executed"]),
                    "unchanged_parent_retained": bool(
                        parent["unchanged_parent_retained"]
                    ),
                }
            )
        children = []
        for raw_child in _sequence(
            round_row.get("children"),
            owner="beam source children",
        ):
            child = _mapping(raw_child, owner="beam source child")
            # The Phase-III comparison is a per-round marginal ratio that
            # cannot be rebuilt from lineage totals, so that mode carries the
            # branch's own score.  The canonical mode is recomputable from
            # lineage totals and keeps its original payload byte for byte.
            score_carried = (
                {"comparison_score": float(child["comparison_score"])}
                if _beam_carries_comparison_score
                else {}
            )
            children.append(
                {
                    **score_carried,
                    **{
                        field: _priced_value(child[field])
                        for field in _priced_fields
                    },
                    "branch_id": str(child["branch_id"]),
                    "parent_branch_id": child.get("parent_branch_id"),
                    "accepted_energy": float(child["accepted_energy"]),
                    "selected_pool_indices": [
                        int(index)
                        for index in _sequence(
                            child.get("selected_pool_indices"),
                            owner="beam source selected pool indices",
                        )
                    ],
                    "sibling_diversity_receipt": (
                        None
                        if child.get("sibling_diversity_receipt") is None
                        else _validate_beam_sibling_diversity_receipt(
                            child.get("sibling_diversity_receipt")
                        )
                    ),
                    "stop_reasons": [
                        str(reason)
                        for reason in _sequence(
                            child.get("stop_reasons"),
                            owner="beam source stop reasons",
                        )
                    ],
                }
            )
        rounds.append(
            {
                "controller_round": int(round_row["controller_round"]),
                "children_executed": int(round_row["children_executed"]),
                "parent_rows": parent_rows,
                "children": children,
                "survivor_branch_ids": [
                    str(branch_id)
                    for branch_id in _sequence(
                        round_row.get("survivor_branch_ids"),
                        owner="beam source survivors",
                    )
                ],
                "terminal_reason": round_row.get("terminal_reason"),
            }
        )
    return {
        "schema": "ra_adapt_accepted_beam_execution_projection_v1",
        "source_schema": str(source.get("schema", "")),
        "comparison": str(source.get("comparison", "")),
        "s_alg_scope": str(source.get("s_alg_scope", "")),
        "calibration_status": str(source.get("calibration_status", "")),
        "unchanged_parent_survival": bool(
            source.get("unchanged_parent_survival")
        ),
        "phase_live_hysteresis": bool(source.get("phase_live_hysteresis")),
        "s_alg_weight": float(source.get("s_alg_weight", math.nan)),
        "live_parent_branches": int(
            source.get("live_parent_branches", -1)
        ),
        "admission_children_per_parent": int(
            source.get("admission_children_per_parent", -1)
        ),
        "maximum_admission_children_per_round": int(
            source.get("maximum_admission_children_per_round", -1)
        ),
        "initial_unbranched_s_alg": int(
            source.get("initial_unbranched_s_alg", -1)
        ),
        "all_executed_s_alg": int(source.get("all_executed_s_alg", -1)),
        "winning_lineage_s_alg": int(
            source.get("winning_lineage_s_alg", -1)
        ),
        "winning_comparison_score": float(
            source.get("winning_comparison_score", math.nan)
        ),
        "winning_branch_ids": [
            str(branch_id)
            for branch_id in _sequence(
                source.get("winning_branch_ids"),
                owner="beam source winning branch ids",
            )
        ],
        "rounds": rounds,
    }


def _beam_accounting_projection(
    value: Any,
    *,
    run: Any,
) -> dict[str, Any] | None:
    """Authenticate raw beam accounting and retain aggregate claims only."""

    if value in (None, {}):
        return None
    source = _mapping(value, owner="accepted-run source beam accounting")
    source_keys = {
        "schema",
        "all_executed_search_work_included",
        "winning_branch_ids",
        "winning_lineage",
        "discarded_s_alg",
        "unchanged_parent_survival",
    }
    winning = _mapping(
        source.get("winning_lineage"),
        owner="accepted-run source beam winning lineage",
    )
    winning_keys = {
        "schema",
        "contract",
        "scope",
        "unit",
        "components",
        "N_H_outer",
        "N_H_refit",
        "N_grad",
        "N_metric",
        "S_alg",
        "S_unique",
        "identity_repeat_occurrence_count",
        "includes_rejected_evaluated_candidates",
        "persistent_or_prior_run_cache_reductions_allowed",
    }
    accounting = getattr(run, "estimator_accounting", None)
    public = (
        accounting.to_dict()
        if accounting is not None and hasattr(accounting, "to_dict")
        else None
    )
    public_components = (
        public.get("winning_lineage", {}).get("components", {})
        if isinstance(public, Mapping)
        else {}
    )
    normalized_components = {
        str(key).lower(): int(component)
        for key, component in dict(winning.get("components", {})).items()
    }
    source_component_fields = {
        "n_h_outer": int(winning.get("N_H_outer", -1)),
        "n_h_refit": int(winning.get("N_H_refit", -1)),
        "n_grad": int(winning.get("N_grad", -1)),
        "n_metric": int(winning.get("N_metric", -1)),
    }
    if (
        set(source) != source_keys
        or set(winning) != winning_keys
        or source.get("schema")
        != "paper_i_fork_local_beam_accounting_v1"
        or source.get("all_executed_search_work_included") is not True
        or source.get("unchanged_parent_survival") is not False
        or not isinstance(public, Mapping)
        or normalized_components != dict(public_components)
        or source_component_fields != dict(public_components)
        or int(winning.get("S_alg", -1))
        != int(accounting.winning_lineage.s_alg)
        or int(source.get("discarded_s_alg", -1))
        != int(accounting.all_work.s_alg)
        - int(accounting.winning_lineage.s_alg)
    ):
        raise ValueError(
            "Source beam accounting disagrees with typed estimator work."
        )
    return {
        "schema": "ra_adapt_accepted_beam_accounting_projection_v1",
        "all_executed_search_work_included": True,
        "winning_branch_ids": [
            str(value)
            for value in _sequence(
                source.get("winning_branch_ids"),
                owner="source beam winning branch ids",
            )
        ],
        "all_executed_s_alg": int(accounting.all_work.s_alg),
        "winning_lineage_s_alg": int(accounting.winning_lineage.s_alg),
        "winning_lineage_components": {
            str(key): int(component)
            for key, component in public_components.items()
        },
        "discarded_s_alg": int(source["discarded_s_alg"]),
        "unchanged_parent_survival": False,
    }


def _beam_rows(
    *,
    protocol: Any,
    run: Any,
    prefixes: Sequence[Mapping[str, Any]],
    beam_diagnostics: Any,
    beam_accounting: Any,
) -> dict[int, dict[str, Any] | None]:
    beam = protocol.request.method.beam
    _beam_carries_comparison_score = bool(
        not isinstance(beam, BeamOff)
        and beam_comparison_carries_recorded_score(beam)
    )
    _carries_score = _beam_carries_comparison_score
    # The branch-compiled-cost comparison ranks on quantities that are not
    # recoverable from the rest of the receipt -- the compiled cost of each
    # sibling's whole prefix, the sibling-relative factor it produced, and the
    # descent it bought -- so they travel with the child rows.
    _priced_child_fields = (
        ()
        if isinstance(beam, BeamOff)
        else beam_comparison_priced_child_fields(beam)
    )
    if isinstance(beam, BeamOff):
        if (
            beam_diagnostics not in (None, {})
            or beam_accounting not in (None, {})
        ):
            raise ValueError("Beam-off accepted run carries beam diagnostics.")
        return {int(row["controller_round"]): None for row in prefixes}
    if not isinstance(beam, ForkLocalBeam):
        raise ValueError("Accepted-run evidence has an unauthorized beam policy.")
    diagnostics = _mapping(
        beam_diagnostics,
        owner="accepted-run beam diagnostics",
    )
    expected_diagnostic_keys = {
        "schema",
        "source_schema",
        "comparison",
        "s_alg_scope",
        "calibration_status",
        "unchanged_parent_survival",
        "phase_live_hysteresis",
        "s_alg_weight",
        "live_parent_branches",
        "admission_children_per_parent",
        "maximum_admission_children_per_round",
        "initial_unbranched_s_alg",
        "all_executed_s_alg",
        "winning_lineage_s_alg",
        "winning_comparison_score",
        "winning_branch_ids",
        "rounds",
    }
    raw_accounting = _mapping(
        beam_accounting,
        owner="accepted-run beam accounting",
    )
    expected_accounting_keys = {
        "schema",
        "all_executed_search_work_included",
        "winning_branch_ids",
        "all_executed_s_alg",
        "winning_lineage_s_alg",
        "winning_lineage_components",
        "discarded_s_alg",
        "unchanged_parent_survival",
    }
    rounds = list(
        _sequence(diagnostics.get("rounds"), owner="beam diagnostic rounds")
    )
    winning_ids = [
        str(value)
        for value in _sequence(
            diagnostics.get("winning_branch_ids"),
            owner="beam winning branch ids",
        )
    ]
    if (
        set(diagnostics) != expected_diagnostic_keys
        or diagnostics.get("schema")
        != "ra_adapt_accepted_beam_execution_projection_v1"
        or diagnostics.get("source_schema")
        != "paper_i_canonical_fork_local_beam_search_v1"
        or diagnostics.get("comparison")
        != beam_comparison_diagnostic_label(beam)
        or diagnostics.get("s_alg_scope")
        != "fork_local_cumulative_lineage"
        or diagnostics.get("calibration_status")
        != beam.calibration_status
        or diagnostics.get("unchanged_parent_survival") is not False
        or diagnostics.get("phase_live_hysteresis") is not False
        or float(diagnostics.get("s_alg_weight", math.nan))
        != float(beam.s_alg_weight)
        or int(diagnostics.get("live_parent_branches", -1))
        != beam.live_parent_branches
        or int(diagnostics.get("admission_children_per_parent", -1))
        != beam.admission_children_per_parent
        or int(diagnostics.get("maximum_admission_children_per_round", -1))
        != beam.maximum_admission_children_per_round
        or len(rounds) != len(prefixes)
        or len(winning_ids) != len(prefixes)
        or len(set(winning_ids)) != len(winning_ids)
    ):
        raise ValueError("Fork-local beam diagnostics do not match the policy.")
    accounting = getattr(run, "estimator_accounting", None)
    public_accounting = (
        accounting.to_dict()
        if accounting is not None and hasattr(accounting, "to_dict")
        else None
    )
    if (
        accounting is None
        or not isinstance(public_accounting, Mapping)
        or int(diagnostics.get("all_executed_s_alg", -1))
        != int(accounting.all_work.s_alg)
        or (
            int(diagnostics.get("initial_unbranched_s_alg", -1))
            + int(diagnostics.get("winning_lineage_s_alg", -1))
        )
        != int(accounting.winning_lineage.s_alg)
        or raw_accounting.get("schema")
        != "ra_adapt_accepted_beam_accounting_projection_v1"
        or set(raw_accounting) != expected_accounting_keys
        or raw_accounting.get("all_executed_search_work_included") is not True
        or raw_accounting.get("unchanged_parent_survival") is not False
        or raw_accounting.get("winning_branch_ids") != winning_ids
        or int(raw_accounting.get("all_executed_s_alg", -1))
        != int(accounting.all_work.s_alg)
        or int(raw_accounting.get("winning_lineage_s_alg", -1))
        != int(accounting.winning_lineage.s_alg)
        or dict(raw_accounting.get("winning_lineage_components", {}))
        != dict(public_accounting["winning_lineage"]["components"])
        or int(raw_accounting.get("discarded_s_alg", -1))
        != int(accounting.all_work.s_alg) - int(accounting.winning_lineage.s_alg)
    ):
        raise ValueError(
            "Beam diagnostics disagree with estimator accounting: "
            f"diagnostic all/winner="
            f"{diagnostics.get('all_executed_s_alg')}/"
            f"{diagnostics.get('initial_unbranched_s_alg')}+"
            f"{diagnostics.get('winning_lineage_s_alg')}, "
            f"result all/winner="
            f"{getattr(getattr(accounting, 'all_work', None), 's_alg', None)}/"
            f"{getattr(getattr(accounting, 'winning_lineage', None), 's_alg', None)}."
        )
    accepted_states = {
        int(state.controller_round): state
        for state in getattr(run, "accepted_trajectory", ())
    }
    accepted_transitions = {
        int(row.controller_round): row
        for row in getattr(run, "accepted_transitions", ())
    }
    projections: dict[int, dict[str, Any] | None] = {}
    previous_winner: str | None = None
    previous_survivors: list[str | None] = [None]
    all_child_ids: set[str] = set()
    final_winner_row: Mapping[str, Any] | None = None
    for offset, (raw_round, wrapper, winner_id) in enumerate(
        zip(rounds, prefixes, winning_ids, strict=True)
    ):
        round_row = _mapping(raw_round, owner=f"beam round {offset + 1}")
        if set(round_row) != {
            "controller_round",
            "children_executed",
            "parent_rows",
            "children",
            "survivor_branch_ids",
            "terminal_reason",
        }:
            raise ValueError("Beam execution projection has unknown round fields.")
        controller_round = int(wrapper["controller_round"])
        children = [
            dict(_mapping(value, owner="beam child"))
            for value in _sequence(round_row.get("children"), owner="beam children")
        ]
        child_ids = [str(value.get("branch_id", "")) for value in children]
        survivors = [
            str(value)
            for value in _sequence(
                round_row.get("survivor_branch_ids"),
                owner="beam survivor ids",
            )
        ]
        parent_rows = [
            dict(_mapping(value, owner="beam parent row"))
            for value in _sequence(
                round_row.get("parent_rows"), owner="beam parent rows"
            )
        ]
        if any(
            set(parent) != {
                "parent_branch_id",
                "children_executed",
                "unchanged_parent_retained",
            }
            for parent in parent_rows
        ):
            raise ValueError(
                "Beam execution projection has unknown parent fields."
            )
        if any(
            set(child) != {
                "branch_id",
                "parent_branch_id",
                "accepted_energy",
                "selected_pool_indices",
                "sibling_diversity_receipt",
                "stop_reasons",
            }
            | ({"comparison_score"} if _beam_carries_comparison_score else set())
            | set(_priced_child_fields)
            for child in children
        ):
            raise ValueError(
                "Beam execution projection has unauthenticated child fields."
            )
        parent_ids = [row.get("parent_branch_id") for row in parent_rows]
        child_count_by_parent = {
            parent_id: sum(
                child.get("parent_branch_id") == parent_id for child in children
            )
            for parent_id in parent_ids
        }
        child_selections_by_parent: dict[Any, list[tuple[int, ...]]] = {
            parent_id: [] for parent_id in parent_ids
        }
        child_arithmetic_valid = True
        for child in children:
            branch_id = str(child.get("branch_id", ""))
            parent_id = child.get("parent_branch_id")
            selected_pool_indices = tuple(
                int(value)
                for value in _sequence(
                    child.get("selected_pool_indices"),
                    owner="beam child selected pool indices",
                )
            )
            diversity_raw = child.get("sibling_diversity_receipt")
            diversity_policy = _mapping(
                protocol.route_contract.get("semantic_invariants"),
                owner="beam route semantic invariants",
            ).get("beam_sibling_diversity_policy")
            if diversity_policy == _BEAM_SIBLING_DIVERSITY_POLICY:
                diversity = _validate_beam_sibling_diversity_receipt(
                    diversity_raw,
                    expected_controller_round=controller_round - 1,
                    expected_selected_pool_indices=selected_pool_indices,
                    expected_branch_id=branch_id,
                    expected_parent_branch_id=(
                        None if parent_id is None else str(parent_id)
                    ),
                )
                if diversity["parent_branch_id"] != parent_id:
                    child_arithmetic_valid = False
            elif diversity_raw is not None:
                child_arithmetic_valid = False
                diversity = None
            else:
                diversity = None
            energy = float(child.get("accepted_energy", math.nan))
            stop_reasons = [
                str(value)
                for value in _sequence(
                    child.get("stop_reasons"),
                    owner="beam child stop reasons",
                )
            ]
            if (
                branch_id in all_child_ids
                or parent_id not in previous_survivors
                or len(selected_pool_indices) != 1
                or any(
                    value < 0 or value >= int(protocol.executable_pool.count)
                    for value in selected_pool_indices
                )
                or not math.isfinite(energy)
                or len(stop_reasons) != len(set(stop_reasons))
                or not set(stop_reasons).issubset(
                    {"maximum_controller_rounds", "exact_ed_target_reached"}
                )
            ):
                child_arithmetic_valid = False
            all_child_ids.add(branch_id)
            child_selections_by_parent.setdefault(parent_id, []).append(
                selected_pool_indices
            )
        winner_rows = [
            child
            for child in children
            if child.get("branch_id") == winner_id
            and child.get("parent_branch_id") == previous_winner
        ]
        checkpoint = _mapping(
            wrapper.get("active_prefix_checkpoint"),
            owner="beam winning checkpoint",
        )
        ledger = _mapping(
            checkpoint.get("estimator_ledger_receipt"),
            owner="beam checkpoint estimator receipt",
        )
        state = accepted_states.get(controller_round)
        transition = accepted_transitions.get(controller_round)
        terminal_reason = round_row.get("terminal_reason")
        # Pareto-filtered comparisons can leave fewer eligible branches than
        # the configured width, and the beam then narrows rather than filling
        # itself with branches it has already ruled out.  Comparisons that do
        # not filter mark no child dominated, so this reduces to the previous
        # count for them.
        eligible_children = [
            child
            for child in children
            if not bool(child.get("pareto_dominated", False))
        ]
        expected_survivor_count = (
            1
            if terminal_reason is not None
            else min(
                beam.live_parent_branches,
                len(eligible_children) or len(children),
            )
        )
        if (
            int(round_row.get("controller_round", -1)) != controller_round
            or int(round_row.get("children_executed", -1)) != len(children)
            or not children
            or len(child_ids) != len(set(child_ids))
            or any(not value for value in child_ids)
            or len(children) > beam.maximum_admission_children_per_round
            or len(parent_ids) != len(set(parent_ids))
            or set(parent_ids) != set(previous_survivors)
            or any(
                int(parent.get("children_executed", -1))
                != child_count_by_parent[parent.get("parent_branch_id")]
                or int(parent.get("children_executed", -1))
                > beam.admission_children_per_parent
                or parent.get("unchanged_parent_retained") is not False
                for parent in parent_rows
            )
            or any(
                len(selections) != len(set(selections))
                for selections in child_selections_by_parent.values()
            )
            or not child_arithmetic_valid
            or len(survivors) != len(set(survivors))
            or len(survivors) != expected_survivor_count
            or not set(survivors).issubset(set(child_ids))
            or winner_id not in survivors
            or len(winner_rows) != 1
            or terminal_reason
            not in {None, "maximum_controller_rounds", "exact_ed_target_reached"}
            or (
                terminal_reason is None
                and any(child.get("stop_reasons") for child in children)
            )
            or (
                terminal_reason is not None
                and terminal_reason not in winner_rows[0].get("stop_reasons", ())
            )
            or ledger.get("branch_id") != winner_id
            or ledger.get("parent_branch_id") != previous_winner
            or state is None
            or transition is None
            or _transition_pool_indices(transition)
            != tuple(
                int(value)
                for value in winner_rows[0].get("selected_pool_indices", ())
            )
            or (
                _mapping(
                    protocol.route_contract.get("semantic_invariants"),
                    owner="beam route semantic invariants",
                ).get("beam_sibling_diversity_policy")
                == _BEAM_SIBLING_DIVERSITY_POLICY
                and _validate_beam_sibling_diversity_receipt(
                    winner_rows[0].get("sibling_diversity_receipt"),
                    expected_controller_round=controller_round - 1,
                    expected_parent_state_fingerprint=str(
                        transition.preceding_state_fingerprint
                    ),
                    expected_selected_pool_indices=(
                        _transition_pool_indices(transition)
                    ),
                    expected_branch_id=str(
                        winner_rows[0].get("branch_id", "")
                    ),
                    expected_parent_branch_id=(
                        None
                        if winner_rows[0].get("parent_branch_id") is None
                        else str(
                            winner_rows[0].get("parent_branch_id")
                        )
                    ),
                )
                is None
            )
            or not math.isclose(
                float(winner_rows[0].get("accepted_energy", math.nan)),
                float(state.energy),
                rel_tol=0.0,
                abs_tol=1.0e-12,
            )
        ):
            raise ValueError(
                f"Fork-local beam round {controller_round} is not closed."
            )
        projections[controller_round] = {
            "children": [
                {
                    "branch_id": str(child["branch_id"]),
                    "parent_branch_id": child.get("parent_branch_id"),
                    "selected_pool_indices": [
                        int(value)
                        for value in child["selected_pool_indices"]
                    ],
                    "sibling_diversity_receipt": copy.deepcopy(
                        child["sibling_diversity_receipt"]
                    ),
                    "accepted_energy": float(child["accepted_energy"]),
                    **(
                        {
                            "comparison_score": float(
                                child["comparison_score"]
                            )
                        }
                        if _carries_score
                        else {}
                    ),
                    **{
                        field: _priced_value(child[field])
                        for field in _priced_child_fields
                    },
                    "stop_reasons": [
                        str(value) for value in child["stop_reasons"]
                    ],
                }
                for child in children
            ],
            "survivor_branch_ids": survivors,
            "winning_branch_id": winner_id,
        }
        previous_survivors = list(survivors)
        previous_winner = winner_id
        final_winner_row = winner_rows[0]
    if final_winner_row is None:
        raise ValueError("Fork-local beam terminal accounting is not closed.")
    if beam_comparison_carries_recorded_score(beam):
        # These comparisons rank by a ratio -- Phase-III trust gain over the
        # per-record burden, or branch descent over the sibling-relative
        # compiled cost -- so the terminal score is not a function of the
        # lineage totals.  Close it against the winning branch's own recorded
        # score instead.
        if not math.isclose(
            float(diagnostics.get("winning_comparison_score", math.nan)),
            float(final_winner_row.get("comparison_score", math.nan)),
            rel_tol=0.0,
            abs_tol=1.0e-12,
        ):
            raise ValueError(
                "Fork-local beam terminal accounting is not closed."
            )
    elif not math.isclose(
        float(diagnostics.get("winning_comparison_score", math.nan)),
        float(final_winner_row.get("accepted_energy", math.nan))
        + float(beam.s_alg_weight)
        * int(diagnostics.get("winning_lineage_s_alg", -1)),
        rel_tol=0.0,
        abs_tol=1.0e-12,
    ):
        raise ValueError("Fork-local beam terminal accounting is not closed.")
    return projections


def _project_payload(
    *,
    protocol: Any,
    run: Any,
    controller_replay_evidence: Mapping[str, Any],
    executable_pool_manifest: Any,
    beam_diagnostics: Any,
    beam_accounting: Any,
) -> dict[str, Any]:
    replay = validate_controller_replay_evidence(
        controller_replay_evidence
    )
    if (
        replay.get("protocol_sha256") != str(protocol.sha256)
        or replay.get("problem_request_sha256")
        != str(getattr(getattr(run, "problem", None), "problem_request_sha256", ""))
    ):
        raise ValueError(
            "Controller replay evidence belongs to a different protocol or "
            "problem."
        )
    prefixes = [
        _verify_signed(value, owner="signed controller prefix")
        for value in _sequence(
            replay.get("signed_controller_round_prefixes"),
            owner="signed controller prefixes",
        )
    ]
    states = list(getattr(run, "accepted_trajectory", ()))
    transitions = list(getattr(run, "accepted_transitions", ()))
    if len(prefixes) != len(states) or len(prefixes) != len(transitions):
        raise ValueError(
            "Accepted-run prefixes, transitions, and trajectory do not align."
        )
    route = getattr(run, "route", None)
    route_sha256 = str(getattr(route, "contract_sha256", ""))
    protocol_route = getattr(protocol, "route_contract", None)
    invariants = (
        protocol_route.get("semantic_invariants")
        if isinstance(protocol_route, Mapping)
        else None
    )
    application_lane = (
        invariants.get("application_lane")
        if isinstance(invariants, Mapping)
        else None
    )
    if (
        application_lane not in _APPENDIX_APPLICATION_LANES
        or not isinstance(protocol_route, Mapping)
        or protocol_route.get("sha256") != route_sha256
    ):
        raise ValueError("Accepted-run evidence requires an exact appendix lane.")
    pool_manifest = [
        copy.deepcopy(
            dict(_mapping(row, owner="accepted-run executable-pool row"))
        )
        for row in _sequence(
            executable_pool_manifest,
            owner="accepted-run executable-pool manifest",
        )
    ]
    pool_by_generator_id = _authenticated_pool_manifest(
        protocol=protocol,
        value=pool_manifest,
    )
    backend, compile_contract = _compile_target()
    beam_by_round = _beam_rows(
        protocol=protocol,
        run=run,
        prefixes=prefixes,
        beam_diagnostics=beam_diagnostics,
        beam_accounting=beam_accounting,
    )
    round_rows: list[dict[str, Any]] = []
    previous_operator_labels: list[str] = []
    previous_generator_ids: list[str] = []
    for wrapper, state, transition in zip(
        prefixes,
        states,
        transitions,
        strict=True,
    ):
        controller_round = int(wrapper["controller_round"])
        checkpoint = _mapping(
            wrapper.get("active_prefix_checkpoint"),
            owner="accepted active-prefix checkpoint",
        )
        state_payload = dict(
            _mapping(wrapper.get("accepted_state"), owner="accepted state")
        )
        if (
            controller_round != int(state.controller_round)
            or controller_round != int(transition.controller_round)
            or int(checkpoint.get("active_ansatz_depth", -1))
            != len(state.operators)
            or state_payload != state.to_dict()
            or [
                str(
                    _mapping(value, owner="accepted operator identity").get(
                        "generator_id", ""
                    )
                )
                for value in _sequence(
                    checkpoint.get("ordered_active_operators"),
                    owner="accepted operator identities",
                )
            ]
            != list(state_payload.get("generator_ids", ()))
            or wrapper.get("accepted_state_sha256")
            != canonical_sha256(state_payload)
            or not math.isclose(
                float(state_payload.get("energy", math.nan)),
                float(state.energy),
                rel_tol=0.0,
                abs_tol=0.0,
            )
        ):
            raise ValueError("Accepted-run state and signed prefix disagree.")
        compile_projection = _compile_prefix(
            wrapper=wrapper,
            run=run,
            compile_contract=compile_contract,
            backend=backend,
            pool_by_generator_id=pool_by_generator_id,
        )
        pruning_projection = _pruning_projection(
            protocol=protocol,
            checkpoint=checkpoint,
            transition=transition,
            accepted_energy=float(state.energy),
            accepted_prune_state_fingerprint=str(
                compile_projection[
                    "post_admission_prune_state_fingerprint"
                ]
            ),
        )
        selected_operator_labels = _transition_selected_operators(transition)
        selected_pool_indices = _transition_pool_indices(transition)
        if (
            len(selected_operator_labels) != len(selected_pool_indices)
            or any(
                not 0 <= pool_index < len(pool_manifest)
                or pool_manifest[pool_index].get("label") != operator_label
                for operator_label, pool_index in zip(
                    selected_operator_labels,
                    selected_pool_indices,
                    strict=True,
                )
            )
        ):
            raise ValueError(
                "Accepted admission escaped its executable-pool identity."
            )
        selected_generator_ids = [
            str(pool_manifest[pool_index]["generator_identity"])
            for pool_index in selected_pool_indices
        ]
        pre_prune_operator_labels = [
            *previous_operator_labels,
            *selected_operator_labels,
        ]
        pre_prune_generator_ids = [
            *previous_generator_ids,
            *selected_generator_ids,
        ]
        deleted_labels = list(pruning_projection["deleted_labels"])
        deleted_count = int(pruning_projection["accepted_deletion_count"])
        if deleted_count == 1:
            raw_prune = _mapping(
                checkpoint.get("post_admission_prune"),
                owner="accepted prune lineage",
            )
            raw_deleted_indices = list(
                _sequence(
                    raw_prune.get("deleted_indices"),
                    owner="accepted prune deletion indices",
                )
            )
            if (
                len(raw_deleted_indices) != 1
                or not 0
                <= int(raw_deleted_indices[0])
                < len(pre_prune_generator_ids)
                or pre_prune_generator_ids[int(raw_deleted_indices[0])]
                != deleted_labels[0]
            ):
                raise ValueError("Accepted prune deletion lineage is invalid.")
            del pre_prune_operator_labels[int(raw_deleted_indices[0])]
            del pre_prune_generator_ids[int(raw_deleted_indices[0])]
        if (
            pre_prune_operator_labels != list(state.operators)
            or pre_prune_generator_ids
            != list(state_payload.get("generator_ids", ()))
        ):
            raise ValueError(
                "Accepted admission/prune lineage disagrees with its prefix."
            )
        round_rows.append(
            {
                "controller_round": controller_round,
                "accepted_energy": float(state.energy),
                "active_ansatz_depth": int(
                    checkpoint["active_ansatz_depth"]
                ),
                "signed_prefix_sha256": str(wrapper["sha256"]),
                "source_checkpoint_sha256": str(
                    wrapper["source_checkpoint_sha256"]
                ),
                "accepted_state_sha256": str(
                    wrapper["accepted_state_sha256"]
                ),
                "compile": compile_projection,
                "pruning": pruning_projection,
                "beam": beam_by_round[controller_round],
            }
        )
        previous_operator_labels = list(state.operators)
        previous_generator_ids = list(
            state_payload.get("generator_ids", ())
        )
    accounting = getattr(run, "estimator_accounting", None)
    accounting_payload = (
        accounting.to_dict()
        if accounting is not None and hasattr(accounting, "to_dict")
        else None
    )
    neutral_branch_ids: dict[str, str] = {}
    neutral_round_rows: list[dict[str, Any]] = []
    for row in round_rows:
        neutral_row = copy.deepcopy(row)
        neutral_row.pop("signed_prefix_sha256", None)
        raw_beam = neutral_row.get("beam")
        if isinstance(raw_beam, Mapping):
            neutral_children: list[dict[str, Any]] = []
            for child_ordinal, raw_child in enumerate(
                _sequence(raw_beam.get("children"), owner="beam identity children")
            ):
                child = _mapping(raw_child, owner="beam identity child")
                raw_id = str(child.get("branch_id", ""))
                neutral_id = (
                    f"round_{int(row['controller_round'])}_child_"
                    f"{child_ordinal}"
                )
                if not raw_id or raw_id in neutral_branch_ids:
                    raise ValueError("Beam identity has a repeated raw branch id.")
                raw_parent = child.get("parent_branch_id")
                if raw_parent is not None and str(raw_parent) not in neutral_branch_ids:
                    raise ValueError("Beam identity child has an unknown parent.")
                neutral_branch_ids[raw_id] = neutral_id
                neutral_children.append(
                    {
                        "branch_ordinal": neutral_id,
                        "parent_branch_ordinal": (
                            None
                            if raw_parent is None
                            else neutral_branch_ids[str(raw_parent)]
                        ),
                        "selected_pool_indices": [
                            int(value)
                            for value in child["selected_pool_indices"]
                        ],
                        "accepted_energy": float(child["accepted_energy"]),
                        "stop_reasons": [
                            str(value) for value in child["stop_reasons"]
                        ],
                    }
                )
            survivor_ordinals = [
                neutral_branch_ids[str(raw_id)]
                for raw_id in _sequence(
                    raw_beam.get("survivor_branch_ids"),
                    owner="beam identity survivors",
                )
            ]
            winner_ordinal = neutral_branch_ids[
                str(raw_beam.get("winning_branch_id", ""))
            ]
            neutral_row["beam"] = {
                "children": neutral_children,
                "survivor_branch_ordinals": survivor_ordinals,
                "winning_branch_ordinal": winner_ordinal,
            }
        neutral_round_rows.append(neutral_row)
    terminal_outcome = replay.get("terminal_controller_outcome")
    terminal_exhaustion_sha256 = replay.get(
        "terminal_combinatorial_batch_exhaustion_receipt_sha256"
    )
    terminal_exhaustion = replay.get(
        "terminal_combinatorial_batch_exhaustion_receipt"
    )
    if terminal_outcome == "combinatorial_batch_rank_gate_exhausted_v1":
        if (
            not isinstance(terminal_exhaustion, Mapping)
            or terminal_exhaustion_sha256
            != terminal_exhaustion.get("sha256")
        ):
            raise ValueError(
                "Accepted-run identity lost combinatorial exhaustion evidence."
            )
    elif terminal_exhaustion is not None or terminal_exhaustion_sha256 is not None:
        raise ValueError(
            "Non-combinatorial accepted run contains exhaustion evidence."
        )
    accepted_run_identity = _signed(
        {
            "schema": RA_ADAPT_ACCEPTED_RUN_IDENTITY_SCHEMA,
            "application_lane": str(application_lane),
            "protocol_sha256": str(protocol.sha256),
            "problem_request_sha256": str(replay["problem_request_sha256"]),
            "route_contract_sha256": route_sha256,
            "executable_pool_manifest_sha256": canonical_sha256(
                pool_manifest
            ),
            "compile_contract_sha256": str(compile_contract["sha256"]),
            "accepted_rounds": neutral_round_rows,
            "accepted_rounds_sha256": canonical_sha256(neutral_round_rows),
            **(
                {
                    "terminal_controller_outcome": terminal_outcome,
                    "terminal_combinatorial_batch_exhaustion_receipt_sha256": (
                        terminal_exhaustion_sha256
                    ),
                }
                if terminal_exhaustion_sha256 is not None
                else {}
            ),
        }
    )
    return {
        "schema": RA_ADAPT_ACCEPTED_RUN_EVIDENCE_SCHEMA,
        "application_lane": str(application_lane),
        "protocol_sha256": str(protocol.sha256),
        "problem_request_sha256": str(replay["problem_request_sha256"]),
        "route_contract_sha256": route_sha256,
        "controller_replay_evidence_sha256": str(replay["sha256"]),
        **(
            {
                "terminal_controller_outcome": terminal_outcome,
                "terminal_combinatorial_batch_exhaustion_receipt_sha256": (
                    terminal_exhaustion_sha256
                ),
            }
            if terminal_exhaustion_sha256 is not None
            else {}
        ),
        "executable_pool_manifest": pool_manifest,
        "executable_pool_manifest_sha256": canonical_sha256(pool_manifest),
        "compile_contract": copy.deepcopy(compile_contract),
        "beam_search_diagnostics": (
            None
            if beam_diagnostics in (None, {})
            else copy.deepcopy(dict(beam_diagnostics))
        ),
        "beam_search_diagnostics_sha256": (
            None
            if beam_diagnostics in (None, {})
            else canonical_sha256(dict(beam_diagnostics))
        ),
        "beam_accounting": (
            None
            if beam_accounting in (None, {})
            else copy.deepcopy(dict(beam_accounting))
        ),
        "beam_accounting_sha256": (
            None
            if beam_accounting in (None, {})
            else canonical_sha256(dict(beam_accounting))
        ),
        "estimator_accounting_sha256": canonical_sha256(accounting_payload),
        "accepted_rounds": round_rows,
        "accepted_rounds_sha256": canonical_sha256(round_rows),
        "accepted_run_identity": accepted_run_identity,
        "accepted_run_identity_sha256": accepted_run_identity["sha256"],
    }


def build_ra_adapt_accepted_run_evidence(
    *,
    protocol: Any,
    run: Any,
    finalization: Mapping[str, Any],
    controller_replay_evidence: Mapping[str, Any],
    executable_pool: Any,
) -> dict[str, Any]:
    """Build one signed, prune-aware accepted-run evidence projection."""

    final = _mapping(finalization, owner="RA finalization")
    estimator_accounting = final.get("estimator_call_accounting")
    beam_accounting = (
        estimator_accounting.get("beam_accounting")
        if isinstance(estimator_accounting, Mapping)
        else None
    )
    payload = _project_payload(
        protocol=protocol,
        run=run,
        controller_replay_evidence=controller_replay_evidence,
        executable_pool_manifest=_pool_manifest_from_inventory(
            protocol=protocol,
            executable_pool=executable_pool,
        ),
        beam_diagnostics=_beam_execution_projection(
            final.get("beam_search_diagnostics")
        ),
        beam_accounting=_beam_accounting_projection(
            beam_accounting,
            run=run,
        ),
    )
    return _signed(payload)


def validate_ra_adapt_accepted_run_evidence(
    value: Any,
    *,
    protocol: Any,
    run: Any,
    controller_replay_evidence: Mapping[str, Any],
) -> dict[str, Any]:
    """Reconstruct and compare every accepted-run evidence field."""

    observed = _verify_signed(value, owner="RA accepted-run evidence")
    expected = _signed(
        _project_payload(
            protocol=protocol,
            run=run,
            controller_replay_evidence=controller_replay_evidence,
            executable_pool_manifest=observed.get(
                "executable_pool_manifest"
            ),
            beam_diagnostics=observed.get("beam_search_diagnostics"),
            beam_accounting=observed.get("beam_accounting"),
        )
    )
    if observed != expected:
        raise ValueError(
            "RA accepted-run evidence disagrees with its authenticated run."
        )
    return observed


__all__ = [
    "RA_ADAPT_ACCEPTED_PREFIX_COMPILE_SCHEMA",
    "RA_ADAPT_ACCEPTED_RUN_EVIDENCE_SCHEMA",
    "RA_ADAPT_ACCEPTED_RUN_IDENTITY_SCHEMA",
    "build_ra_adapt_accepted_run_evidence",
    "validate_ra_adapt_accepted_run_evidence",
]
