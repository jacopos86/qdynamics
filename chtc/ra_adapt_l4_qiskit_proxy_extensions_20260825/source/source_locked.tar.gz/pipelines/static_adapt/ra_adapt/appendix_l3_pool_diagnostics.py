"""Hartree--Fock response diagnostics for the RA-ADAPT appendix pools.

The guarded single-Pauli exposure that the ``L=2`` appendix route uses is a
two-qubits-per-spin accident.  With exactly one particle in a two-qubit spin
block, a two-site Pauli flip maps the fixed-count block onto itself, so words
such as ``xxee`` survive the hard sector guard.  At ``L=3`` the spin block
carries two particles in three qubits, every off-diagonal single-Pauli word
leaves the sector, and the guard retains only diagonal ``Z`` words.

A diagonal generator ``G`` acts on a computational-basis reference as
``G|psi> = g|psi>``.  Both the energy gradient ``|<[H, G]>|`` and the tangent
self-metric ``<G^2> - <G>^2`` are then identically zero, the tangent Gram
matrix vanishes, and the controller's supported-response rank gate fires with
no supported direction.  That is a real property of the pool, not a tolerance
problem, so the pool is replaced rather than the gate relaxed.

This module measures those quantities directly so the corrected pool can be
tested and so a campaign can carry the measurement as evidence.
"""

from __future__ import annotations

import functools
from typing import Any, Mapping, Sequence

import numpy as np

from pipelines.contracts.problem import ResolvedProblemContext
from pipelines.static_adapt.ra_adapt.contracts import canonical_sha256
from pipelines.scaffold.hh_continuation_generators import (
    serialize_polynomial_terms_exyz,
)


APPENDIX_POOL_RESPONSE_DIAGNOSTICS_SCHEMA = (
    "ra_adapt_appendix_pool_hartree_fock_response_diagnostics_v1"
)

_PAULI_MATRICES = {
    "e": np.eye(2, dtype=complex),
    "x": np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex),
    "y": np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=complex),
    "z": np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex),
}


def _pauli_word_matrix(word: str) -> np.ndarray:
    """Dense matrix for one ``exyz`` word.

    The word is written most-significant qubit first, matching the register
    convention used by the serialized generator payloads and the reference
    state vector.
    """

    symbols = str(word).strip().lower()
    if not symbols or any(symbol not in _PAULI_MATRICES for symbol in symbols):
        raise ValueError(f"Unsupported Pauli word {word!r}.")
    return functools.reduce(
        np.kron, [_PAULI_MATRICES[symbol] for symbol in symbols]
    )


def _serialized_matrix(
    rows: Sequence[Mapping[str, Any]], *, total_qubits: int
) -> np.ndarray:
    dimension = 2 ** int(total_qubits)
    matrix = np.zeros((dimension, dimension), dtype=complex)
    for row in rows:
        word = str(row["pauli_exyz"])
        if len(word) != int(total_qubits):
            raise ValueError(
                "Serialized generator word does not match the register width."
            )
        coefficient = complex(
            float(row.get("coeff_re", 0.0)), float(row.get("coeff_im", 0.0))
        )
        matrix += coefficient * _pauli_word_matrix(word)
    return matrix


def _is_diagonal_word(word: str) -> bool:
    return all(symbol in {"e", "z"} for symbol in str(word).strip().lower())


def appendix_pool_response_diagnostics(
    problem: ResolvedProblemContext,
    inventory: Any,
    *,
    rank_tolerance: float = 1.0e-9,
    zero_tolerance: float = 1.0e-10,
) -> dict[str, Any]:
    """Measure the Hartree--Fock response of one candidate inventory.

    Returns the per-generator energy gradient and tangent self-metric, the
    spectrum of the tangent Gram matrix, and the supported response rank the
    controller would see at the reference state.
    """

    total_qubits = int(problem.layout.total_qubits)
    reference = np.asarray(
        problem.reference_state.build_state(), dtype=complex
    ).reshape(-1)
    if reference.size != 2 ** total_qubits:
        raise ValueError("Reference state does not match the register width.")
    hamiltonian = _serialized_matrix(
        serialize_polynomial_terms_exyz(problem.hamiltonian),
        total_qubits=total_qubits,
    )
    candidates = tuple(getattr(inventory, "candidates", ()))
    if not candidates:
        raise ValueError("Response diagnostics require a non-empty inventory.")

    rows: list[dict[str, Any]] = []
    tangents: list[np.ndarray] = []
    for candidate in candidates:
        serialized = [dict(row) for row in candidate.serialized_terms_exyz]
        generator = _serialized_matrix(serialized, total_qubits=total_qubits)
        hermiticity_defect = float(
            np.linalg.norm(generator - generator.conj().T)
        )
        applied = generator @ reference
        expectation = complex(reference.conj() @ applied)
        gradient = float(
            abs(
                complex(
                    reference.conj()
                    @ (hamiltonian @ generator - generator @ hamiltonian)
                    @ reference
                )
            )
        )
        tangent = applied - expectation * reference
        self_metric = float(np.real(tangent.conj() @ tangent))
        tangents.append(tangent)
        rows.append(
            {
                "label": str(candidate.label),
                "term_count": int(len(serialized)),
                "diagonal_only": bool(
                    all(
                        _is_diagonal_word(str(row["pauli_exyz"]))
                        for row in serialized
                    )
                ),
                "hermiticity_defect": hermiticity_defect,
                "hartree_fock_gradient_abs": gradient,
                "tangent_self_metric": self_metric,
            }
        )

    stacked = np.asarray(tangents)
    gram = stacked.conj() @ stacked.T
    eigenvalues = np.linalg.eigvalsh((gram + gram.conj().T) / 2.0)
    scale = float(max(1.0, float(np.max(np.abs(eigenvalues)))))
    threshold = float(rank_tolerance) * scale
    supported_rank = int(np.count_nonzero(eigenvalues > threshold))
    payload = {
        "schema": APPENDIX_POOL_RESPONSE_DIAGNOSTICS_SCHEMA,
        "num_sites": int(problem.request.num_sites),
        "total_qubits": total_qubits,
        "sector_num_particles": [
            int(value) for value in problem.sector.num_particles
        ],
        "candidate_representation": str(
            inventory.receipt.candidate_representation
        ),
        "ordered_pool_sha256": str(inventory.receipt.ordered_pool_sha256),
        "generator_count": int(len(rows)),
        "generators": rows,
        "diagonal_only_generator_count": int(
            sum(1 for row in rows if row["diagonal_only"])
        ),
        "all_generators_diagonal": bool(
            all(row["diagonal_only"] for row in rows)
        ),
        "nonzero_gradient_count": int(
            sum(
                1
                for row in rows
                if row["hartree_fock_gradient_abs"] > float(zero_tolerance)
            )
        ),
        "nonzero_self_metric_count": int(
            sum(
                1
                for row in rows
                if row["tangent_self_metric"] > float(zero_tolerance)
            )
        ),
        "tangent_gram_eigenvalues": [float(value) for value in eigenvalues],
        "supported_response_rank": supported_rank,
        "rank_tolerance": float(rank_tolerance),
        "zero_tolerance": float(zero_tolerance),
    }
    return {**payload, "sha256": canonical_sha256(payload)}


def require_responsive_appendix_pool(
    problem: ResolvedProblemContext,
    inventory: Any,
    *,
    rank_tolerance: float = 1.0e-9,
    zero_tolerance: float = 1.0e-10,
) -> dict[str, Any]:
    """Reject a candidate pool with no supported Hartree--Fock response.

    This is a pool-construction guard, not a relaxation of the controller's
    rank gate: it fails closed on exactly the degenerate all-diagonal
    construction that made the controller's gate fire with rank zero.
    """

    diagnostics = appendix_pool_response_diagnostics(
        problem,
        inventory,
        rank_tolerance=rank_tolerance,
        zero_tolerance=zero_tolerance,
    )
    if diagnostics["all_generators_diagonal"]:
        raise ValueError(
            "The appendix candidate pool is entirely diagonal: every "
            "generator leaves the reference state invariant up to a phase, "
            "so no Hartree--Fock response direction exists."
        )
    if diagnostics["supported_response_rank"] <= 0:
        raise ValueError(
            "The appendix candidate pool has supported response rank zero "
            "at the Hartree--Fock reference."
        )
    if diagnostics["nonzero_self_metric_count"] <= 0:
        raise ValueError(
            "No appendix candidate generator has a nonzero tangent "
            "self-metric at the Hartree--Fock reference."
        )
    return diagnostics


__all__ = [
    "APPENDIX_POOL_RESPONSE_DIAGNOSTICS_SCHEMA",
    "appendix_pool_response_diagnostics",
    "require_responsive_appendix_pool",
]
