"""Generate the failure atlas: every raise site in the algorithm layer,
categorized by what it guards.

Usage:
    python3 pipelines/shell/failure_atlas.py

Output: agent_guidance/static-adapt/failure-atlas.md (generated file —
regenerate after refactor increments; do not hand-edit).

Read-only with respect to code. Agents performing runs consult the atlas
to know the enforced contingencies before hitting them; see the
memory-budget and run-guide contracts for the run-side rules.
"""

from __future__ import annotations

import ast
import subprocess
from collections import Counter, defaultdict
from datetime import date
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
SCAN_ROOTS = (
    "pipelines/static_adapt",
    "pipelines/scaffold",
)
OUT = REPO / "agent_guidance/static-adapt/failure-atlas.md"

CATEGORIES = (
    (
        "physics_invariant",
        (
            "sector", "commut", "symmetry", "particle", "energy-safety",
            "energy safety", "hermit", "fixed-count", "spin", "boson",
            "hamiltonian mismatch", "parity",
        ),
    ),
    (
        "accounting_closure",
        (
            "s_alg", "s_unique", "partition", "ledger", "reconcil",
            "occurrence", "estimator", "accounting", "does not close",
        ),
    ),
    (
        "retirement_weld",
        ("retired", "historical affected", "quarantine", "legacy route",
         "no longer", "superseded"),
    ),
    (
        "resume_checkpoint_safety",
        ("resume", "checkpoint", "only shorten", "sha256", "replay",
         "continuation", "snapshot"),
    ),
    (
        "authority_provenance",
        ("authority", "bundle", "source lock", "source-lock", "manifest",
         "provenance", "authoriz", "materializ", "digest"),
    ),
    (
        "input_validation",
        ("must be", "expects", "requires", "invalid", "unknown", "not one of",
         "unsupported", "missing required"),
    ),
)


def categorize(message: str, func: str) -> str:
    lowered = message.lower()
    for name, markers in CATEGORIES:
        if any(marker in lowered for marker in markers):
            return name
    return "internal_consistency"


def first_string(node: ast.Raise) -> str:
    if node.exc is None:
        return "(re-raise)"
    for sub in ast.walk(node.exc):
        if isinstance(sub, ast.Constant) and isinstance(sub.value, str):
            return sub.value
        if isinstance(sub, ast.JoinedStr):
            parts = [
                v.value
                for v in sub.values
                if isinstance(v, ast.Constant) and isinstance(v.value, str)
            ]
            if parts:
                return "".join(parts)
    return "(dynamic message)"


def exc_name(node: ast.Raise) -> str:
    if node.exc is None:
        return "reraise"
    target = node.exc
    if isinstance(target, ast.Call):
        target = target.func
    return getattr(target, "id", getattr(target, "attr", "?"))


def main() -> None:
    rows = []
    for root in SCAN_ROOTS:
        for path in sorted((REPO / root).rglob("*.py")):
            rel = str(path.relative_to(REPO))
            try:
                tree = ast.parse(path.read_text(encoding="utf-8"))
            except SyntaxError:
                continue
            func_stack: dict[int, str] = {}
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    for line in range(node.lineno, (node.end_lineno or node.lineno) + 1):
                        func_stack.setdefault(line, node.name)
            for node in ast.walk(tree):
                if not isinstance(node, ast.Raise):
                    continue
                message = first_string(node)
                func = func_stack.get(node.lineno, "<module>")
                rows.append(
                    {
                        "file": rel,
                        "line": node.lineno,
                        "exc": exc_name(node),
                        "func": func,
                        "message": message,
                        "category": categorize(message, func),
                    }
                )

    by_cat = defaultdict(list)
    for row in rows:
        by_cat[row["category"]].append(row)
    counts = Counter(row["category"] for row in rows)
    file_counts = Counter(row["file"] for row in rows)

    head = subprocess.run(
        ["git", "rev-parse", "--short", "HEAD"],
        capture_output=True, text=True, cwd=REPO,
    ).stdout.strip()

    lines = []
    lines.append("# Failure Atlas — Algorithm Layer")
    lines.append("")
    lines.append(
        f"GENERATED {date.today().isoformat()} at commit `{head}` by "
        "`pipelines/shell/failure_atlas.py`. Do not hand-edit; regenerate "
        "after refactor increments. Lists every raise site under "
        + " and ".join(f"`{r}/`" for r in SCAN_ROOTS)
        + " — the enforced contingencies an agent performing runs must "
        "know. Categories are heuristic starting points; the message at "
        "the cited line is authoritative."
    )
    lines.append("")
    lines.append("## Counts")
    lines.append("")
    lines.append("| Category | Raise sites |")
    lines.append("|---|---|")
    for cat, count in counts.most_common():
        lines.append(f"| {cat} | {count} |")
    lines.append(f"| **total** | **{len(rows)}** |")
    lines.append("")
    lines.append("Top files: " + ", ".join(
        f"`{f}` ({c})" for f, c in file_counts.most_common(5)
    ))
    lines.append("")
    order = [name for name, _ in CATEGORIES] + ["internal_consistency"]
    for cat in order:
        if cat not in by_cat:
            continue
        lines.append(f"## {cat} ({len(by_cat[cat])})")
        lines.append("")
        lines.append("| Location | Exception | Guarding message |")
        lines.append("|---|---|---|")
        for row in sorted(by_cat[cat], key=lambda r: (r["file"], r["line"])):
            msg = row["message"].replace("|", "\\|").replace("\n", " ")
            if len(msg) > 110:
                msg = msg[:107] + "..."
            lines.append(
                f"| `{row['file']}:{row['line']}` ({row['func']}) "
                f"| {row['exc']} | {msg} |"
            )
        lines.append("")

    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {OUT.relative_to(REPO)}: {len(rows)} raise sites")
    for cat, count in counts.most_common():
        print(f"  {cat}: {count}")


if __name__ == "__main__":
    main()
