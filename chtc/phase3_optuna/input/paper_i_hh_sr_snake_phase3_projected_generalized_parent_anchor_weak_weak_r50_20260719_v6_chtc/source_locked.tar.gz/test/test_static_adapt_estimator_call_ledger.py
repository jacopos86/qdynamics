from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import json

import numpy as np
import pytest

from pipelines.static_adapt.estimator_call_ledger import (
    EstimatorCallKey,
    EstimatorCallLedger,
    build_formal_manifold_query_closure_from_estimator_ledger,
    is_optimizer_or_guard_energy_scope,
    projective_state_fingerprint,
)


def _key(
    *,
    state: str = "projective-state-1",
    kind: str = "energy",
    formula: str = "hamiltonian_expectation",
    pair: tuple[str, str] | None = None,
) -> EstimatorCallKey:
    return EstimatorCallKey(
        projective_state_fingerprint=state,
        hamiltonian_fingerprint="hh-hamiltonian-1",
        backend_fingerprint="exact-statevector-backend-v1",
        precision_contract="float64-exact",
        primitive_kind=kind,
        observable_or_formula_identity=formula,
        symmetric_pair=pair,
    )


def test_projective_state_fingerprint_ignores_norm_and_global_phase():
    state = np.array([1.0 + 2.0j, -0.25 + 0.5j, 0.75 - 0.1j])
    globally_rephased = 3.7 * np.exp(0.37j) * state
    assert projective_state_fingerprint(state) == projective_state_fingerprint(
        globally_rephased
    )
    assert projective_state_fingerprint(state) != projective_state_fingerprint(
        state + np.array([0.0, 0.0, 0.01])
    )
    equal_magnitudes = np.array([1.0, 1.0j, -1.0, -1.0j])
    assert projective_state_fingerprint(
        equal_magnitudes
    ) == projective_state_fingerprint(np.exp(1.13j) * equal_magnitudes)
    with pytest.raises(ValueError, match="norm"):
        projective_state_fingerprint(np.zeros(2, dtype=complex))


def test_branch_and_scope_are_consumers_not_primitive_identity():
    identity = _key(kind="coordinate_gradient", formula="commutator:candidate-a")
    ledger = EstimatorCallLedger()
    first = ledger.record_call(
        identity,
        component="N_grad",
        consumer_scope="phase0",
        branch_id="branch-a",
    )
    reused = ledger.record_call(
        identity,
        component="N_grad",
        consumer_scope="phase1",
        branch_id="branch-b",
    )

    assert first.charged is True
    assert reused.charged is False
    summary = ledger.summary()
    assert summary["N_grad"] == summary["S_alg"] == 1
    assert summary["selected_call_occurrence_count"] == 2
    assert summary["deduplicated_reuse_occurrence_count"] == 1
    assert summary["unique_primitive_count_by_consumer_branch"] == {
        "branch-a": 1,
        "branch-b": 1,
    }
    assert summary["unique_primitive_count_by_consumer_scope"] == {
        "phase0": 1,
        "phase1": 1,
    }
    assert "branch" not in identity.as_dict()


@pytest.mark.parametrize(
    ("field", "replacement"),
    [
        ("projective_state_fingerprint", "projective-state-2"),
        ("hamiltonian_fingerprint", "hh-hamiltonian-2"),
        ("backend_fingerprint", "shot-backend-v1"),
        ("precision_contract", "shots-4096"),
        ("primitive_kind", "coordinate_gradient"),
        ("observable_or_formula_identity", "different-formula"),
    ],
)
def test_every_required_identity_field_changes_the_primitive_id(field, replacement):
    baseline = _key()
    assert replace(baseline, **{field: replacement}).primitive_id != baseline.primitive_id


def test_different_physical_state_charges_and_symmetric_pair_deduplicates():
    ledger = EstimatorCallLedger()
    forward = _key(
        kind="metric_element",
        formula="fubini_study_metric",
        pair=("coordinate-2", "coordinate-1"),
    )
    reversed_pair = _key(
        kind="metric_element",
        formula="fubini_study_metric",
        pair=("coordinate-1", "coordinate-2"),
    )
    different_state = _key(
        state="projective-state-2",
        kind="metric_element",
        formula="fubini_study_metric",
        pair=("coordinate-1", "coordinate-2"),
    )
    assert forward.symmetric_pair == ("coordinate-1", "coordinate-2")
    assert forward.primitive_id == reversed_pair.primitive_id

    ledger.record_call(
        forward,
        component="N_metric",
        consumer_scope="metric_build",
        branch_id="branch-a",
    )
    ledger.record_call(
        reversed_pair,
        component="N_metric",
        consumer_scope="metric_reuse",
        branch_id="branch-b",
    )
    ledger.record_call(
        different_state,
        component="N_metric",
        consumer_scope="metric_build",
        branch_id="branch-a",
    )
    assert ledger.summary()["N_metric"] == 2


def test_winner_lineage_summary_separates_discarded_branch_work():
    ledger = EstimatorCallLedger()
    outer = _key(state="state-initial", formula="initial-energy")
    gradient = _key(
        state="state-shared",
        kind="coordinate_gradient",
        formula="gradient:candidate-a",
    )
    loser_refit = _key(state="state-loser", formula="powell-objective")
    winner_metric = _key(
        state="state-winner",
        kind="metric_element",
        formula="metric",
        pair=("0", "1"),
    )

    ledger.record_call(
        outer, component="N_H_outer", consumer_scope="initial", branch_id=None
    )
    ledger.record_call(
        gradient,
        component="N_grad",
        consumer_scope="phase0",
        branch_id="discarded",
    )
    ledger.record_call(
        gradient,
        component="N_grad",
        consumer_scope="phase1",
        branch_id="winner",
    )
    ledger.record_call(
        loser_refit,
        component="N_H_refit",
        consumer_scope="boundary_refit",
        branch_id="discarded",
    )
    ledger.record_call(
        winner_metric,
        component="N_metric",
        consumer_scope="phase2",
        branch_id="winner",
    )

    all_branches = ledger.summary()
    assert all_branches["components"] == {
        "N_H_outer": 1,
        "N_H_refit": 1,
        "N_grad": 1,
        "N_metric": 1,
    }
    assert all_branches["S_alg"] == 4

    winner = ledger.summary(branch_ids=("winner",), include_unbranched=True)
    assert winner["components"] == {
        "N_H_outer": 1,
        "N_H_refit": 0,
        "N_grad": 1,
        "N_metric": 1,
    }
    assert winner["S_alg"] == 3
    assert ledger.summary(
        branch_ids=("winner",), include_unbranched=False
    )["S_alg"] == 2
    assert ledger.summary(include_unbranched=False)["S_alg"] == 3


def test_cross_component_reuse_is_charged_to_first_selected_consumer():
    ledger = EstimatorCallLedger()
    energy = _key(state="shared-energy-state", formula="energy")
    ledger.record_call(
        energy,
        component="N_H_outer",
        consumer_scope="outer_guard",
        branch_id=None,
    )
    ledger.record_call(
        energy,
        component="N_H_refit",
        consumer_scope="final_refit",
        branch_id="winner",
    )

    all_branches = ledger.summary()
    assert all_branches["N_H_outer"] == 1
    assert all_branches["N_H_refit"] == 0
    assert all_branches["S_alg"] == 1
    assert all_branches["cross_component_reuse_primitive_ids"] == [
        energy.primitive_id
    ]

    winner_only = ledger.summary(
        branch_ids=("winner",), include_unbranched=False
    )
    assert winner_only["N_H_outer"] == 0
    assert winner_only["N_H_refit"] == winner_only["S_alg"] == 1


def test_full_payload_roundtrip_is_json_serializable_and_validated():
    ledger = EstimatorCallLedger()
    identity = _key(kind="coordinate_gradient", formula="gradient:candidate-a")
    ledger.record_call(
        identity,
        component="N_grad",
        consumer_scope="phase0",
        branch_id="branch-a",
    )
    ledger.record_call(
        identity,
        component="N_grad",
        consumer_scope="phase1",
        branch_id="branch-a",
    )
    payload = json.loads(json.dumps(ledger.to_payload()))
    restored = EstimatorCallLedger.from_payload(payload)
    assert restored.to_payload() == payload

    payload["ledger_fingerprint"] = "tampered"
    with pytest.raises(ValueError, match="fingerprint mismatch"):
        EstimatorCallLedger.from_payload(payload)


def test_concurrent_duplicate_recording_charges_once_and_retains_consumers():
    ledger = EstimatorCallLedger()
    identity = _key(kind="coordinate_gradient", formula="gradient:candidate-a")

    def record_branch(branch_index: int) -> int:
        charged = 0
        for occurrence in range(25):
            receipt = ledger.record_call(
                identity,
                component="N_grad",
                consumer_scope=f"phase-{occurrence % 3}",
                branch_id=f"branch-{branch_index}",
            )
            charged += int(receipt.charged)
        return charged

    with ThreadPoolExecutor(max_workers=8) as executor:
        charged_counts = list(executor.map(record_branch, range(8)))

    assert sum(charged_counts) == 1
    summary = ledger.summary()
    assert summary["N_grad"] == summary["S_alg"] == 1
    assert summary["selected_call_occurrence_count"] == 200
    assert summary["deduplicated_reuse_occurrence_count"] == 199
    assert summary["unique_primitive_count_by_consumer_branch"] == {
        f"branch-{index}": 1 for index in range(8)
    }


@pytest.mark.parametrize(
    ("scope", "expected"),
    [
        ("energy:powell_objective", True),
        ("energy:terminal_prune_refit", True),
        ("finite_angle_objective_guard", True),
        ("outer_state_refresh", False),
        ("prune_surrogate_anchor", False),
        ("final_verification", False),
        ("finite_angle_objective_guard_extra", False),
    ],
)
def test_optimizer_or_guard_energy_scope_contract(scope, expected):
    assert is_optimizer_or_guard_energy_scope(scope) is expected


def test_formal_manifold_estimator_closure_partitions_unique_and_executed_work():
    ledger = EstimatorCallLedger()

    initial_energy = _key(
        state="state-initial",
        kind="hamiltonian_expectation",
        formula="initial-energy",
    )
    refresh_energy = _key(
        state="state-refresh",
        kind="hamiltonian_expectation",
        formula="outer-state-refresh",
    )
    winner_objective = _key(
        state="state-winner-objective",
        kind="hamiltonian_expectation",
        formula="powell-objective",
    )
    winner_guard = _key(
        state="state-winner-guard",
        kind="hamiltonian_expectation",
        formula="finite-angle-guard",
    )
    loser_objective = _key(
        state="state-loser-objective",
        kind="hamiltonian_expectation",
        formula="powell-objective",
    )
    loser_guard = _key(
        state="state-loser-guard",
        kind="hamiltonian_expectation",
        formula="finite-angle-guard",
    )
    shared_gradient = _key(
        state="state-shared-gradient",
        kind="coordinate_gradient",
        formula="gradient:candidate-a",
    )
    winner_metric = _key(
        state="state-winner-metric",
        kind="metric_element",
        formula="fubini-study-metric",
        pair=("0", "1"),
    )
    loser_hessian = _key(
        state="state-loser-hessian",
        kind="coordinate_second_derivative",
        formula="energy-hessian",
        pair=("0", "1"),
    )
    winner_hessian_vector = _key(
        state="state-winner-hessian-vector",
        kind="hessian_vector",
        formula="hessian-vector:0",
    )
    loser_cross_state = _key(
        state="state-loser-cross",
        kind="cross_state_tangent",
        formula="cross-state-tangent",
        pair=("old-0", "new-0"),
    )

    # Shared setup work is part of the winning lineage.  The repeated initial
    # objective is a real optimizer occurrence but only one unique oracle call.
    for _ in range(2):
        ledger.record_call(
            initial_energy,
            component="N_H_outer",
            consumer_scope="energy:initial",
            branch_id=None,
        )
    ledger.record_call(
        refresh_energy,
        component="N_H_outer",
        consumer_scope="outer_state_refresh",
        branch_id=None,
    )

    for _ in range(2):
        ledger.record_call(
            winner_objective,
            component="N_H_refit",
            consumer_scope="energy:powell_objective",
            branch_id="winner",
        )
    ledger.record_call(
        winner_guard,
        component="N_H_refit",
        consumer_scope="finite_angle_objective_guard",
        branch_id="winner",
    )
    ledger.record_call(
        loser_objective,
        component="N_H_refit",
        consumer_scope="energy:powell_objective",
        branch_id="discarded",
    )
    ledger.record_call(
        loser_guard,
        component="N_H_refit",
        consumer_scope="finite_angle_objective_guard",
        branch_id="discarded",
    )

    # The loser consumes this gradient first, but the winner consumes the same
    # physical primitive later.  It must be retained in winning/shared unique
    # work and excluded from discarded-only unique overhead.
    ledger.record_call(
        shared_gradient,
        component="N_grad",
        consumer_scope="phase1_gradient",
        branch_id="discarded",
    )
    ledger.record_call(
        shared_gradient,
        component="N_grad",
        consumer_scope="phase2_gradient",
        branch_id="winner",
    )
    for _ in range(2):
        ledger.record_call(
            winner_metric,
            component="N_metric",
            consumer_scope="metric_build",
            branch_id="winner",
        )
    ledger.record_call(
        loser_hessian,
        component="N_metric",
        consumer_scope="hessian_build",
        branch_id="discarded",
    )
    ledger.record_call(
        winner_hessian_vector,
        component="N_metric",
        consumer_scope="hessian_vector_probe",
        branch_id="winner",
    )
    ledger.record_call(
        loser_cross_state,
        component="N_metric",
        consumer_scope="cross_state_registration",
        branch_id="discarded",
    )

    closure = build_formal_manifold_query_closure_from_estimator_ledger(
        ledger,
        winning_branch_ids=("winner",),
        stored_nfev_total=6,
    )

    assert closure["schema"] == "formal_manifold_estimator_ledger_query_closure_v1"
    assert closure["primitive_kind_to_query_category"] == {
        "coordinate_gradient": "N_grad",
        "coordinate_second_derivative": "N_Q",
        "cross_state_tangent": "N_cross",
        "directional_metric_bilinear": "N_G",
        "energy": "N_E",
        "hamiltonian_expectation": "N_E",
        "hessian_element": "N_Q",
        "hessian_vector": "N_Hv",
        "metric_element": "N_G",
        "tangent_or_metric": "N_G",
    }

    winning = closure["winning_branch"]
    assert winning["counts"] == {
        "N_E": 4,
        "N_grad": 1,
        "N_G": 1,
        "N_Q": 0,
        "N_Hv": 1,
        "N_cross": 0,
    }
    assert winning["S_alg"] == winning["unique_primitive_count"] == 7
    assert shared_gradient.primitive_id in winning["primitive_ids"]

    discarded = closure["discarded_branch_operational_overhead"]
    assert discarded["counts"] == {
        "N_E": 2,
        "N_grad": 0,
        "N_G": 0,
        "N_Q": 1,
        "N_Hv": 0,
        "N_cross": 1,
    }
    assert discarded["S_alg"] == discarded["unique_primitive_count"] == 4
    assert shared_gradient.primitive_id not in discarded["primitive_ids"]

    all_executed = closure["all_executed"]
    assert all_executed["counts"] == {
        "N_E": 6,
        "N_grad": 1,
        "N_G": 1,
        "N_Q": 1,
        "N_Hv": 1,
        "N_cross": 1,
    }
    assert all_executed["S_alg"] == all_executed["unique_primitive_count"] == 11

    assert closure["primitive_set_reconciliation"] == {
        "winning_discarded_disjoint": True,
        "union_equals_all_executed": True,
        "winning_count": 7,
        "discarded_count": 4,
        "all_executed_count": 11,
    }

    occurrences = closure["executed_occurrence_accounting"]
    assert occurrences["all_execution"]["total_call_occurrences"] == 15
    assert occurrences["all_execution"]["same_identity_reuse_occurrence_count"] == 4
    assert occurrences["winning_plus_shared_execution"][
        "total_call_occurrences"
    ] == 10
    assert occurrences["winning_plus_shared_execution"][
        "same_identity_reuse_occurrence_count"
    ] == 3
    assert occurrences["discarded_branch_execution"][
        "total_call_occurrences"
    ] == 5

    # N_E includes non-optimizer refresh/verification measurements, whereas
    # nfev is exactly the occurrences whose scopes are optimizer objectives or
    # the finite-angle objective guard.
    assert closure["stored_nfev_total"] == 6
    assert closure["corrected_nfev_total"] == 7
    assert closure["nfev_correction"] == 1
    assert closure["nfev_winning_lineage"] == 5
    assert closure["nfev_discarded_operational_overhead"] == 2
    assert closure["nfev_reconciled"] is True


def test_formal_manifold_estimator_closure_fails_closed_on_unknown_primitive_kind():
    ledger = EstimatorCallLedger()
    ledger.record_call(
        _key(
            state="state-unknown",
            kind="unclassified_quantum_oracle",
            formula="mystery-probe",
        ),
        component="N_metric",
        consumer_scope="mystery_probe",
        branch_id="winner",
    )

    with pytest.raises(RuntimeError, match="primitive kind|primitive_kind|unsupported"):
        build_formal_manifold_query_closure_from_estimator_ledger(
            ledger,
            winning_branch_ids=("winner",),
        )


def test_formal_manifold_estimator_closure_rejects_kind_component_mismatch():
    ledger = EstimatorCallLedger()
    ledger.record_call(
        _key(
            state="state-gradient",
            kind="coordinate_gradient",
            formula="gradient:candidate-a",
        ),
        component="N_H_refit",
        consumer_scope="energy:misclassified-gradient",
        branch_id="winner",
    )

    with pytest.raises(
        RuntimeError,
        match="primitive-kind/legacy-component compatibility",
    ):
        build_formal_manifold_query_closure_from_estimator_ledger(
            ledger,
            winning_branch_ids=("winner",),
        )


def test_formal_manifold_nfev_filters_to_energy_primitive_occurrences():
    ledger = EstimatorCallLedger()
    ledger.record_call(
        _key(
            state="state-metric",
            kind="metric_element",
            formula="metric:0,0",
        ),
        component="N_metric",
        consumer_scope="energy:misleading-scope-name",
        branch_id="winner",
    )
    ledger.record_call(
        _key(
            state="state-energy",
            kind="hamiltonian_expectation",
            formula="optimizer-energy",
        ),
        component="N_H_refit",
        consumer_scope="energy:powell_objective",
        branch_id="winner",
    )

    closure = build_formal_manifold_query_closure_from_estimator_ledger(
        ledger,
        winning_branch_ids=("winner",),
        stored_nfev_total=1,
    )
    assert closure["all_executed"]["counts"] == {
        "N_E": 1,
        "N_grad": 0,
        "N_G": 1,
        "N_Q": 0,
        "N_Hv": 0,
        "N_cross": 0,
    }
    assert closure["corrected_nfev_total"] == 1
    assert closure["nfev_correction"] == 0
    assert closure["raw_energy_evaluation_occurrence_count"] == 1
