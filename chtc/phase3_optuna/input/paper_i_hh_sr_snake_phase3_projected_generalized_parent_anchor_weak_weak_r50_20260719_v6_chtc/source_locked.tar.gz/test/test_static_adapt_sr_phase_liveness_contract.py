from __future__ import annotations

from pathlib import Path
import sys

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from pipelines.static_adapt.cli_config import _build_adapt_arg_parser
from pipelines.static_adapt.sr_snake_route_profile import (
    SR_ROUTE_PROFILE_CONVENTIONAL_V3_1,
    PHASE3_RESPONSE_COORDINATE_SCOPE_FULL_ACTIVE_PLUS_SINGLETON_V1,
    SR_ROUTE_PROFILE_NO_PRUNE_SYMMETRIC_COST_V1,
    canonical_sr_snake_v3_contract_sha256,
    canonical_sr_snake_v3_1_contract,
    canonical_sr_snake_v3_1_contract_sha256,
    canonical_sr_snake_no_prune_symmetric_cost_v1_contract,
    canonical_sr_snake_no_prune_symmetric_cost_v1_contract_sha256,
    validate_sr_route_profile_runtime_settings,
)


def _parser():
    return _build_adapt_arg_parser(adapt_gradient_parity_rtol=1.0e-7)


@pytest.mark.parametrize(
    ("argv", "expected_hysteresis"),
    [
        (["--sr-route-profile", "sr_snake_v4"], False),
        (
            [
                "--sr-route-profile",
                "sr_snake_no_prune_symmetric_cost_v1",
                "--adapt-max-depth",
                "30",
            ],
            False,
        ),
        (
            [
                "--sr-route-profile",
                "sr_snake_symmetric_cost_fs_prune_nodamping_v1",
                "--adapt-max-depth",
                "30",
            ],
            False,
        ),
        (
            [
                "--sr-route-profile",
                "sr_snake_no_prune_symmetric_cost_beam_v1",
                "--adapt-max-depth",
                "30",
            ],
            False,
        ),
    ],
)
def test_full_response_profiles_preserve_their_source_locked_phase_liveness(
    argv: list[str],
    expected_hysteresis: bool,
) -> None:
    args = _parser().parse_args(argv)

    assert args.phase3_response_coordinate_scope == (
        PHASE3_RESPONSE_COORDINATE_SCOPE_FULL_ACTIVE_PLUS_SINGLETON_V1
    )
    assert args.phase_live_hysteresis_enabled is expected_hysteresis


def test_main_no_prune_profile_accepts_recorded_hysteresis_disable() -> None:
    args = _parser().parse_args(
        [
            "--sr-route-profile",
            "sr_snake_no_prune_symmetric_cost_v1",
            "--adapt-max-depth",
            "30",
            "--phase-live-hysteresis-disabled",
        ]
    )

    assert args.phase_live_hysteresis_enabled is False


def test_main_no_prune_profile_rejects_hysteresis_enable() -> None:
    with pytest.raises(SystemExit, match="2"):
        _parser().parse_args(
            [
                "--sr-route-profile",
                "sr_snake_no_prune_symmetric_cost_v1",
                "--adapt-max-depth",
                "30",
                "--phase-live-hysteresis-enabled",
            ]
        )


@pytest.mark.parametrize("profile", ["sr_snake", "sr_snake_v3_1"])
def test_current_conventional_alias_disables_hysteresis(profile: str) -> None:
    args = _parser().parse_args(["--sr-route-profile", profile])

    assert args.sr_route_profile_resolved == SR_ROUTE_PROFILE_CONVENTIONAL_V3_1
    assert args.phase_live_hysteresis_enabled is False
    assert args.sr_route_profile_contract == canonical_sr_snake_v3_1_contract()
    assert args.sr_route_profile_contract_sha256 == (
        canonical_sr_snake_v3_1_contract_sha256()
    )


def test_current_conventional_alias_rejects_explicit_hysteresis_enable() -> None:
    with pytest.raises(SystemExit, match="2"):
        _parser().parse_args(
            [
                "--sr-route-profile",
                "sr_snake",
                "--phase-live-hysteresis-enabled",
            ]
        )


@pytest.mark.parametrize("profile", ["sr_snake_v2", "sr_snake_v3"])
def test_frozen_historical_profiles_keep_their_recorded_default(
    profile: str,
) -> None:
    args = _parser().parse_args(["--sr-route-profile", profile])

    assert args.phase_live_hysteresis_enabled is True


def test_frozen_v3_contract_digest_remains_byte_stable() -> None:
    assert canonical_sr_snake_v3_contract_sha256() == (
        "435910592e88f0136a0d45f611f79fe96b21d75fd25bad58276c871f39dc080e"
    )
    assert canonical_sr_snake_v3_1_contract_sha256() != (
        canonical_sr_snake_v3_contract_sha256()
    )


def test_main_no_prune_contract_matches_valid_hysteresis_disabled_source_lock() -> None:
    contract = canonical_sr_snake_no_prune_symmetric_cost_v1_contract()
    assert canonical_sr_snake_no_prune_symmetric_cost_v1_contract_sha256() == (
        "023bc7ac535ee4d88d78dd5336a59dd2fb0543c133fa0a60b009efab75422c91"
    )
    assert contract["execution_settings"]["phase_live_hysteresis_enabled"] is False
    assert contract["semantic_invariants"]["phase_live_hysteresis_enabled"] is False
    assert contract["semantic_invariants"]["phase_retirement_policy"] == "disabled_v1"


def test_current_v3_1_runtime_validator_requires_disabled_hysteresis() -> None:
    contract = canonical_sr_snake_v3_1_contract()
    digest = canonical_sr_snake_v3_1_contract_sha256()

    assert validate_sr_route_profile_runtime_settings(
        profile_request=SR_ROUTE_PROFILE_CONVENTIONAL_V3_1,
        contract=contract,
        contract_sha256=digest,
        runtime_settings={"phase_live_hysteresis_enabled": False},
    ) == contract

    with pytest.raises(ValueError, match="effective runtime settings drifted"):
        validate_sr_route_profile_runtime_settings(
            profile_request=SR_ROUTE_PROFILE_CONVENTIONAL_V3_1,
            contract=contract,
            contract_sha256=digest,
            runtime_settings={"phase_live_hysteresis_enabled": True},
        )
