from __future__ import annotations

from pathlib import Path
import sys

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from pipelines.static_adapt.cli_config import _build_adapt_arg_parser
from pipelines.static_adapt.joint_linear_solve import (
    JOINT_LINEAR_SOLVE_SUPPORTED_METRIC_PROJECTED_GENERALIZED_TRUST_V1,
)
from pipelines.static_adapt.sr_snake_route_profile import (
    CANONICAL_SR_SNAKE_NO_PRUNE_SYMMETRIC_COST_PROJECTED_PHASE3_V1_EXECUTION_SETTINGS,
    SR_ROUTE_PROFILE_NO_PRUNE_SYMMETRIC_COST_PROJECTED_PHASE3_V1,
    canonical_sr_snake_no_prune_symmetric_cost_projected_phase3_v1_contract,
    canonical_sr_snake_no_prune_symmetric_cost_projected_phase3_v1_contract_sha256,
    canonical_sr_snake_no_prune_symmetric_cost_v1_contract,
    canonical_sr_snake_no_prune_symmetric_cost_v1_contract_sha256,
    validate_sr_route_profile_runtime_settings,
)


def _parser():
    return _build_adapt_arg_parser(adapt_gradient_parity_rtol=1.0e-7)


def test_projected_phase3_profile_is_one_setting_ablation_of_valid_main_sr() -> None:
    parent = canonical_sr_snake_no_prune_symmetric_cost_v1_contract()
    child = canonical_sr_snake_no_prune_symmetric_cost_projected_phase3_v1_contract()

    assert canonical_sr_snake_no_prune_symmetric_cost_v1_contract_sha256() == (
        "023bc7ac535ee4d88d78dd5336a59dd2fb0543c133fa0a60b009efab75422c91"
    )
    assert child["lineage_authority"]["parent_contract_sha256"] == (
        canonical_sr_snake_no_prune_symmetric_cost_v1_contract_sha256()
    )
    changed = {
        key: (parent["execution_settings"].get(key), value)
        for key, value in child["execution_settings"].items()
        if parent["execution_settings"].get(key) != value
    }
    assert changed == {
        "historical_singleton_coordinate_solve_policy": (
            "supported_metric_whitened_eigh_v1",
            JOINT_LINEAR_SOLVE_SUPPORTED_METRIC_PROJECTED_GENERALIZED_TRUST_V1,
        )
    }


def test_projected_phase3_profile_keeps_phase2_and_whitened_accepted_refit() -> None:
    contract = canonical_sr_snake_no_prune_symmetric_cost_projected_phase3_v1_contract()
    settings = contract["execution_settings"]
    invariants = contract["semantic_invariants"]

    assert settings["historical_singleton_coordinate_solve_scope"] == "phase3_only_v1"
    assert settings["phase_live_hysteresis_enabled"] is False
    assert settings["adapt_accepted_refit_scope"] == "full_ansatz_v1"
    assert settings["adapt_accepted_refit_coordinate_chart"] == (
        "supported_fs_whitened_fixed_v1"
    )
    assert invariants["phase2_supported_whitening_active"] is False
    assert invariants["phase3_support_projection_active"] is True
    assert invariants["phase3_supported_whitening_active"] is False
    assert invariants["phase3_supported_metric_inverse_sqrt_active"] is False
    assert invariants["phase3_metric_ridge_active"] is False
    assert invariants["accepted_refit_coordinate_chart"] == (
        "supported_fs_whitened_fixed_v1"
    )


def test_projected_phase3_alias_cli_and_contract_round_trip() -> None:
    args = _parser().parse_args(
        [
            "--sr-route-profile",
            "sr_snake_no_prune_symmetric_cost_projected_phase3_v1",
            "--adapt-max-depth",
            "50",
        ]
    )
    contract = canonical_sr_snake_no_prune_symmetric_cost_projected_phase3_v1_contract()
    digest = canonical_sr_snake_no_prune_symmetric_cost_projected_phase3_v1_contract_sha256()

    assert args.sr_route_profile_resolved == (
        SR_ROUTE_PROFILE_NO_PRUNE_SYMMETRIC_COST_PROJECTED_PHASE3_V1
    )
    assert args.historical_singleton_coordinate_solve_policy == (
        JOINT_LINEAR_SOLVE_SUPPORTED_METRIC_PROJECTED_GENERALIZED_TRUST_V1
    )
    assert args.sr_route_profile_contract == contract
    assert args.sr_route_profile_contract_sha256 == digest
    runtime = dict(
        CANONICAL_SR_SNAKE_NO_PRUNE_SYMMETRIC_COST_PROJECTED_PHASE3_V1_EXECUTION_SETTINGS
    )
    runtime["adapt_max_depth"] = 50
    assert validate_sr_route_profile_runtime_settings(
        profile_request=args.sr_route_profile_resolved,
        contract=contract,
        contract_sha256=digest,
        runtime_settings=runtime,
    ) == contract


def test_projected_phase3_profile_rejects_whitened_solver_override() -> None:
    with pytest.raises(SystemExit, match="2"):
        _parser().parse_args(
            [
                "--sr-route-profile",
                "sr_snake_no_prune_symmetric_cost_projected_phase3_v1",
                "--adapt-max-depth",
                "50",
                "--historical-singleton-coordinate-solve-policy",
                "supported_metric_whitened_eigh_v1",
            ]
        )
