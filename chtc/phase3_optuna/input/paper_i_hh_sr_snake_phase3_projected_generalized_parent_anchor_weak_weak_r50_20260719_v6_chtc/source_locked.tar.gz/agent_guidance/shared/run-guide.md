<!--
This guide is consumed by AI coding agents.

Editing contract:
- Keep machine-parseable: use tables, code blocks, explicit paths.
- Every artifact path must be relative to repo root.
- Artifact path examples are handles for specific files/directories, not permission for recursive artifact scans.
- Any command retained here must be copy-pasteable from repo root.
- Mark broken/historical items explicitly so agents skip them.
- Do not duplicate the full run skill or rebuild an old command catalog here.
- This file is a short run-routing reminder below root AGENTS, MATH AGENTS, and active run/table skills.
-->

# Shared Run Guide

Moved from root `run_guide.md` on 2026-05-31 so durable agent-facing run guidance lives under `agent_guidance/`. The root `run_guide.md` file is now only a compatibility pointer.

This guide is intentionally thin and subordinate to root `AGENTS.md`,
`MATH/AGENTS.md`, and the active run/table skills. It is not a standalone CLI
runbook or historical command catalog.

Mandatory paper-specific run sources of truth:

```text
agent_guidance/skills/paper-i-run/SKILL.md
agent_guidance/skills/paper-ii-run/SKILL.md
agent_guidance/skills/paper-iii-run/SKILL.md
```

Use the root router first, then `MATH/AGENTS.md`, then the relevant paper-specific run skill before
planning, launching, monitoring, repairing, aggregating, reporting, or promoting
any run that can affect Paper I, Paper II, Paper III, evidence PDFs,
Optuna/settings studies, CHTC jobs, table-support artifacts, or canonical
settings. Use the matching paper-specific results skill after the relevant paper-specific run skill when the
task is to update table cells, source maps, current-status tables, or table
provenance from completed evidence.

Visible manuscript/PDF tables, figures, and explicit reader-facing claims define
the paper-facing run queue. Hidden `.tex` comments, `.txt` notes, handoff notes,
and TODO blocks are provenance/context only; they do not by themselves authorize
a run. Use the visible table/figure first, then use source maps, manifests, and
nearby provenance comments only to verify how to fill that visible target.

## Best-visible-settings baseline gate

For any paper-facing rerun, repair, noise variant, comparator extension, or CHTC submission, start from the current best visible table/figure value for that method and regime. Do not invent new algorithmic settings from a generic CLI default.

Required sequence:

1. Identify the visible target: table label, row/regime/case, method cell, and displayed value/status.
2. Locate the source map or machine-readable support JSON for that visible target.
3. Resolve the method/regime entry to its source JSON or manifest.
4. Extract the algorithmic settings from that source: route/profile, pool, cutoff pair, optimizer/trial/policy fields, seed/scaffold pointers, and source hash when present.
5. Reuse those settings as the baseline. Change only the user-requested variable, such as noise model, shots, hardware backend, rerun depth cap, or diagnostic perturbation.
6. Record a baseline trace in the run note/manifest: `table_label`, `regime_or_case`, `method`, `visible_value`, `source_map`, `source_json`, `source_sha256`, `settings_reused`, and `settings_changed`.
7. Fail closed if the visible row's source JSON/settings cannot be found. Do not substitute arbitrary settings; repair provenance or ask the user.

Paper-I HH Qiskit-cost replay exception rule:

- For reruns that affect Hubbard--Holstein Qiskit cost tables, cost-vs-iteration
  plots, or Table-III resource provenance, the baseline is the existing Paper-I
  Qiskit cost-table provenance, not current code defaults, old CHTC submit
  files, or a freshly assembled command.
- Start from the linked source map/support artifacts, especially
  `MATH/paper_facing/paper_I_static_scaffold/hh_tableiii_convergence_sources.json`,
  `MATH/paper_facing/paper_I_static_scaffold/hh_exact_prefix_cost_iteration_preview_provenance_20260614.json`,
  and any adjacent replay/Qiskit sidecar named by those records.
- Reuse route/profile, pool and class-filter, cutoff/reference pair,
  optimizer/SPSA constants and engine, seeds, backend/cost settings,
  source-current/scaffold pointers, resume/segment settings, and replay/depth
  contract exactly as recorded.
- For the current Paper-I HH repair line, the only algorithmic settings agents
  may intentionally change are the newly implemented prune controls and
  batching controls explicitly requested by the user. Output paths, run labels,
  manifests, and audit filenames may change. Any additional settings difference
  blocks the run unless the user explicitly approves it as another variable.

Resolver command from repo root:

```bash
python3 agent_guidance/skills/shared/scripts/resolve_visible_settings.py \
  --source-map MATH/paper_facing/paper_I_static_scaffold/hh_tableiii_convergence_sources.json \
  --regime weak_weak \
  --method SNAKE
```

The resolver emits a baseline trace with the visible table/figure target, source JSON, source SHA-256 verification, reusable settings/contracts, and a `run_note_template`. Its default behavior is fail-closed: missing source JSON, SHA mismatch, or missing reusable settings exits nonzero. Use `--allow-missing-source-json`, `--allow-sha-mismatch`, or `--allow-empty-settings` only for audit/exploration, never to authorize a paper-facing run.

For example, Paper I Table III weak-weak SNAKE currently resolves through `tab:fixed_accuracy_hh_cartesian`, regime `weak_weak`, method `SNAKE`, and the source map `MATH/paper_facing/paper_I_static_scaffold/hh_tableiii_convergence_sources.json`. The resolver reports the visible value, source JSON, route contract, pool contract, cutoff pair, and source-current pointer. A weak-regime noise run should reuse that baseline and change only the noise-specific fields.

The old HH-only command catalog is deprecated. Do not treat historical `L=2`, `n_ph=1`, Marrakesh, fixed-manifold, robustness-matrix, or one-off artifact commands as defaults unless the user explicitly asks to reproduce that legacy route.

## 1. Authority order for runs

| Priority | Source | Use |
|---:|---|---|
| 1 | `AGENTS.md` | Global invariants, artifact hygiene, QPU-faithful data-flow rules. |
| 2 | `MATH/AGENTS.md` | Math/paper scope, paper program, manuscript/run gates. |
| 3 | Paper-specific run skill: `paper-i-run`, `paper-ii-run`, or `paper-iii-run` | Current paper run manager and canonical run policy. |
| 4 | Matching paper-specific results skill: `paper-i-results`, `paper-ii-results`, or `paper-iii-results` | Evidence-to-table updates, source-map/audit refreshes, PDF rebuild checks. |
| 5 | Visible manuscript/PDF tables, figures, and reader-facing claims | Defines the paper-facing run queue. |
| 6 | Source maps, manifests, nearby provenance comments, and support docs | Verifies how to fill visible targets; does not create standalone run targets. |
| 7 | Machine-readable configs/manifests | Executable defaults and artifact provenance. |
| 8 | This file | Short routing reminder only. |

If this file conflicts with root `AGENTS.md`, `MATH/AGENTS.md`, the relevant paper-specific run skill,
or the matching paper-specific results skill, follow the higher-priority source and update this
guide.

## 2. Required run-response frame

For routine run/status/progress replies, the run-skill frame is the whole response:

```text
Objective: ...
What I’m doing: ...
Next step: ...
Expected result: ...
```

After those four lines, stop. Do not append paragraphs, bullets, evidence dumps, or repeated explanation. Use extra text only when the user explicitly asks for commands/details, a safety blocker requires evidence, a tool failure must be explained, the run has reached a final handoff/report state, or the paper-specific run skill defines a current-status table exception. For Paper-I current-run status, follow `agent_guidance/skills/paper-i-run/SKILL.md`: report owned scope and method/regime rows in a readable table instead of cluster/proc shorthand.

## 3. Active paper targets

| Paper | Primary method | Manuscript | Main table labels | Support surface |
|---|---|---|---|---|
| Paper I | `SNAKE` | `MATH/paper_details/static_adapt_paper_I.tex` | `tab:fixed_accuracy_claims`, `tab:fixed_accuracy_spin_boson`, main HH `tab:hh_first_plateau_prefix_costs`; appendix HH `tab:fixed_accuracy_hh_cartesian` | `MATH/paper_facing/paper_I_static_scaffold/`; table-update ref `agent_guidance/skills/paper-i-results/references/paper_i_tables.md` |
| Paper II | `checkpoint McLachlan` | `MATH/paper_details/time_dynamics_paper_II.tex` | `tab:dyn_claims` | `MATH/paper_facing/paper_II_dynamics/` |
| Paper III | `geometry-selected QSE` | `MATH/paper_details/excited_spectra_dynamics_paper_III.tex` | `tab:qse_static_claims`, `tab:excited_dyn_claims` | `MATH/paper_facing/paper_III_spectra/`; production comments/support files only when required. |

For paper-facing work, follow the `MATH/AGENTS.md` paper-support load order
first. Inspect visible manuscript tables/figures before proposing commands.
Inspect manuscript comments, paper-specific support manifests, or target
manuscript blocks only to verify or fill the visible target, not to discover a
hidden run queue.

## 4. Run classes

Classify every run before launch.

| Class | Meaning | Promotion status |
|---|---|---|
| `smoke` | Tiny route check, actual runtime under 3 minutes excluding queue wait. | Never paper-facing. |
| `diagnostic` | Debugs failures, settings, compatibility, or behavior. | Not paper-facing unless rerun under production rules. |
| `candidate` | Complete enough to compare against current canonical/Pareto state. | Reviewable, not promoted. |
| `paper_facing` | Approved evidence run with full provenance, complete suite rules, and PDF report. | May be promoted only after user approval. |

Smoke tests must stay small. If a smoke expands into a substantial benchmark, stop or downgrade it.

## 5. Universal run gates

Before any candidate or paper-facing run, verify:

```text
run_class is declared
paper target is declared
method ordering is correct
suite membership is explicit
all wired Hamiltonian families are included or explicitly excluded by the user
working cutoff is explicit
reference/evaluation cutoff is explicit when relevant
seed/scaffold provenance is explicit
settings source is explicit
manifest output is enabled
report target is known
promotion is not automatic
```

For every candidate or paper-facing result update, also update or create the
machine-readable provenance/replay sidecar required by
`agent_guidance/skills/shared/run-results-common.md`: source paths and hashes,
rerun settings, replay status, trajectory/history source, Qiskit/resource
sidecars when relevant, generated plot/report paths, and future-agent rerun
guidance. A result update that changes table cells, plots, reports, or source
maps without refreshing this sidecar is incomplete.

Do not use broad repo scans to discover artifacts. Follow paper comments, support manifests, source maps, and targeted paths.

## 6. Paper I current contract

Use for SNAKE/static ADAPT fixed-accuracy and ablation evidence.

| Item | Current rule |
|---|---|
| Reporting policy | `paper_i_phys_v1` |
| Main target style | Physical fixed-accuracy target, not legacy same-cutoff `1e-6`/`1e-8`. |
| Lattice/control/mixed target | `tau_phys = 1e-4 * N_phys * E0`. For current clean `L=2`, `E0=1` rows, `tau_phys = 2e-4`. |
| Phonon-bearing primary error | External/higher-cutoff physical error, e.g. `abs(E_ADAPT(N_ph_work) - E_exact(N_ph_eval))`. |
| Paper I Tables 1-3 main | Visible manuscript tables for Hubbard, spin-boson/Rabi, and Hubbard-Holstein. Use `agent_guidance/skills/paper-i-results/references/paper_i_tables.md`; do not apply the broader full clean/current-status Table-I cutoff list to these cells. |
| Full clean/current-status Table-I cutoffs | Use the locked known working/reference cutoff pair for the row. Do not run lower-cutoff probes as part of report generation. The approved table row overrides generic placeholders: Bose-Hubbard `(1,4)` weak/strong; harmonic/Kerr `(4,7)` weak/strong; spin-boson `(2,5)` weak and `(6,9)` strong; Hubbard-Holstein `(1,4)` weak and `(2,5)` strong; molecular-vibronic H2 `(1,4)` weak and `(3,6)` strong. |
| Same-cutoff error | Diagnostic only. |
| First-crossing resources | Report resources at the first accepted ADAPT iteration crossing `tau_phys`. |
| SNAKE table costs | Prefer the historical Route-A/SPSA Pareto display representative from `pipelines/exact_bench/table_i_routea_spsa_historical_pareto.py`; resources must come from hash-verified Qiskit first-hit sidecars, not terminal/current-run overwrites. |
| HH Qiskit-cost replay baseline | For HH Table-III replay/rerun work tied to Qiskit costs or cost-vs-iteration provenance, reuse the existing Paper-I replay settings from the Qiskit cost-table provenance and linked source maps. Change only the user-named new prune and batching controls plus output paths/run labels; fail closed on route, pool, optimizer/SPSA, seed, backend/cost, cutoff, source-pointer, resume/segment, or depth-contract drift. |
| Legacy thresholds | Support-ledger or idealized convergence stress tests only. |
| Main method | SNAKE first. |
| Route | Route A / algebraic shortlisting unless the user asks for an ablation. |
| SNAKE preferred profile | Route A with full-meta pool, Pauli-child/child-set exploration, beam enabled, novelty exponent preserved at `1` when present, prune amplitude shortlist/witness not required, and batch commutation not required. |
| HH display regime labels | Current HH rows use the six-regime grid crossing Hubbard sector `U/t in {0.25, 1.25, 8}` with Holstein sector `lambda in {0.25, 1.25}`: `weak-weak`, `intermediate-weak`, `strong-weak`, `weak-strong`, `intermediate-strong`, and `strong-strong`. Legacy artifact keys `strong_weak`/`strong-weak` and `strong_strong`/`strong-strong` may still mean the `U/t=1.25` intermediate rows; resolve current `U/t=8` rows explicitly from source-map/overlay labels such as `strong-weak-u8` and `strong-strong-u8`. |
| HH active method matrix | Current HH Table III run/status/repair scope is `3 x 6`: SNAKE, Geo-ADAPT (`static_geo_adapt_vqe`), and append-only ADAPT (`static_full_meta_append_adapt_vqe`) across all six display regimes. TETRIS, QEB, HEA, family-informed VQE, and PosGeo are legacy/diagnostic unless explicitly requested. |
| HH speed path | Prefer `python3 pipelines/exact_bench/paper_i_hh_speed_optuna.py --regime <regime>` over hand-assembled Optuna commands; it delegates through `hh_cost_energy_optuna.py` with `--force-route-a-paper-i-production` and auto worker defaults (`--gradient-workers 0 --beam-parent-workers 0`). Before HH SNAKE/Optuna timing or submission, use persistent disk HH pool cache, `STATIC_ADAPT_HH_POOL_CACHE_SCOPE=paper_i_holstein_sector`, persistent ADAPT-layer candidate-record cache (`STATIC_ADAPT_CANDIDATE_RECORD_CACHE=disk`, optional `STATIC_ADAPT_CANDIDATE_RECORD_CACHE_DIR`), and the exact-energy manifest. Prewarm through the wrapper itself using `--max-depth 0 --maxiter 1` for one weak-Holstein regime and one strong-Holstein regime; do not hand-reconstruct builder parameters because delegated CLI float formatting such as `.12g` `g_ep` is part of the key. That cache scope builds one structural `full_meta_minus_hva` pool per Paper-I Holstein sector (`lambda=0.25,n_ph_work=2` and `lambda=1.25,n_ph_work=4`) and reuses it across `U/t in {0.25,1.25,8}` while refreshing cached `ham_block::*` polynomials for the current `U`. Candidate-record cache reuse is direct-ADAPT/state/candidate/scoring-keyed, not Optuna-only; exact direct replays should show disk hits in the phase2 full-feature `candidate_record_cache` counters. The same cache directory also stores phase-0 pilot-screen results keyed by state/settings; warm replays should log `hardcoded_adapt_phase0_screen_cache` with `status="hit"`. Runtime split should log child-set parallel scoring counters in `hardcoded_adapt_beam_phase2_full_feature_parallel`, especially `runtime_split_child_set_parallel_scoring_count` and `runtime_split_child_set_parallel_worker_max`. Require warm-trial logs to show `hardcoded_adapt_pool_cache_hit`, `hardcoded_adapt_generator_registry_cache_hit`, `hardcoded_adapt_candidate_record_cache_config`, phase-0 cache hits when replaying the same state, and `ground_state.exact_energy_source="adapt_exact_gs_reference_json"`. Use `phase3_symmetry_mitigation_mode=off` unless explicitly testing symmetry mitigation. |
| SNAKE cost mode | Cost/resource scoring is on by default; the user may request no-cost/no-resource mode, especially for HH. Optuna must keep the chosen cost mode fixed. |
| Obsolete route trap | Do not use `target_energy_accuracy` or older fixed-threshold route names as the run profile. Use visible table/source-map settings and `tau_phys` only as the reporting/first-crossing threshold when applicable. |
| HH adaptive production pool | `full_meta_minus_hva`: `adapt_pool=full_meta` with `agent_guidance/static-adapt/hh_full_meta_minus_hva_class_filter.json`; applies to active HH SNAKE, Geo-ADAPT, and append-only ADAPT rows. Do not reduce current HH production rows to old winning pools. `full_meta` itself still includes HVA, and HVA VQE remains a separate conventional VQE ansatz/comparator. |
| HH Pauli-child policy | Pauli-child / child-set candidate exploration enabled by default; report observed child/batch/runtime-split fields literally. |
| SNAKE Optuna progress | Live jobs must expose and status-report current-best `DeltaE` per trial and per ADAPT iteration/prefix. Missing either view is a monitoring schema defect to repair before accepting candidate/paper-facing reruns. |
| HH CHTC Optuna status format | For current Paper-I HH CHTC Optuna status, use the four-line frame plus exactly one method-by-regime table with rows `SNAKE`, `Geo-ADAPT`, and `append-only ADAPT`, and columns `weak-weak`, `intermediate-weak`, `strong-weak`, `weak-strong`, `intermediate-strong`, and `strong-strong`; map legacy keys `strong_weak`/`strong-weak` and `strong_strong`/`strong-strong` into the intermediate columns only when source-map/overlay labels show those keys refer to `U/t=1.25`. Each cell should include state, best `DeltaE`, iter/prefix, trial, plateau value/prefix, and reported value, or `missing:<field>`. No prose after the table. |
| Exit/retrieve current best | If the user says the current job is good enough, asks to exit, or asks to retrieve the current best, fetch/copy the full JSON evidence bundle before closing the loop; do not stop the job unless explicitly asked. |
| HH cutoff chat rule | Always report both `n_ph_work` and `n_ph_ref`/`n_ph_eval`. Default unspecified HH working cutoff is `2`, generally compared to `work+3`; escalate when Paper-I/Table-III locks or exact-floor checks require it. |
| Optimizer fairness | Active HH comparisons use the shared SPSA optimizer contract for SNAKE, Geo-ADAPT, and append-only ADAPT. Mixed SPSA/COBYLA/L-BFGS-B/Nelder-Mead/exact-search rows, unequal budgets, or legacy methods mixed into the active HH matrix are diagnostic or optimizer/legacy ablation evidence unless explicitly approved as a study. |
| Ablations | Disabled-minus-full with matched Hamiltonian, seed, cutoff, encoding, backend, optimizer, and resource settings. |

Do not silently use older `5e-3 * N_phys * E0`, `1e-3 * N_phys * E0`, lower-cutoff probes, reduced/winning-pool HH defaults, or the old universal `1e-6`/`1e-8` table policy.

## 7. Paper II current contract

Use for checkpoint-adaptive McLachlan dynamics.

| Item | Current rule |
|---|---|
| Primary method | `checkpoint McLachlan` first. |
| Calibration gate | Use `$time-dynamics-benchmark-calibration` when available before CHTC submission, aggregation, evidence-PDF generation, or table updates; fail closed on calibration `ERROR`s. |
| Settings policy | Class-level controller settings, not per-Hamiltonian tuning for table claims. |
| Same-seed rule | Every method at one benchmark point shares the same static seed hash. |
| Exact data | Diagnostics/reporting only; never controller decisions. |
| QPU-faithful strict route | Must satisfy the exact-input/data-flow contract in `AGENTS.md` and the relevant paper-specific run skill. |
| Invalid paper row | Trajectory freezes while exact diagnostic trajectory moves, e.g. `theta_dot_l2=0`, `rho_num=0`, `rho_miss≈1`. |
| Current lock path | `chtc/generic_time_dynamics_table/input/class_settings/paper_ii_class_settings_lock_v1.json` |

Do not use staged, fallback, pending, or recovery seed artifacts in paper-facing aggregates.

## 8. Paper III current contract

Use for geometry-selected QSE spectra and excited-state dynamics.

| Item | Current rule |
|---|---|
| Primary method | `geometry-selected QSE` first. |
| Suite coverage | Include all Hamiltonian families wired through the generic benchmark/static-ADAPT/SNAKE program unless narrowed by user. |
| Excited states | Six excited states per benchmark point for production unless explicitly narrowed. |
| Cutoffs | Run `n_ph=1` compatibility first, then require `n_ph=2` compatibility before production claims. |
| Exact spectra/trajectories | Diagnostic/reporting only; not QPU-faithful controller inputs. |
| Missing comparators | Blocker, not a reason to silently downgrade the comparator set. |

## 9. Settings priority

Resolve algorithm-under-test settings in this order:

| Priority | Settings source |
|---:|---|
| 1 | Approved table-facing class-canonical settings. |
| 2 | Approved Hamiltonian-class canonical settings. |
| 3 | Approved Hamiltonian-specific settings, only when allowed by the table/report claim. |
| 4 | Reviewed Optuna/settings candidate with explicit payload and source artifact. |
| 5 | If none exists, ask whether to run a settings-search/Optuna pass. |

Do not silently fall back to stale defaults when a better approved settings record exists.

## 10. Lifecycle

Use this lifecycle for candidate and paper-facing work:

```text
1. Frame objective with the required run-skill response block.
2. Read target paper comments and support pointers.
3. Classify the run.
4. Verify settings, seed/scaffold, cutoff/reference policy, suite membership, and method ordering.
5. Check whether an existing artifact already satisfies or dominates the request.
6. Launch only if execution is still appropriate.
7. Monitor until terminal success/failure.
8. If a run fails, classify it before reporting it final. Treat implementation
   plumbing failures as repair triggers: fix, run a narrow proof test, and
   resume/rerun the same scientific command.
9. Ask before any repair that changes mathematical/scientific semantics,
   evidence semantics, route identity, settings, cutoffs, seeds, or scope.
10. Validate manifest/report inputs.
11. Generate a PDF run report for candidate/paper-facing review.
12. If completed evidence should update table cells/source maps/current-status artifacts, switch to the matching paper-specific results skill and consume the run artifacts.
13. Open requested PDFs in VS Code on macOS: prefer `code -r <report.pdf>` when available, otherwise `open -a "Visual Studio Code" <report.pdf>`. Use Finder for PNG/image artifacts, not PDFs.
14. Ask the user before promotion.
```

## 11. Report contract

Candidate and paper-facing runs should produce a PDF report before promotion discussion.

PDF build rule: when the user asks for a results, evidence, current-status, audit, or table PDF, build it through LaTeX from a `.tex` source and render tables as LaTeX tables. Do not use ReportLab tables, ad hoc quick-report PDFs, notebook-export PDFs, dataframe screenshots, bitmap table images, or screenshot-to-PDF output unless the user explicitly asks for a disposable diagnostic mockup in the current request.

Required report contents:

| Section | Requirement |
|---|---|
| Manifest page | Render parameters from the machine-readable run manifest. |
| Objective | State paper target, method, suite, and run class. |
| Provenance | Include exact paper file/table target, seed/scaffold hashes, settings source, and artifact paths. |
| Tables | Paper-style aggregate table and per-Hamiltonian tables. |
| Method order | SNAKE first for Paper I, checkpoint McLachlan first for Paper II, geometry-selected QSE first for Paper III. |
| Gates | Pass/fail for same-suite, same-seed, cutoff/reference, QPU-faithful/exact-data rules when relevant. |
| Appendix | JSON paths, manifests, logs, hashes, and commands. |

Do not promote from terminal JSON alone when a paper-style PDF report is expected.


When in doubt, return to `AGENTS.md` -> `MATH/AGENTS.md` -> the relevant paper-specific run skill; inspect paper-support docs, target paper comments, and machine-readable manifests only as required by the task. You are encouraged to ask the user many questions so that you can be confident in executing the correctly scoped run.
