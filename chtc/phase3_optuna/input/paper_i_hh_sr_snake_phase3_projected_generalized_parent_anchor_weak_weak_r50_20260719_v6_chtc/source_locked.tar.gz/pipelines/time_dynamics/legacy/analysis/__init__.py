"""Legacy analysis command shims."""
