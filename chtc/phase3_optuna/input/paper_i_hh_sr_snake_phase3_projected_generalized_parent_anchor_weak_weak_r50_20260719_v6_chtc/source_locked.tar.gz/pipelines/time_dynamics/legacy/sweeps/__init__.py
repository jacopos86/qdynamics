"""Legacy sweep command shims."""
