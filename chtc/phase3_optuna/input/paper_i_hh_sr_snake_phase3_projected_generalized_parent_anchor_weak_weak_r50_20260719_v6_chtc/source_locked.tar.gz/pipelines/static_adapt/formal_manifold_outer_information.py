"""Outer-ADAPT geometric information reuse for Formal-Manifold SNAKE.

This module is deliberately independent of the SR selector and its Powell
refit.  It implements the typed numerical recursion derived in the Paper-I
Formal-Manifold Volume V note:

* zero-amplitude admission is an exact same-ray Gram--Schur extension;
* nonlinear refit motion is a prediction, split into positive metric strain
  and a skew orientation connection;
* endpoint probes close, minimally correct, or reject that prediction;
* Procrustes registration is available only to an authoritative measured
  reanchor; and
* vectors, covectors, direct curvature, and inverse curvature use distinct
  transport laws in one supported raw-Fubini--Study orthonormal frame.

The routines perform classical matrix algebra only.  They neither execute nor
invent estimator primitives.  Callers must supply acquired blocks together
with their immutable primitive identities and remain responsible for charging
those identities in the route query ledger.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
import hashlib
import json
import math
from types import MappingProxyType
from typing import Any, Mapping, Sequence

import numpy as np
from scipy.linalg import expm

from pipelines.static_adapt.joint_linear_solve import factor_supported_metric


OUTER_INFORMATION_SCHEMA = "formal_manifold_outer_information_state_v1"
OUTER_INFORMATION_CHECKPOINT_SCHEMA = (
    "formal_manifold_outer_information_checkpoint_v2"
)
OUTER_SUPPORTED_FRAME_SCHEMA = "formal_manifold_outer_supported_frame_v1"
OUTER_SAME_RAY_EXTENSION_SCHEMA = (
    "formal_manifold_same_ray_gram_schur_extension_v1"
)
OUTER_METRIC_PREDICTION_SCHEMA = (
    "formal_manifold_affine_invariant_metric_prediction_v1"
)
OUTER_CLOSURE_SCHEMA = "formal_manifold_transport_closure_v1"
OUTER_TRANSPORT_SCHEMA = "formal_manifold_split_connection_transport_v1"
ACTIVE_OUTER_GEOMETRY_PRIOR_SCHEMA = (
    "formal_manifold_active_outer_geometry_prior_v1"
)

STATUS_ACQUIRED = "acquired"
STATUS_INHERITED = "inherited"
STATUS_DERIVED = "derived"
STATUS_PREDICTED = "predicted"
STATUS_CORRECTED = "corrected"
STATUS_INVALIDATED = "invalidated"
PROVENANCE_STATUSES = frozenset(
    {
        STATUS_ACQUIRED,
        STATUS_INHERITED,
        STATUS_DERIVED,
        STATUS_PREDICTED,
        STATUS_CORRECTED,
        STATUS_INVALIDATED,
    }
)

CLOSURE_CONTINUE = "continue"
CLOSURE_CORRECT = "correct"
CLOSURE_ANCHOR = "anchor"
CLOSURE_INVALIDATE = "invalidate"
CLOSURE_OUTCOMES = frozenset(
    {
        CLOSURE_CONTINUE,
        CLOSURE_CORRECT,
        CLOSURE_ANCHOR,
        CLOSURE_INVALIDATE,
    }
)

CURVATURE_NONE = "none"
CURVATURE_DIRECT = "direct_hessian"
CURVATURE_INVERSE = "inverse_hessian"
CURVATURE_KINDS = frozenset(
    {CURVATURE_NONE, CURVATURE_DIRECT, CURVATURE_INVERSE}
)

NULL_GRADIENT_REJECT = "reject_raw_null_action_v1"
NULL_GRADIENT_PROJECT = "project_to_supported_quotient_v1"
NULL_GRADIENT_POLICIES = frozenset(
    {NULL_GRADIENT_REJECT, NULL_GRADIENT_PROJECT}
)

TRANSACTION_IDLE = "idle"
TRANSACTION_GROWTH = "same_ray_growth"
TRANSACTION_PREDICTION = "refit_prediction"
TRANSACTION_REANCHOR_REQUIRED = "reanchor_required"
TRANSACTION_CLOSED = "closure_passed"

PROVENANCE_ROLE_METRIC = "metric"
PROVENANCE_ROLE_CURVATURE = "curvature"
PROVENANCE_ROLE_REGISTRATION = "frame_registration"


class OuterInformationReanchorRequired(RuntimeError):
    """Signal a modeled support transition that requires an exact reanchor.

    This is not an implementation failure and it does not authorize changing
    the accepted SR ansatz.  The caller must discard only the incompatible
    predictive geometry hypothesis and let the next acquired endpoint geometry
    establish a new outer-information anchor.
    """

    def __init__(self, reason: str, *, telemetry: Mapping[str, Any]) -> None:
        reason_value = str(reason).strip()
        if not reason_value:
            raise ValueError("outer reanchor reason must be nonempty.")
        super().__init__(reason_value)
        self.reason = reason_value
        self.telemetry = _immutable_payload(dict(telemetry))

EXACT_OUTER_CONTROL_OFF = "off"
EXACT_OUTER_CONTROL_SHADOW_EACH_OUTER_V1 = "shadow_each_outer_v1"
EXACT_OUTER_CONTROL_AUTHORITY_EACH_OUTER_V1 = "authority_each_outer_v1"
EXACT_OUTER_CONTROL_MODEL_GUARD_EACH_OUTER_V2 = (
    "model_guard_each_outer_v2"
)
EXACT_OUTER_CONTROL_CHOICES = (
    EXACT_OUTER_CONTROL_OFF,
    EXACT_OUTER_CONTROL_SHADOW_EACH_OUTER_V1,
    EXACT_OUTER_CONTROL_AUTHORITY_EACH_OUTER_V1,
    EXACT_OUTER_CONTROL_MODEL_GUARD_EACH_OUTER_V2,
)


def normalize_exact_outer_control_mode(value: Any) -> str:
    """Normalize the explicit exact-vs-predicted outer diagnostic control."""

    mode = str(value or EXACT_OUTER_CONTROL_OFF).strip().lower()
    aliases = {
        "none": EXACT_OUTER_CONTROL_OFF,
        "false": EXACT_OUTER_CONTROL_OFF,
        "0": EXACT_OUTER_CONTROL_OFF,
        "shadow": EXACT_OUTER_CONTROL_SHADOW_EACH_OUTER_V1,
        "exact_shadow": EXACT_OUTER_CONTROL_SHADOW_EACH_OUTER_V1,
        "authority": EXACT_OUTER_CONTROL_AUTHORITY_EACH_OUTER_V1,
        "exact_authority": EXACT_OUTER_CONTROL_AUTHORITY_EACH_OUTER_V1,
        "model_guard": EXACT_OUTER_CONTROL_MODEL_GUARD_EACH_OUTER_V2,
        "exact_model_guard": EXACT_OUTER_CONTROL_MODEL_GUARD_EACH_OUTER_V2,
    }
    mode = aliases.get(mode, mode)
    if mode not in EXACT_OUTER_CONTROL_CHOICES:
        raise ValueError(
            "exact outer control mode must be one of "
            f"{list(EXACT_OUTER_CONTROL_CHOICES)}, got {value!r}."
        )
    return mode


def _sym(value: Any) -> np.ndarray:
    array = np.asarray(value, dtype=float)
    return np.asarray(0.5 * (array + array.T), dtype=float)


def _finite_vector(value: Any, *, name: str) -> np.ndarray:
    result = np.asarray(value, dtype=float).reshape(-1).copy()
    if not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must be finite.")
    return result


def _finite_square(value: Any, *, name: str) -> np.ndarray:
    result = np.asarray(value, dtype=float)
    if result.ndim != 2 or result.shape[0] != result.shape[1]:
        raise ValueError(f"{name} must be square.")
    if not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must be finite.")
    return _sym(result)


def _readonly(value: Any, *, dtype: Any = float) -> np.ndarray:
    result = np.asarray(value, dtype=dtype).copy()
    result.setflags(write=False)
    return result


def _matrix_function_spd(value: np.ndarray, function: Any) -> np.ndarray:
    matrix = _finite_square(value, name="positive matrix")
    eigenvalues, eigenvectors = np.linalg.eigh(matrix)
    if eigenvalues.size and float(np.min(eigenvalues)) <= 0.0:
        raise ValueError("matrix function requires a positive-definite matrix.")
    return _sym(
        eigenvectors
        @ np.diag(function(np.asarray(eigenvalues, dtype=float)))
        @ eigenvectors.T
    )


def _matrix_exp_symmetric(value: np.ndarray) -> np.ndarray:
    matrix = _finite_square(value, name="symmetric generator")
    eigenvalues, eigenvectors = np.linalg.eigh(matrix)
    return _sym(eigenvectors @ np.diag(np.exp(eigenvalues)) @ eigenvectors.T)


def _matrix_invsqrt_spd(value: np.ndarray) -> np.ndarray:
    return _matrix_function_spd(value, lambda x: x ** -0.5)


def _matrix_sqrt_spd(value: np.ndarray) -> np.ndarray:
    return _matrix_function_spd(value, np.sqrt)


def _matrix_log_spd(value: np.ndarray) -> np.ndarray:
    return _matrix_function_spd(value, np.log)


def _json_hash(payload: Any) -> str:
    encoded = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _array_hash(value: np.ndarray) -> str:
    array = np.ascontiguousarray(np.asarray(value, dtype="<f8"))
    digest = hashlib.sha256()
    digest.update(str(array.shape).encode("ascii"))
    digest.update(b"\0")
    digest.update(array.tobytes())
    return digest.hexdigest()


def _portable_payload(value: Any) -> Any:
    """Return a detached JSON-style representation of nested telemetry."""

    if isinstance(value, Mapping):
        return {
            str(key): _portable_payload(item)
            for key, item in value.items()
        }
    if isinstance(value, (tuple, list)):
        return [_portable_payload(item) for item in value]
    if isinstance(value, np.ndarray):
        return np.asarray(value).tolist()
    if isinstance(value, np.generic):
        return value.item()
    return deepcopy(value)


def _immutable_payload(value: Any) -> Any:
    """Freeze nested provenance so a committed record cannot drift in memory."""

    portable = _portable_payload(value)
    if isinstance(portable, dict):
        return MappingProxyType(
            {key: _immutable_payload(item) for key, item in portable.items()}
        )
    if isinstance(portable, list):
        return tuple(_immutable_payload(item) for item in portable)
    return portable


def _latest_provenance_id(
    provenance: Sequence["ProvenanceRecord"],
    *,
    role: str,
) -> str | None:
    """Return the newest record in one typed provenance lane."""

    for record in reversed(tuple(provenance)):
        if str(record.certificate.get("provenance_role", "")) == str(role):
            return str(record.record_id)
    return None


def _latest_provenance_status(
    provenance: Sequence["ProvenanceRecord"],
    *,
    role: str,
) -> str | None:
    """Return the status of the newest record in one typed provenance lane."""

    for record in reversed(tuple(provenance)):
        if str(record.certificate.get("provenance_role", "")) == str(role):
            return str(record.status)
    return None


def _parent_tuple(value: str | None) -> tuple[str, ...]:
    return () if value is None else (str(value),)


@dataclass(frozen=True)
class OuterInformationConfig:
    """Numerical and epistemic gates for one outer-information recursion."""

    rank_relative_tolerance: float = 1.0e-6
    metric_regularization: float = 1.0e-9
    closure_pass_tolerance: float = 1.0e-3
    closure_correction_tolerance: float = 5.0e-2
    correction_min_eigenvalue: float = 1.0e-8
    support_span_tolerance: float = 5.0e-8
    transport_orthogonality_tolerance: float = 5.0e-8
    orientation_alignment_floor: float = 1.0e-7
    energy_model_null_tolerance: float = 1.0e-8
    null_curvature_policy: str = "reject_raw_null_action_v1"
    secant_min_norm: float = 1.0e-10
    secant_denominator_tolerance: float = 1.0e-8
    max_prediction_age: int = 8
    endpoint_gradient_prediction_policy: str = "transported_source_only_v1"

    def __post_init__(self) -> None:
        for name in (
            "rank_relative_tolerance",
            "metric_regularization",
            "closure_pass_tolerance",
            "closure_correction_tolerance",
            "correction_min_eigenvalue",
            "support_span_tolerance",
            "transport_orthogonality_tolerance",
            "orientation_alignment_floor",
            "energy_model_null_tolerance",
            "secant_min_norm",
            "secant_denominator_tolerance",
        ):
            value = float(getattr(self, name))
            if not math.isfinite(value) or value < 0.0:
                raise ValueError(f"{name} must be finite and nonnegative.")
        if float(self.closure_pass_tolerance) > float(
            self.closure_correction_tolerance
        ):
            raise ValueError(
                "closure_pass_tolerance must not exceed the correction tolerance."
            )
        if int(self.max_prediction_age) < 1:
            raise ValueError("max_prediction_age must be positive.")
        if str(self.null_curvature_policy) not in {
            "reject_raw_null_action_v1",
            "project_to_supported_quotient_v1",
        }:
            raise ValueError("unknown null_curvature_policy.")
        if str(self.endpoint_gradient_prediction_policy) not in {
            "transported_source_only_v1",
            "transported_source_plus_curvature_displacement_v2",
        }:
            raise ValueError("unknown endpoint_gradient_prediction_policy.")

    def as_dict(self) -> dict[str, Any]:
        return {
            name: getattr(self, name)
            for name in self.__dataclass_fields__
        }


@dataclass(frozen=True)
class ProvenanceRecord:
    """One typed node in the outer-information dependency graph."""

    quantity: str
    status: str
    base_state_id: str
    chart_id: str
    support_id: str
    parent_ids: tuple[str, ...] = ()
    primitive_ids: tuple[str, ...] = ()
    observation_ids: tuple[str, ...] = ()
    certificate: Mapping[str, Any] = field(default_factory=dict)
    record_id: str = ""

    def __post_init__(self) -> None:
        for name in ("quantity", "base_state_id", "chart_id", "support_id"):
            if not str(getattr(self, name)):
                raise ValueError(f"{name} must be nonempty.")
        if str(self.status) not in PROVENANCE_STATUSES:
            raise ValueError("unknown provenance status.")
        parents = tuple(sorted({str(value) for value in self.parent_ids}))
        primitives = tuple(sorted({str(value) for value in self.primitive_ids}))
        observations = tuple(
            sorted({str(value) for value in self.observation_ids})
        )
        if any(not value for value in (*parents, *primitives, *observations)):
            raise ValueError("provenance identifiers must be nonempty.")
        certificate = _portable_payload(self.certificate)
        payload = {
            "quantity": str(self.quantity),
            "status": str(self.status),
            "base_state_id": str(self.base_state_id),
            "chart_id": str(self.chart_id),
            "support_id": str(self.support_id),
            "parent_ids": list(parents),
            "primitive_ids": list(primitives),
            "observation_ids": list(observations),
            "certificate": certificate,
        }
        expected = _json_hash(payload)
        if self.record_id and str(self.record_id) != expected:
            raise ValueError("provenance record fingerprint mismatch.")
        object.__setattr__(self, "parent_ids", parents)
        object.__setattr__(self, "primitive_ids", primitives)
        object.__setattr__(self, "observation_ids", observations)
        object.__setattr__(self, "certificate", _immutable_payload(certificate))
        object.__setattr__(self, "record_id", expected)

    def portable_payload(self) -> dict[str, Any]:
        return {
            "quantity": str(self.quantity),
            "status": str(self.status),
            "base_state_id": str(self.base_state_id),
            "chart_id": str(self.chart_id),
            "support_id": str(self.support_id),
            "parent_ids": list(self.parent_ids),
            "primitive_ids": list(self.primitive_ids),
            "observation_ids": list(self.observation_ids),
            "certificate": _portable_payload(self.certificate),
            "record_id": str(self.record_id),
        }

    @classmethod
    def from_portable_payload(
        cls, payload: Mapping[str, Any]
    ) -> "ProvenanceRecord":
        values = dict(payload)
        if not str(values.get("record_id", "")):
            raise ValueError("portable provenance record must retain its record_id.")
        return cls(**values)


@dataclass(frozen=True)
class OuterSupportedFrame:
    """One supported raw-FS frame plus the shared solver whitening."""

    raw_metric: np.ndarray
    raw_orthonormalizer: np.ndarray
    raw_analysis: np.ndarray
    solver_whitening: np.ndarray
    solver_whitening_pseudoinverse: np.ndarray
    regularized_to_raw_frame: np.ndarray
    retained_vectors: np.ndarray
    retained_eigenvalues: np.ndarray
    raw_eigenvalues: np.ndarray
    rank_relative_tolerance: float
    support_threshold: float
    metric_ridge: float
    whitening_provenance_id: str
    frame_id: str
    status: str
    source_primitive_ids: tuple[str, ...] = ()
    schema: str = OUTER_SUPPORTED_FRAME_SCHEMA

    def __post_init__(self) -> None:
        if str(self.schema) != OUTER_SUPPORTED_FRAME_SCHEMA:
            raise ValueError("outer supported-frame schema mismatch.")
        if str(self.status) not in PROVENANCE_STATUSES:
            raise ValueError("outer supported frame has an unknown status.")
        G = _finite_square(self.raw_metric, name="raw_metric")
        dimension = int(G.shape[0])
        O = np.asarray(self.raw_orthonormalizer, dtype=float)
        if O.ndim != 2 or O.shape[0] != dimension:
            raise ValueError("raw_orthonormalizer has an incompatible shape.")
        rank = int(O.shape[1])
        L = np.asarray(self.raw_analysis, dtype=float)
        W = np.asarray(self.solver_whitening, dtype=float)
        Wp = np.asarray(self.solver_whitening_pseudoinverse, dtype=float)
        bridge = np.asarray(self.regularized_to_raw_frame, dtype=float)
        vectors = np.asarray(self.retained_vectors, dtype=float)
        values = _finite_vector(
            self.retained_eigenvalues, name="retained_eigenvalues"
        )
        spectrum = _finite_vector(self.raw_eigenvalues, name="raw_eigenvalues")
        rank_tolerance = float(self.rank_relative_tolerance)
        if not math.isfinite(rank_tolerance) or rank_tolerance < 0.0:
            raise ValueError("rank_relative_tolerance must be finite and nonnegative.")
        ridge = float(self.metric_ridge)
        if not math.isfinite(ridge) or ridge < 0.0:
            raise ValueError("metric_ridge must be finite and nonnegative.")
        expected_shapes = {
            "raw_analysis": (rank, dimension),
            "solver_whitening": (dimension, rank),
            "solver_whitening_pseudoinverse": (rank, dimension),
            "regularized_to_raw_frame": (rank, rank),
            "retained_vectors": (dimension, rank),
            "retained_eigenvalues": (rank,),
            "raw_eigenvalues": (dimension,),
        }
        actual = {
            "raw_analysis": L.shape,
            "solver_whitening": W.shape,
            "solver_whitening_pseudoinverse": Wp.shape,
            "regularized_to_raw_frame": bridge.shape,
            "retained_vectors": vectors.shape,
            "retained_eigenvalues": values.shape,
            "raw_eigenvalues": spectrum.shape,
        }
        mismatches = [
            name for name, shape in expected_shapes.items() if actual[name] != shape
        ]
        if mismatches:
            raise ValueError(
                "outer supported-frame shape mismatch: " + ",".join(mismatches)
            )
        identity = np.eye(rank, dtype=float)
        orthogonality = float(np.linalg.norm(O.T @ G @ O - identity, ord="fro"))
        analysis_residual = float(np.linalg.norm(L @ O - identity, ord="fro"))
        retained_metric = _sym(vectors @ np.diag(values) @ vectors.T)
        quotient_residual = float(
            np.linalg.norm(L.T @ L - retained_metric, ord="fro")
        )
        if (
            orthogonality > 5.0e-8
            or analysis_residual > 5.0e-8
            or quotient_residual > 5.0e-8
        ):
            raise ValueError(
                "outer supported frame failed metric/analysis postconditions."
            )
        expected_threshold = float(
            rank_tolerance
            * (max(float(np.max(spectrum)), 0.0) if spectrum.size else 0.0)
        )
        expected_retained = np.asarray(
            spectrum[spectrum > expected_threshold], dtype=float
        )
        expected_W = np.asarray(
            vectors @ np.diag((values + ridge) ** -0.5), dtype=float
        )
        expected_Wp = np.asarray(
            np.diag((values + ridge) ** 0.5) @ vectors.T, dtype=float
        )
        expected_bridge = np.asarray(L @ expected_W, dtype=float)
        factor_fields = (
            ("solver_whitening", W, expected_W),
            (
                "solver_whitening_pseudoinverse",
                Wp,
                expected_Wp,
            ),
            (
                "regularized_to_raw_frame",
                bridge,
                expected_bridge,
            ),
            ("retained_eigenvalues", values, expected_retained),
            ("raw_eigenvalues", spectrum, np.linalg.eigvalsh(G)),
        )
        inconsistent = [
            name
            for name, actual_value, expected_value in factor_fields
            if actual_value.shape != np.asarray(expected_value).shape
            or not np.allclose(
                actual_value,
                expected_value,
                rtol=2.0e-12,
                atol=2.0e-13,
            )
        ]
        if inconsistent:
            raise ValueError(
                "outer supported frame disagrees with shared whitening: "
                + ",".join(inconsistent)
            )
        eigensystem_residual = float(
            np.linalg.norm(
                G @ vectors - vectors @ np.diag(values), ord="fro"
            )
        )
        vector_orthogonality = float(
            np.linalg.norm(vectors.T @ vectors - identity, ord="fro")
        )
        if eigensystem_residual > 5.0e-8 or vector_orthogonality > 5.0e-8:
            raise ValueError(
                "outer supported frame retained eigensystem is inconsistent."
            )
        if not math.isclose(
            float(self.support_threshold),
            expected_threshold,
            rel_tol=2.0e-12,
            abs_tol=2.0e-15,
        ):
            raise ValueError(
                "outer supported frame support threshold disagrees with the "
                "shared whitening convention."
            )
        expected_frame_id = _json_hash(
            {
                "schema": OUTER_SUPPORTED_FRAME_SCHEMA,
                "metric": _array_hash(G),
                "orthonormalizer": _array_hash(O),
                "raw_analysis": _array_hash(L),
                "solver_whitening": _array_hash(W),
                "solver_whitening_pseudoinverse": _array_hash(Wp),
                "regularized_to_raw_frame": _array_hash(bridge),
                "retained_vectors": _array_hash(vectors),
                "retained_eigenvalues": _array_hash(values),
                "raw_eigenvalues": _array_hash(spectrum),
                "rank_relative_tolerance": rank_tolerance,
                "support_threshold": float(self.support_threshold),
                "metric_ridge": ridge,
                "whitening_provenance_id": str(self.whitening_provenance_id),
                "status": str(self.status),
                "source_primitive_ids": sorted(
                    str(value) for value in self.source_primitive_ids
                ),
            }
        )
        if self.frame_id and str(self.frame_id) != expected_frame_id:
            raise ValueError("outer supported-frame fingerprint mismatch.")
        object.__setattr__(self, "raw_metric", _readonly(G))
        object.__setattr__(self, "raw_orthonormalizer", _readonly(O))
        object.__setattr__(self, "raw_analysis", _readonly(L))
        object.__setattr__(self, "solver_whitening", _readonly(W))
        object.__setattr__(self, "solver_whitening_pseudoinverse", _readonly(Wp))
        object.__setattr__(self, "regularized_to_raw_frame", _readonly(bridge))
        object.__setattr__(self, "retained_vectors", _readonly(vectors))
        object.__setattr__(self, "retained_eigenvalues", _readonly(values))
        object.__setattr__(self, "raw_eigenvalues", _readonly(spectrum))
        object.__setattr__(
            self,
            "source_primitive_ids",
            tuple(sorted({str(value) for value in self.source_primitive_ids})),
        )
        object.__setattr__(self, "frame_id", expected_frame_id)

    @property
    def dimension(self) -> int:
        return int(self.raw_metric.shape[0])

    @property
    def rank(self) -> int:
        return int(self.raw_orthonormalizer.shape[1])

    @property
    def support_id(self) -> str:
        return _json_hash(
            {
                "retained_vectors": _array_hash(self.retained_vectors),
                "retained_eigenvalues": _array_hash(self.retained_eigenvalues),
                "threshold": float(self.support_threshold),
            }
        )

    def portable_payload(self) -> dict[str, Any]:
        return {
            "schema": str(self.schema),
            "raw_metric": self.raw_metric.tolist(),
            "raw_orthonormalizer": self.raw_orthonormalizer.tolist(),
            "raw_analysis": self.raw_analysis.tolist(),
            "solver_whitening": self.solver_whitening.tolist(),
            "solver_whitening_pseudoinverse": (
                self.solver_whitening_pseudoinverse.tolist()
            ),
            "regularized_to_raw_frame": (
                self.regularized_to_raw_frame.tolist()
            ),
            "retained_vectors": self.retained_vectors.tolist(),
            "retained_eigenvalues": self.retained_eigenvalues.tolist(),
            "raw_eigenvalues": self.raw_eigenvalues.tolist(),
            "rank_relative_tolerance": float(self.rank_relative_tolerance),
            "support_threshold": float(self.support_threshold),
            "metric_ridge": float(self.metric_ridge),
            "whitening_provenance_id": str(self.whitening_provenance_id),
            "frame_id": str(self.frame_id),
            "status": str(self.status),
            "source_primitive_ids": list(self.source_primitive_ids),
        }

    @classmethod
    def from_portable_payload(
        cls, payload: Mapping[str, Any]
    ) -> "OuterSupportedFrame":
        values = dict(payload)
        if not str(values.get("frame_id", "")):
            raise ValueError("portable outer frame must retain its frame_id.")
        dimension = int(len(values.get("raw_eigenvalues", ())))
        rank = int(len(values.get("retained_eigenvalues", ())))
        matrix_shapes = {
            "raw_metric": (dimension, dimension),
            "raw_orthonormalizer": (dimension, rank),
            "raw_analysis": (rank, dimension),
            "solver_whitening": (dimension, rank),
            "solver_whitening_pseudoinverse": (rank, dimension),
            "regularized_to_raw_frame": (rank, rank),
            "retained_vectors": (dimension, rank),
        }
        for field_name, shape in matrix_shapes.items():
            array = np.asarray(values.get(field_name), dtype=float)
            if int(array.size) != int(np.prod(shape, dtype=int)):
                raise ValueError(
                    f"portable outer frame {field_name} has an invalid size."
                )
            values[field_name] = np.asarray(array, dtype=float).reshape(shape)
        return cls(**values)


def build_supported_frame(
    raw_metric: np.ndarray,
    *,
    config: OuterInformationConfig,
    status: str,
    source_primitive_ids: Sequence[str] = (),
    raw_orthonormalizer_override: np.ndarray | None = None,
) -> OuterSupportedFrame:
    """Use the repository-wide raw support/ridge convention for one frame."""

    G = _finite_square(raw_metric, name="raw_metric")
    factor = factor_supported_metric(
        G,
        rank_relative_tolerance=float(config.rank_relative_tolerance),
        metric_regularization=float(config.metric_regularization),
    )
    if not factor.feasible and factor.reason != "empty_supported_metric_subspace":
        raise ValueError(
            "outer metric failed shared supported factorization: "
            f"{factor.reason}."
        )
    override_supplied = raw_orthonormalizer_override is not None
    O = (
        np.asarray(factor.raw_orthonormalizer, dtype=float)
        if not override_supplied
        else np.asarray(raw_orthonormalizer_override, dtype=float)
    )
    if O.shape != (int(G.shape[0]), int(factor.rank)):
        raise ValueError("frame override does not match the retained support rank.")
    if factor.rank:
        # A quotient-frame synthesis is defined only modulo raw Gram-null
        # coordinate directions.  Requiring its Euclidean column span to equal
        # ``im(G)`` would incorrectly reject the canonical same-ray inclusion
        # when a newly admitted coordinate duplicates an old physical tangent.
        # The metric adjoint is the correctly typed analysis map.
        retained_metric = _sym(
            factor.retained_vectors
            @ np.diag(factor.retained_eigenvalues)
            @ factor.retained_vectors.T
        )
        if override_supplied:
            # The caller's frame may be exactly orthonormal for the measured
            # raw Gram matrix while carrying components in modes discarded by
            # the shared raw-support test.  This occurs naturally during a
            # same-ray extension when a candidate residual lies just below the
            # retained-support threshold.  Canonicalize the override in the
            # retained quotient and apply the nearest symmetric rewhitening;
            # this removes only unsupported gauge components and preserves the
            # caller's resolved physical orientation.
            support_projector = np.asarray(
                factor.retained_vectors @ factor.retained_vectors.T,
                dtype=float,
            )
            O_supported = np.asarray(support_projector @ O, dtype=float)
            override_metric = _sym(
                O_supported.T @ retained_metric @ O_supported
            )
            override_eigenvalues = np.linalg.eigvalsh(override_metric)
            numerical_floor = float(
                np.finfo(float).eps
                * max(1, int(factor.rank))
                * max(
                    1.0,
                    float(np.max(np.abs(override_eigenvalues)))
                    if override_eigenvalues.size
                    else 1.0,
                )
            )
            if (
                not override_eigenvalues.size
                or float(np.min(override_eigenvalues)) <= numerical_floor
            ):
                raise ValueError(
                    "frame override does not span the retained metric quotient."
                )
            O = np.asarray(
                O_supported @ _matrix_invsqrt_spd(override_metric),
                dtype=float,
            )
        L = np.asarray(O.T @ retained_metric, dtype=float)
        representation_residual = float(
            np.linalg.norm(L.T @ L - retained_metric, ord="fro")
        )
        if representation_residual > float(config.support_span_tolerance):
            raise ValueError(
                "frame override does not synthesize the retained metric quotient "
                f"after quotient canonicalization (residual={representation_residual:.6e}, "
                f"tolerance={float(config.support_span_tolerance):.6e})."
            )
    else:
        L = np.zeros((0, int(G.shape[0])), dtype=float)
    bridge = np.asarray(L @ factor.whitening, dtype=float)
    return OuterSupportedFrame(
        raw_metric=G,
        raw_orthonormalizer=O,
        raw_analysis=L,
        solver_whitening=np.asarray(factor.whitening, dtype=float),
        solver_whitening_pseudoinverse=np.asarray(
            factor.whitening_pseudoinverse, dtype=float
        ),
        regularized_to_raw_frame=bridge,
        retained_vectors=np.asarray(factor.retained_vectors, dtype=float),
        retained_eigenvalues=np.asarray(
            factor.retained_eigenvalues, dtype=float
        ),
        raw_eigenvalues=np.asarray(factor.raw_eigenvalues, dtype=float),
        rank_relative_tolerance=float(config.rank_relative_tolerance),
        support_threshold=float(factor.support_threshold),
        metric_ridge=float(factor.metric_ridge),
        whitening_provenance_id=str(factor.provenance_id),
        frame_id="",
        status=str(status),
        source_primitive_ids=tuple(source_primitive_ids),
    )


def supported_subspace_projector_defect(
    source: OuterSupportedFrame,
    target: OuterSupportedFrame,
) -> float:
    """Return the coordinate-invariant gap between two raw support spaces.

    Equal retained rank is not sufficient to establish support continuity:
    a null/retained eigenspace can rotate while preserving rank.  The spectral
    norm of the difference of the two Euclidean eigenspace projectors is the
    sine of the largest principal angle and therefore detects exactly that
    failure mode without depending on eigenvector signs or ordering.
    """

    if int(source.dimension) != int(target.dimension):
        raise ValueError("support projectors require a common raw dimension.")
    source_projector = _sym(
        source.retained_vectors @ source.retained_vectors.T
    )
    target_projector = _sym(
        target.retained_vectors @ target.retained_vectors.T
    )
    return float(
        np.linalg.norm(source_projector - target_projector, ord=2)
        if source_projector.size
        else 0.0
    )


def _raw_metric_null_compatibility(
    frame: OuterSupportedFrame,
    *,
    raw_gradient: np.ndarray,
    raw_curvature: np.ndarray | None,
    tolerance: float,
    gradient_policy: str = NULL_GRADIENT_REJECT,
    curvature_policy: str = "reject_raw_null_action_v1",
    raise_on_failure: bool = True,
) -> dict[str, Any]:
    """Certify that an energy model descends to the raw-metric quotient."""

    gradient = _finite_vector(raw_gradient, name="raw_gradient")
    if gradient.size != frame.dimension:
        raise ValueError("raw gradient does not match the metric dimension.")
    projector = _sym(frame.retained_vectors @ frame.retained_vectors.T)
    discarded = _sym(np.eye(frame.dimension, dtype=float) - projector)
    gradient_residual = float(np.linalg.norm(discarded @ gradient))
    machine_factor = float(
        4096.0 * np.finfo(float).eps * max(1, frame.dimension)
    )
    gradient_tolerance = float(
        max(float(tolerance), machine_factor * max(1.0, np.linalg.norm(gradient)))
    )
    curvature_residual = 0.0
    curvature_tolerance = float(tolerance)
    if raw_curvature is not None:
        curvature = _finite_square(raw_curvature, name="raw_curvature")
        if curvature.shape != (frame.dimension, frame.dimension):
            raise ValueError("raw curvature does not match the metric dimension.")
        curvature_residual = float(np.linalg.norm(curvature @ discarded, ord=2))
        curvature_tolerance = float(
            max(
                float(tolerance),
                machine_factor * max(1.0, np.linalg.norm(curvature, ord=2)),
            )
        )
    gradient_compatible = bool(gradient_residual <= gradient_tolerance)
    curvature_compatible = bool(curvature_residual <= curvature_tolerance)
    project_gradient = bool(
        str(gradient_policy) == NULL_GRADIENT_PROJECT
    )
    if str(gradient_policy) not in NULL_GRADIENT_POLICIES:
        raise ValueError("unknown raw-metric null-gradient policy.")
    project_curvature = bool(
        str(curvature_policy) == "project_to_supported_quotient_v1"
    )
    if str(curvature_policy) not in {
        "reject_raw_null_action_v1",
        "project_to_supported_quotient_v1",
    }:
        raise ValueError("unknown raw-metric null-curvature policy.")
    certificate = {
        "schema": "formal_manifold_outer_raw_metric_null_certificate_v1",
        "discarded_dimension": int(frame.dimension - frame.rank),
        "gradient_residual_norm": gradient_residual,
        "gradient_tolerance": gradient_tolerance,
        "gradient_compatible": gradient_compatible,
        "gradient_policy": str(gradient_policy),
        "gradient_representation": (
            "raw_gradient_projected_to_supported_quotient"
            if project_gradient
            else "raw_gradient_requires_null_annihilation"
        ),
        "raw_null_gradient_component_discarded": bool(
            project_gradient and not gradient_compatible
        ),
        "curvature_residual_norm": curvature_residual,
        "curvature_tolerance": curvature_tolerance,
        "curvature_compatible": curvature_compatible,
        "curvature_policy": str(curvature_policy),
        "curvature_representation": (
            "raw_direct_projected_to_supported_quotient"
            if project_curvature
            else "raw_direct_requires_null_annihilation"
        ),
        "raw_null_curvature_action_discarded": bool(
            project_curvature and not curvature_compatible
        ),
        "certified": bool(
            (gradient_compatible or project_gradient)
            and (curvature_compatible or project_curvature)
        ),
    }
    if (
        bool(raise_on_failure)
        and not gradient_compatible
        and not project_gradient
    ):
        raise ValueError("raw_metric_null_gradient_incompatible")
    if (
        bool(raise_on_failure)
        and not curvature_compatible
        and not project_curvature
    ):
        raise ValueError("raw_metric_null_curvature_incompatible")
    return certificate


@dataclass(frozen=True)
class SameRayExtension:
    frame: OuterSupportedFrame
    augmented_metric: np.ndarray
    residual_gram: np.ndarray
    inherited_frame_inclusion: np.ndarray
    candidate_residual_synthesis: np.ndarray
    old_to_new_registry_mapping: tuple[int, ...]
    candidate_positions: tuple[int, ...]
    source_primitive_ids: tuple[str, ...]
    telemetry: Mapping[str, Any]
    schema: str = OUTER_SAME_RAY_EXTENSION_SCHEMA

    def __post_init__(self) -> None:
        if str(self.schema) != OUTER_SAME_RAY_EXTENSION_SCHEMA:
            raise ValueError("same-ray extension schema mismatch.")
        object.__setattr__(self, "augmented_metric", _readonly(self.augmented_metric))
        object.__setattr__(self, "residual_gram", _readonly(self.residual_gram))
        object.__setattr__(
            self, "inherited_frame_inclusion", _readonly(self.inherited_frame_inclusion)
        )
        object.__setattr__(
            self,
            "candidate_residual_synthesis",
            _readonly(self.candidate_residual_synthesis),
        )
        object.__setattr__(
            self,
            "source_primitive_ids",
            tuple(sorted({str(value) for value in self.source_primitive_ids})),
        )
        object.__setattr__(self, "telemetry", _immutable_payload(self.telemetry))


def extend_same_ray_frame(
    old_frame: OuterSupportedFrame,
    *,
    active_candidate_gram: np.ndarray,
    candidate_candidate_gram: np.ndarray,
    old_to_new_registry_mapping: Sequence[int],
    candidate_positions: Sequence[int],
    config: OuterInformationConfig,
    source_primitive_ids: Sequence[str],
) -> SameRayExtension:
    """Exactly extend an inherited frame at an unchanged physical ray."""

    G_DB = np.asarray(active_candidate_gram, dtype=float)
    if G_DB.ndim != 2 or G_DB.shape[0] != old_frame.dimension:
        raise ValueError("active_candidate_gram has an incompatible shape.")
    candidate_count = int(G_DB.shape[1])
    G_BB = _finite_square(
        candidate_candidate_gram, name="candidate_candidate_gram"
    )
    if G_BB.shape != (candidate_count, candidate_count):
        raise ValueError("candidate_candidate_gram dimension mismatch.")
    old_mapping = tuple(int(value) for value in old_to_new_registry_mapping)
    new_positions = tuple(int(value) for value in candidate_positions)
    total = int(old_frame.dimension + candidate_count)
    if (
        len(old_mapping) != old_frame.dimension
        or len(new_positions) != candidate_count
        or set((*old_mapping, *new_positions)) != set(range(total))
        or len(set((*old_mapping, *new_positions))) != total
    ):
        raise ValueError(
            "old and candidate registry positions must partition the enlarged chart."
        )
    G_aug = np.zeros((total, total), dtype=float)
    G_aug[np.ix_(old_mapping, old_mapping)] = old_frame.raw_metric
    G_aug[np.ix_(old_mapping, new_positions)] = G_DB
    G_aug[np.ix_(new_positions, old_mapping)] = G_DB.T
    G_aug[np.ix_(new_positions, new_positions)] = G_BB
    G_aug = _sym(G_aug)

    # The full enlarged raw FS metric is the authority for support.  Factoring
    # the Schur residual against its own tiny scale can promote a roundoff-sized
    # residual of a physically redundant candidate into a false new mode.
    augmented_factor = factor_supported_metric(
        G_aug,
        rank_relative_tolerance=float(config.rank_relative_tolerance),
        metric_regularization=float(config.metric_regularization),
    )
    if not augmented_factor.feasible and augmented_factor.reason not in {
        "empty_supported_metric_subspace"
    }:
        if str(old_frame.status) in {STATUS_PREDICTED, STATUS_CORRECTED}:
            raise OuterInformationReanchorRequired(
                "enlarged_same_ray_metric_requires_exact_reanchor",
                telemetry={
                    "schema": (
                        "formal_manifold_same_ray_metric_reanchor_required_v1"
                    ),
                    "factorization_reason": str(augmented_factor.reason),
                    "source_frame_id": str(old_frame.frame_id),
                    "source_frame_status": str(old_frame.status),
                    "source_rank": int(old_frame.rank),
                    "candidate_count": int(candidate_count),
                    "augmented_rank": int(augmented_factor.rank),
                    "augmented_raw_eigenvalues": [
                        float(value)
                        for value in augmented_factor.raw_eigenvalues.tolist()
                    ],
                    "augmented_support_threshold": float(
                        augmented_factor.support_threshold
                    ),
                    "negative_eigenvalue_tolerance": float(
                        augmented_factor.negative_eigenvalue_tolerance
                    ),
                    "next_action": (
                        "discard_predictive_geometry_and_use_exact_metric"
                    ),
                    "structural_rollback_performed": False,
                    "classical_quantum_query_charge": 0,
                },
            )
        raise ValueError(
            "enlarged same-ray acquired metric failed supported "
            f"factorization: {augmented_factor.reason}."
        )

    K = np.asarray(
        old_frame.raw_orthonormalizer.T @ G_DB, dtype=float
    )
    Gamma = _sym(G_BB - K.T @ K)
    residual_eigenvalues, residual_eigenvectors = np.linalg.eigh(Gamma)
    residual_eigenvalues = np.asarray(residual_eigenvalues, dtype=float)
    residual_eigenvectors = np.asarray(residual_eigenvectors, dtype=float)
    if residual_eigenvalues.size and float(np.min(residual_eigenvalues)) < -float(
        augmented_factor.negative_eigenvalue_tolerance
    ):
        raise ValueError(
            "same-ray candidate residual is materially non-positive under the "
            "shared augmented-metric tolerance."
        )
    r = int(old_frame.rank)
    q = int(augmented_factor.rank - r)
    if q < 0 or q > candidate_count:
        raise ValueError(
            "same-ray growth changed inherited support incompatibly with the "
            "shared augmented-metric rank rule."
        )
    if q:
        retained_residual_values = np.asarray(
            residual_eigenvalues[-q:], dtype=float
        )
        retained_residual_vectors = np.asarray(
            residual_eigenvectors[:, -q:], dtype=float
        )
        if np.any(retained_residual_values <= 0.0):
            raise ValueError(
                "same-ray augmented support requires a nonpositive residual mode."
            )
        R = np.asarray(
            retained_residual_vectors
            @ np.diag(retained_residual_values ** -0.5),
            dtype=float,
        )
    else:
        R = np.zeros((candidate_count, 0), dtype=float)
    O_append = np.zeros(
        (old_frame.dimension + candidate_count, r + q), dtype=float
    )
    O_append[: old_frame.dimension, :r] = old_frame.raw_orthonormalizer
    if q:
        O_append[: old_frame.dimension, r:] = (
            -old_frame.raw_orthonormalizer @ K @ R
        )
        O_append[old_frame.dimension :, r:] = R
    O_aug = np.zeros((total, r + q), dtype=float)
    O_aug[list(old_mapping), :] = O_append[: old_frame.dimension, :]
    if candidate_count:
        O_aug[list(new_positions), :] = O_append[old_frame.dimension :, :]

    if int(augmented_factor.rank) != r + q:
        raise ValueError(
            "same-ray Schur rank disagrees with the shared augmented support rule."
        )
    extension_residual = float(
        np.linalg.norm(O_aug.T @ G_aug @ O_aug - np.eye(r + q), ord="fro")
    )
    if extension_residual > 5.0e-8:
        raise FloatingPointError("same-ray extended frame is not FS orthonormal.")
    frame = build_supported_frame(
        G_aug,
        config=config,
        status=STATUS_INHERITED,
        source_primitive_ids=tuple(source_primitive_ids),
        raw_orthonormalizer_override=O_aug,
    )
    quotient_canonicalization_fro = float(
        np.linalg.norm(frame.raw_orthonormalizer - O_aug, ord="fro")
    )
    inclusion = np.zeros((r + q, r), dtype=float)
    inclusion[:r, :] = np.eye(r, dtype=float)
    return SameRayExtension(
        frame=frame,
        augmented_metric=G_aug,
        residual_gram=Gamma,
        inherited_frame_inclusion=inclusion,
        candidate_residual_synthesis=R,
        old_to_new_registry_mapping=old_mapping,
        candidate_positions=new_positions,
        source_primitive_ids=tuple(source_primitive_ids),
        telemetry={
            "schema": OUTER_SAME_RAY_EXTENSION_SCHEMA,
            "old_coordinate_count": int(old_frame.dimension),
            "candidate_coordinate_count": int(candidate_count),
            "old_supported_rank": int(r),
            "residual_supported_rank": int(q),
            "enlarged_supported_rank": int(r + q),
            "residual_support_threshold": float(
                augmented_factor.support_threshold
            ),
            "residual_spectrum": [
                float(value) for value in residual_eigenvalues.tolist()
            ],
            "residual_rank_source": (
                "augmented_supported_rank_minus_inherited_rank_v1"
            ),
            "old_old_metric_reacquired": False,
            "frame_orthonormality_residual": extension_residual,
            "quotient_frame_canonicalization_fro": (
                quotient_canonicalization_fro
            ),
            "quotient_frame_canonicalization_applied": bool(
                quotient_canonicalization_fro
                > 32.0 * np.finfo(float).eps * max(1, total)
            ),
            "shared_whitening_provenance_id": str(
                frame.whitening_provenance_id
            ),
            "classical_quantum_query_charge": 0,
        },
    )


@dataclass(frozen=True)
class MetricPrediction:
    source_frame_id: str
    frame: OuterSupportedFrame
    normalized_strain: np.ndarray
    step_scale: float
    status: str
    telemetry: Mapping[str, Any]
    schema: str = OUTER_METRIC_PREDICTION_SCHEMA

    def __post_init__(self) -> None:
        if str(self.schema) != OUTER_METRIC_PREDICTION_SCHEMA:
            raise ValueError("metric-prediction schema mismatch.")
        if str(self.status) != STATUS_PREDICTED:
            raise ValueError("metric prediction must remain explicitly predicted.")
        object.__setattr__(self, "normalized_strain", _readonly(self.normalized_strain))
        object.__setattr__(self, "telemetry", _immutable_payload(self.telemetry))


def predict_endpoint_metric(
    source: OuterSupportedFrame,
    *,
    normalized_strain: np.ndarray | None,
    step_scale: float,
    config: OuterInformationConfig,
) -> MetricPrediction:
    """Apply the affine-invariant exponential on the certified support."""

    scale = float(step_scale)
    if not math.isfinite(scale) or scale < 0.0:
        raise ValueError("step_scale must be finite and nonnegative.")
    H = (
        np.zeros((source.rank, source.rank), dtype=float)
        if normalized_strain is None
        else _finite_square(normalized_strain, name="normalized_strain")
    )
    if H.shape != (source.rank, source.rank):
        raise ValueError("normalized_strain must act on the source support.")
    exp_H = _matrix_exp_symmetric(scale * H)
    G_pred = _sym(source.raw_analysis.T @ exp_H @ source.raw_analysis)
    O_pred = np.asarray(
        source.raw_orthonormalizer
        @ _matrix_exp_symmetric(-0.5 * scale * H),
        dtype=float,
    )
    predicted_factor = factor_supported_metric(
        G_pred,
        rank_relative_tolerance=float(config.rank_relative_tolerance),
        metric_regularization=float(config.metric_regularization),
    )
    if int(predicted_factor.rank) != int(source.rank):
        raise OuterInformationReanchorRequired(
            "predicted_endpoint_metric_support_rank_changed",
            telemetry={
                "schema": "formal_manifold_outer_prediction_support_transition_v1",
                "source_frame_id": str(source.frame_id),
                "source_support_id": str(source.support_id),
                "source_rank": int(source.rank),
                "predicted_rank": int(predicted_factor.rank),
                "predicted_raw_eigenvalues": [
                    float(value)
                    for value in predicted_factor.raw_eigenvalues.tolist()
                ],
                "predicted_support_threshold": float(
                    predicted_factor.support_threshold
                ),
                "step_scale": float(scale),
                "normalized_strain_operator_norm": float(
                    np.linalg.norm(H, ord=2) if H.size else 0.0
                ),
                "next_action": "discard_prediction_and_require_exact_reanchor",
                "structural_rollback_performed": False,
                "classical_quantum_query_charge": 0,
            },
        )
    frame = build_supported_frame(
        G_pred,
        config=config,
        status=STATUS_PREDICTED,
        source_primitive_ids=source.source_primitive_ids,
        raw_orthonormalizer_override=O_pred,
    )
    return MetricPrediction(
        source_frame_id=str(source.frame_id),
        frame=frame,
        normalized_strain=H,
        step_scale=scale,
        status=STATUS_PREDICTED,
        telemetry={
            "schema": OUTER_METRIC_PREDICTION_SCHEMA,
            "source_frame_id": str(source.frame_id),
            "target_frame_id": str(frame.frame_id),
            "step_scale": scale,
            "normalized_strain_operator_norm": float(
                np.linalg.norm(H, ord=2) if H.size else 0.0
            ),
            "metric_prediction_status": STATUS_PREDICTED,
            "orientation_inferred_from_endpoint_metrics": False,
            "classical_quantum_query_charge": 0,
        },
    )


def _common_support_basis(
    source: OuterSupportedFrame,
    target: OuterSupportedFrame,
    *,
    tolerance: float,
) -> np.ndarray:
    if source.dimension != target.dimension or source.rank != target.rank:
        raise ValueError("transport requires equal raw dimensions and support ranks.")
    if source.rank == 0:
        return np.zeros((source.dimension, 0), dtype=float)
    U0 = np.asarray(source.retained_vectors, dtype=float)
    U1 = np.asarray(target.retained_vectors, dtype=float)
    residual = float(np.linalg.norm(U0 @ U0.T - U1 @ U1.T, ord="fro"))
    if residual > float(tolerance):
        raise ValueError("transport endpoints do not share a certified support span.")
    return U0


@dataclass(frozen=True)
class SplitConnectionTransport:
    source_frame_id: str
    target_frame_id: str
    metric_polar: np.ndarray
    orientation: np.ndarray
    coefficient_transport: np.ndarray
    raw_coordinate_transport: np.ndarray
    orthogonality_residual: float
    pairing_residual: float
    orientation_provenance: str
    telemetry: Mapping[str, Any]
    schema: str = OUTER_TRANSPORT_SCHEMA

    def __post_init__(self) -> None:
        if str(self.schema) != OUTER_TRANSPORT_SCHEMA:
            raise ValueError("split-connection transport schema mismatch.")
        for name in (
            "metric_polar",
            "orientation",
            "coefficient_transport",
            "raw_coordinate_transport",
        ):
            object.__setattr__(self, name, _readonly(getattr(self, name)))
        object.__setattr__(self, "telemetry", _immutable_payload(self.telemetry))


def build_split_connection_transport(
    source: OuterSupportedFrame,
    target: OuterSupportedFrame,
    *,
    config: OuterInformationConfig,
    skew_connection: np.ndarray | None = None,
    step_scale: float = 1.0,
    measured_orientation: np.ndarray | None = None,
    orientation_provenance: str | None = None,
) -> SplitConnectionTransport:
    """Build metric-polar transport plus predicted or measured orientation."""

    basis = _common_support_basis(
        source, target, tolerance=float(config.support_span_tolerance)
    )
    rank = int(source.rank)
    if rank:
        G0 = _sym(basis.T @ source.raw_metric @ basis)
        G1 = _sym(basis.T @ target.raw_metric @ basis)
        G1_sqrt = _matrix_sqrt_spd(G1)
        G1_invsqrt = _matrix_invsqrt_spd(G1)
        middle = _sym(G1_sqrt @ G0 @ G1_sqrt)
        C_support = _sym(G1_invsqrt @ _matrix_sqrt_spd(middle) @ G1_invsqrt)
        C_raw = np.asarray(basis @ C_support @ basis.T, dtype=float)
        Rg = np.asarray(
            target.raw_analysis @ C_raw @ source.raw_orthonormalizer,
            dtype=float,
        )
    else:
        C_raw = np.zeros((source.dimension, source.dimension), dtype=float)
        Rg = np.zeros((0, 0), dtype=float)
    metric_polar_preprojection_orthogonality = float(
        np.linalg.norm(Rg.T @ Rg - np.eye(rank), ord="fro")
    )
    metric_polar_projection_applied = False
    metric_polar_projection_correction = 0.0
    metric_polar_preprojection_singular_values: list[float] = []
    if (
        rank
        and metric_polar_preprojection_orthogonality
        > float(config.transport_orthogonality_tolerance)
    ):
        # ``Rg`` is the coefficient representation of the intrinsic
        # metric-polar isometry between two whitened supported frames.  It is
        # orthogonal in exact arithmetic, but forming it through raw charts can
        # lose that property when the retained metric is poorly conditioned.
        # Restore the intended isometry with the nearest orthogonal polar
        # factor; do not continue through a singular or non-finite map.
        U_polar, singular_values, Vh_polar = np.linalg.svd(
            Rg, full_matrices=False
        )
        if not np.all(np.isfinite(singular_values)):
            raise FloatingPointError(
                "split metric-polar transport has non-finite singular values."
            )
        singular_floor = max(
            float(config.orientation_alignment_floor),
            float(np.finfo(float).eps),
        )
        if singular_values.size and float(np.min(singular_values)) <= singular_floor:
            raise FloatingPointError(
                "split metric-polar transport is numerically singular."
            )
        metric_polar_preprojection_singular_values = [
            float(value) for value in singular_values.tolist()
        ]
        raw_Rg = np.asarray(Rg, dtype=float)
        Rg = np.asarray(U_polar @ Vh_polar, dtype=float)
        metric_polar_projection_correction = float(
            np.linalg.norm(Rg - raw_Rg, ord="fro")
        )
        metric_polar_projection_applied = True
    scale = float(step_scale)
    if not math.isfinite(scale) or scale < 0.0:
        raise ValueError("step_scale must be finite and nonnegative.")
    measured_registration: np.ndarray | None = None
    if measured_orientation is not None:
        # A measured cross-frame Procrustes factor is already the complete
        # source-to-target coefficient registration.  It must not be composed
        # a second time with the intrinsic metric-polar predictor.  We retain
        # the latter as telemetry and expose the residual orientation factor
        # relative to it, but the authoritative coefficient map is measured.
        measured_registration = np.asarray(measured_orientation, dtype=float)
        if measured_registration.shape != (rank, rank) or not np.all(
            np.isfinite(measured_registration)
        ):
            raise ValueError("measured orientation has an incompatible shape.")
        P = measured_registration
        Romega = np.asarray(P @ Rg.T, dtype=float)
        provenance = str(
            orientation_provenance or "measured_cross_frame_procrustes_v1"
        )
    else:
        omega = (
            np.zeros((rank, rank), dtype=float)
            if skew_connection is None
            else np.asarray(skew_connection, dtype=float)
        )
        if omega.shape != (rank, rank) or not np.all(np.isfinite(omega)):
            raise ValueError("skew_connection has an incompatible shape.")
        skew_residual = float(np.linalg.norm(omega + omega.T, ord="fro"))
        if skew_residual > 5.0e-10:
            raise ValueError("skew_connection must be skew-symmetric.")
        Romega = np.asarray(expm(-scale * omega), dtype=float)
        provenance = str(
            orientation_provenance or "predicted_skew_connection_v1"
        )
    if Romega.shape != (rank, rank) or not np.all(np.isfinite(Romega)):
        raise ValueError("orientation map has an incompatible shape.")
    orientation_residual = float(
        np.linalg.norm(Romega.T @ Romega - np.eye(rank), ord="fro")
    )
    if measured_registration is None:
        P = np.asarray(Romega @ Rg, dtype=float)
    orthogonality = float(np.linalg.norm(P.T @ P - np.eye(rank), ord="fro"))
    if orthogonality > float(config.transport_orthogonality_tolerance):
        raise FloatingPointError("split transport is not orthogonal in the FS frame.")
    raw_transport = np.asarray(
        target.raw_orthonormalizer @ P @ source.raw_analysis, dtype=float
    )
    if rank:
        probe = np.arange(1, rank + 1, dtype=float)
        vector = P @ probe
        covector = np.linalg.solve(P.T, probe)
        pairing = float(
            abs(float(covector @ vector - probe @ probe))
            / (abs(float(probe @ probe)) + np.finfo(float).tiny)
        )
    else:
        pairing = 0.0
    return SplitConnectionTransport(
        source_frame_id=str(source.frame_id),
        target_frame_id=str(target.frame_id),
        metric_polar=Rg,
        orientation=Romega,
        coefficient_transport=P,
        raw_coordinate_transport=raw_transport,
        orthogonality_residual=orthogonality,
        pairing_residual=pairing,
        orientation_provenance=provenance,
        telemetry={
            "schema": OUTER_TRANSPORT_SCHEMA,
            "metric_polar_is_intrinsic_only": True,
            "orientation_inferred_from_endpoint_metrics": False,
            "orientation_provenance": provenance,
            "cross_state_tangent_data_acquired": bool(
                measured_registration is not None
            ),
            "measured_registration_is_complete_coefficient_transport": bool(
                measured_registration is not None
            ),
            "orientation_orthogonality_residual": orientation_residual,
            "metric_polar_preprojection_orthogonality_residual": (
                metric_polar_preprojection_orthogonality
            ),
            "metric_polar_projection_applied": bool(
                metric_polar_projection_applied
            ),
            "metric_polar_projection_correction_fro": (
                metric_polar_projection_correction
            ),
            "metric_polar_preprojection_singular_values": (
                metric_polar_preprojection_singular_values
            ),
            "transport_orthogonality_residual": orthogonality,
            "pairing_residual": pairing,
            "classical_quantum_query_charge": 0,
        },
    )


def transport_vector(transport: SplitConnectionTransport, value: Any) -> np.ndarray:
    vector = _finite_vector(value, name="vector")
    if vector.size != transport.coefficient_transport.shape[1]:
        raise ValueError("vector dimension does not match transport source.")
    return np.asarray(transport.coefficient_transport @ vector, dtype=float)


def transport_covector(
    transport: SplitConnectionTransport, value: Any
) -> np.ndarray:
    covector = _finite_vector(value, name="covector")
    P = np.asarray(transport.coefficient_transport, dtype=float)
    if covector.size != P.shape[1] or P.shape[0] != P.shape[1]:
        raise ValueError("covector transport requires one square common support.")
    return np.asarray(np.linalg.solve(P.T, covector), dtype=float)


def transport_direct_curvature(
    transport: SplitConnectionTransport, value: Any
) -> np.ndarray:
    direct = _finite_square(value, name="direct curvature")
    P = np.asarray(transport.coefficient_transport, dtype=float)
    if direct.shape != (P.shape[1], P.shape[1]) or P.shape[0] != P.shape[1]:
        raise ValueError("direct curvature does not match common support.")
    Pinv = np.linalg.inv(P)
    return _sym(Pinv.T @ direct @ Pinv)


def transport_inverse_curvature(
    transport: SplitConnectionTransport, value: Any
) -> np.ndarray:
    inverse = _finite_square(value, name="inverse curvature")
    P = np.asarray(transport.coefficient_transport, dtype=float)
    if inverse.shape != (P.shape[1], P.shape[1]):
        raise ValueError("inverse curvature does not match common support.")
    return _sym(P @ inverse @ P.T)


def _typed_curvature_action(
    *,
    curvature_kind: str,
    curvature: np.ndarray,
    displacement: np.ndarray,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Return the first-order differential change in one target frame.

    A direct curvature maps a tangent vector to an energy covector.  An
    inverse curvature maps covectors to vectors, so its corresponding direct
    action is obtained by solving ``B y = s``.  A missing, singular, or
    indefinite inverse model is not silently pseudo-inverted: the transported
    source differential remains the prediction and the telemetry records why
    the curvature action was unavailable.
    """

    kind = str(curvature_kind)
    s = _finite_vector(displacement, name="curvature displacement")
    if kind == CURVATURE_NONE:
        return np.zeros_like(s), {
            "available": False,
            "applied": False,
            "reason": "curvature_model_absent",
            "curvature_kind": kind,
        }
    model = _finite_square(curvature, name="curvature action model")
    if model.shape != (s.size, s.size):
        raise ValueError("curvature action model and displacement differ.")
    if kind == CURVATURE_DIRECT:
        action = np.asarray(model @ s, dtype=float)
        return action, {
            "available": True,
            "applied": True,
            "reason": "direct_curvature_action",
            "curvature_kind": kind,
            "solve_condition_number": None,
        }
    if kind != CURVATURE_INVERSE:
        raise ValueError("unknown curvature kind for differential prediction.")
    eigenvalues = np.linalg.eigvalsh(model)
    minimum = float(np.min(eigenvalues)) if eigenvalues.size else float("inf")
    condition = float(np.linalg.cond(model)) if model.size else 1.0
    if (
        not math.isfinite(minimum)
        or minimum <= np.finfo(float).eps
        or not math.isfinite(condition)
    ):
        return np.zeros_like(s), {
            "available": False,
            "applied": False,
            "reason": "inverse_curvature_not_spd_solvable",
            "curvature_kind": kind,
            "minimum_eigenvalue": minimum,
            "solve_condition_number": condition,
        }
    action = np.asarray(np.linalg.solve(model, s), dtype=float)
    return action, {
        "available": True,
        "applied": True,
        "reason": "inverse_curvature_solved_direct_action",
        "curvature_kind": kind,
        "minimum_eigenvalue": minimum,
        "solve_condition_number": condition,
    }


def _guarded_typed_secant_update(
    *,
    curvature_kind: str,
    curvature: np.ndarray,
    displacement: np.ndarray,
    differential_change: np.ndarray,
    config: OuterInformationConfig,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Apply the route's typed SR1/BFGS secant update with one guard policy."""

    kind = str(curvature_kind)
    model = np.asarray(curvature, dtype=float)
    s = _finite_vector(displacement, name="secant displacement")
    y = _finite_vector(differential_change, name="secant differential change")
    telemetry: dict[str, Any] = {
        "curvature_update_applied": False,
        "curvature_update_kind": (
            "direct_sr1"
            if kind == CURVATURE_DIRECT
            else "inverse_bfgs"
            if kind == CURVATURE_INVERSE
            else "none"
        ),
        "curvature_update_denominator": None,
        "reason": "unsupported_or_missing_curvature",
        "s_norm": float(np.linalg.norm(s)),
        "y_norm": float(np.linalg.norm(y)),
    }
    if kind == CURVATURE_NONE:
        return np.zeros((0, 0), dtype=float), telemetry
    model = _finite_square(model, name="secant curvature model")
    if model.shape != (s.size, s.size) or y.size != s.size:
        raise ValueError("secant model, displacement, and differential differ.")
    s_norm = float(telemetry["s_norm"])
    y_norm = float(telemetry["y_norm"])
    if s_norm <= float(config.secant_min_norm):
        telemetry["reason"] = "secant_displacement_too_small"
        return model, telemetry
    if y_norm <= float(config.secant_min_norm):
        telemetry["reason"] = "secant_differential_change_too_small"
        return model, telemetry
    if kind == CURVATURE_DIRECT:
        residual = np.asarray(y - model @ s, dtype=float)
        denominator = float(np.dot(residual, s))
        telemetry["curvature_update_denominator"] = denominator
        threshold = float(config.secant_denominator_tolerance) * max(
            float(np.linalg.norm(residual)) * s_norm,
            np.finfo(float).eps,
        )
        if abs(denominator) <= threshold:
            telemetry["reason"] = "direct_sr1_denominator_guard"
            return model, telemetry
        telemetry["curvature_update_applied"] = True
        telemetry["reason"] = "guarded_direct_sr1_applied"
        return _sym(model + np.outer(residual, residual) / denominator), telemetry
    if kind != CURVATURE_INVERSE:
        raise ValueError("unknown curvature kind for secant update.")
    denominator = float(np.dot(s, y))
    telemetry["curvature_update_denominator"] = denominator
    threshold = float(config.secant_denominator_tolerance) * max(
        s_norm * y_norm,
        np.finfo(float).eps,
    )
    if denominator <= threshold:
        telemetry["reason"] = "inverse_bfgs_curvature_guard"
        return model, telemetry
    rho = 1.0 / denominator
    identity = np.eye(model.shape[0], dtype=float)
    left = identity - rho * np.outer(s, y)
    telemetry["curvature_update_applied"] = True
    telemetry["reason"] = "guarded_inverse_bfgs_applied"
    return _sym(left @ model @ left.T + rho * np.outer(s, s)), telemetry


@dataclass(frozen=True)
class ClosureResult:
    outcome: str
    reason: str
    frame: OuterSupportedFrame | None
    defect: float
    probe_rank: int
    blind_dimension: int
    correction: np.ndarray
    observed_probe_gram: np.ndarray
    predicted_probe_gram: np.ndarray
    source_primitive_ids: tuple[str, ...]
    source_observation_ids: tuple[str, ...]
    telemetry: Mapping[str, Any]
    schema: str = OUTER_CLOSURE_SCHEMA

    def __post_init__(self) -> None:
        if str(self.schema) != OUTER_CLOSURE_SCHEMA:
            raise ValueError("closure-result schema mismatch.")
        if str(self.outcome) not in CLOSURE_OUTCOMES:
            raise ValueError("unknown closure outcome.")
        for name in (
            "correction",
            "observed_probe_gram",
            "predicted_probe_gram",
        ):
            object.__setattr__(self, name, _readonly(getattr(self, name)))
        object.__setattr__(
            self,
            "source_primitive_ids",
            tuple(sorted({str(value) for value in self.source_primitive_ids})),
        )
        object.__setattr__(
            self,
            "source_observation_ids",
            tuple(sorted({str(value) for value in self.source_observation_ids})),
        )
        object.__setattr__(self, "telemetry", _immutable_payload(self.telemetry))

    def portable_payload(self) -> dict[str, Any]:
        return {
            "schema": str(self.schema),
            "outcome": str(self.outcome),
            "reason": str(self.reason),
            "frame": (
                None if self.frame is None else self.frame.portable_payload()
            ),
            "defect": float(self.defect),
            "probe_rank": int(self.probe_rank),
            "blind_dimension": int(self.blind_dimension),
            "correction": self.correction.tolist(),
            "observed_probe_gram": self.observed_probe_gram.tolist(),
            "predicted_probe_gram": self.predicted_probe_gram.tolist(),
            "source_primitive_ids": list(self.source_primitive_ids),
            "source_observation_ids": list(self.source_observation_ids),
            "telemetry": _portable_payload(self.telemetry),
        }

    @classmethod
    def from_portable_payload(
        cls, payload: Mapping[str, Any]
    ) -> "ClosureResult":
        values = dict(payload)
        frame = values.get("frame")
        values["frame"] = (
            None
            if frame is None
            else OuterSupportedFrame.from_portable_payload(frame)
        )
        values.setdefault("source_observation_ids", ())
        return cls(**values)


def close_predicted_geometry(
    predicted: OuterSupportedFrame,
    *,
    probe_coefficients: np.ndarray | None = None,
    observed_probe_gram: np.ndarray | None = None,
    config: OuterInformationConfig,
    source_primitive_ids: Sequence[str] = (),
    source_observation_ids: Sequence[str] = (),
    prediction_age: int = 1,
    force_minimum_change_correction: bool = False,
    authoritative_full_endpoint_metric: np.ndarray | None = None,
    metric_source_primitive_ids: Sequence[str] = (),
) -> ClosureResult:
    """Apply deterministic probe closure and minimum-change correction.

    ``authoritative_full_endpoint_metric`` is a typed authority path, not a
    shorthand for a spanning directional probe.  Its entries are the complete
    raw endpoint Gram matrix, and ``metric_source_primitive_ids`` must contain
    only the immutable primitives that acquired that matrix.  A support-
    preserving exact metric replaces the predicted metric while retaining the
    prediction's unresolved orientation gauge.  It therefore acquires the
    metric/frame, but does not acquire cross-state registration or curvature.

    The original probe-closure behavior remains the default.  The two paths
    are deliberately mutually exclusive so generic probe or gradient
    primitive IDs cannot be laundered into exact metric/frame provenance.
    """

    exact_metric_supplied = authoritative_full_endpoint_metric is not None
    metric_primitive_ids = tuple(
        sorted({str(value).strip() for value in metric_source_primitive_ids})
    )
    generic_primitive_ids = tuple(
        sorted({str(value).strip() for value in source_primitive_ids})
    )
    if any(
        not value
        for value in (*metric_primitive_ids, *generic_primitive_ids)
    ):
        raise ValueError("closure primitive identifiers must be nonempty.")
    if exact_metric_supplied:
        if generic_primitive_ids:
            raise ValueError(
                "authoritative full endpoint metric closure accepts only "
                "metric_source_primitive_ids, not generic source primitives."
            )
        if not metric_primitive_ids:
            raise ValueError(
                "authoritative full endpoint metric closure requires immutable "
                "metric primitive IDs."
            )
        if probe_coefficients is not None or observed_probe_gram is not None:
            raise ValueError(
                "authoritative full endpoint metric closure is mutually "
                "exclusive with directional probe closure."
            )
        exact_metric = _finite_square(
            authoritative_full_endpoint_metric,
            name="authoritative_full_endpoint_metric",
        )
        if exact_metric.shape != (predicted.dimension, predicted.dimension):
            raise ValueError(
                "authoritative full endpoint metric has an incompatible shape."
            )
        exact_support = build_supported_frame(
            exact_metric,
            config=config,
            status=STATUS_ACQUIRED,
            source_primitive_ids=metric_primitive_ids,
        )
        support_defect = supported_subspace_projector_defect(
            predicted, exact_support
        )
        rank_matches = bool(exact_support.rank == predicted.rank)
        support_matches = bool(
            rank_matches
            and support_defect <= float(config.support_span_tolerance)
        )
        relative = (
            _sym(
                predicted.raw_orthonormalizer.T
                @ exact_metric
                @ predicted.raw_orthonormalizer
            )
            if rank_matches
            else np.zeros((predicted.rank, predicted.rank), dtype=float)
        )
        identity = np.eye(predicted.rank, dtype=float)
        Delta = _sym(relative - identity)
        relative_eigenvalues = np.linalg.eigvalsh(relative)
        min_relative = (
            float(np.min(relative_eigenvalues))
            if relative_eigenvalues.size
            else 1.0
        )
        correction_norm = float(
            np.linalg.norm(Delta, ord=2) if Delta.size else 0.0
        )
        defect = correction_norm
        age_exceeded = int(prediction_age) >= int(config.max_prediction_age)
        frame: OuterSupportedFrame | None = None
        if not support_matches:
            outcome = CLOSURE_ANCHOR
            reason = "authoritative_full_endpoint_metric_changed_support"
        elif min_relative <= float(config.correction_min_eigenvalue):
            outcome = CLOSURE_ANCHOR
            reason = "authoritative_full_endpoint_metric_lost_positive_support"
        else:
            try:
                corrected_orthonormalizer = np.asarray(
                    predicted.raw_orthonormalizer
                    @ _matrix_invsqrt_spd(relative),
                    dtype=float,
                )
                frame = build_supported_frame(
                    exact_metric,
                    config=config,
                    status=STATUS_ACQUIRED,
                    source_primitive_ids=metric_primitive_ids,
                    raw_orthonormalizer_override=corrected_orthonormalizer,
                )
            except (ValueError, FloatingPointError):
                outcome = CLOSURE_ANCHOR
                reason = (
                    "authoritative_full_endpoint_metric_frame_correction_failed"
                )
                frame = None
            else:
                outcome = CLOSURE_CORRECT
                reason = "authoritative_full_endpoint_metric_acquired"
        return ClosureResult(
            outcome=outcome,
            reason=reason,
            frame=frame,
            defect=defect,
            probe_rank=int(predicted.rank),
            blind_dimension=0,
            correction=Delta,
            observed_probe_gram=relative,
            predicted_probe_gram=identity,
            source_primitive_ids=metric_primitive_ids,
            source_observation_ids=tuple(source_observation_ids),
            telemetry={
                "schema": OUTER_CLOSURE_SCHEMA,
                "outcome": outcome,
                "reason": reason,
                "dimensionless_closure_defect": defect,
                "probe_rank": int(predicted.rank),
                "supported_rank": int(predicted.rank),
                "exact_supported_rank": int(exact_support.rank),
                "blind_dimension": 0,
                "observation_spans_support": True,
                "correction_operator_norm": correction_norm,
                "minimum_relative_metric_eigenvalue": min_relative,
                "prediction_age": int(prediction_age),
                "prediction_age_budget_exhausted_before_exact_metric": bool(
                    age_exceeded
                ),
                "full_endpoint_metric_acquired": True,
                "authoritative_full_endpoint_metric": True,
                "authoritative_metric_support_projector_defect": (
                    support_defect
                ),
                "authoritative_metric_support_matches_prediction": bool(
                    support_matches
                ),
                "metric_frame_status": (
                    STATUS_ACQUIRED if frame is not None else STATUS_INVALIDATED
                ),
                "metric_frame_authority": (
                    "acquired_exact_full_endpoint_gram_minimum_change_gauge_v1"
                ),
                "cross_state_tangent_data_acquired": False,
                "metric_closure_outcome": outcome,
                "orientation_closure_status": (
                    "unobserved_predicted_connection"
                ),
                "orientation_sensitive_observation_acquired": False,
                "curvature_closure_status": "unobserved_predicted_transport",
                "transport_fully_certified": False,
                "classical_quantum_query_charge": 0,
                "force_minimum_change_correction": True,
                "metric_source_primitive_ids": list(metric_primitive_ids),
            },
        )

    if metric_primitive_ids:
        raise ValueError(
            "metric_source_primitive_ids require an authoritative full "
            "endpoint metric."
        )
    if probe_coefficients is None or observed_probe_gram is None:
        raise ValueError(
            "directional closure requires probe_coefficients and "
            "observed_probe_gram."
        )

    X = np.asarray(probe_coefficients, dtype=float)
    if X.ndim != 2 or X.shape[0] != predicted.rank:
        raise ValueError("probe_coefficients must have one row per support mode.")
    if not np.all(np.isfinite(X)) or X.shape[1] < 1:
        raise ValueError("probe_coefficients must be finite and nonempty.")
    probe_rank = int(np.linalg.matrix_rank(X))
    if probe_rank != int(X.shape[1]):
        raise ValueError("probe coefficients must have full column rank.")
    Yhat = _sym(X.T @ X)
    Y = _finite_square(observed_probe_gram, name="observed_probe_gram")
    if Y.shape != Yhat.shape:
        raise ValueError("observed probe Gram has an incompatible shape.")
    R = _sym(Y - Yhat)
    try:
        normalized = _matrix_invsqrt_spd(Yhat) @ R @ _matrix_invsqrt_spd(Yhat)
    except ValueError:
        normalized = np.full_like(R, np.nan)
    defect = float(
        np.linalg.norm(normalized, ord=2)
        if np.all(np.isfinite(normalized))
        else float("inf")
    )
    pinv = np.linalg.pinv(X)
    Delta = _sym(pinv.T @ R @ pinv)
    relative = _sym(np.eye(predicted.rank, dtype=float) + Delta)
    relative_eigenvalues = np.linalg.eigvalsh(relative)
    min_relative = (
        float(np.min(relative_eigenvalues))
        if relative_eigenvalues.size
        else 1.0
    )
    correction_norm = float(
        np.linalg.norm(Delta, ord=2) if Delta.size else 0.0
    )
    blind = int(predicted.rank - probe_rank)
    # The configured age is the largest number of unanchored predictions that
    # may exist *before* this closure.  Equality therefore exhausts the budget
    # and requires an authoritative anchor; using ``>`` silently admitted one
    # extra predictive transition.
    age_exceeded = int(prediction_age) >= int(config.max_prediction_age)

    if not np.all(np.isfinite(Y)) or (
        np.linalg.eigvalsh(Y).size
        and float(np.min(np.linalg.eigvalsh(Y))) < -1.0e-12
    ):
        outcome = CLOSURE_INVALIDATE
        reason = "invalid_observed_probe_metric"
        frame: OuterSupportedFrame | None = None
    elif age_exceeded:
        outcome = CLOSURE_ANCHOR
        reason = "maximum_prediction_age_reached"
        frame = None
    elif (
        defect <= float(config.closure_pass_tolerance)
        and not bool(force_minimum_change_correction)
    ):
        outcome = CLOSURE_CONTINUE
        reason = (
            "spanning_probe_pass"
            if blind == 0
            else "partial_probe_pass_with_declared_blind_subspace"
        )
        frame = predicted
    elif (
        defect <= float(config.closure_correction_tolerance)
        and correction_norm <= float(config.closure_correction_tolerance)
        and min_relative > float(config.correction_min_eigenvalue)
    ):
        G_corrected = _sym(
            predicted.raw_analysis.T @ relative @ predicted.raw_analysis
        )
        O_corrected = np.asarray(
            predicted.raw_orthonormalizer @ _matrix_invsqrt_spd(relative),
            dtype=float,
        )
        try:
            frame = build_supported_frame(
                G_corrected,
                config=config,
                status=STATUS_CORRECTED,
                source_primitive_ids=tuple(
                    sorted(
                        set(predicted.source_primitive_ids)
                        | set(generic_primitive_ids)
                    )
                ),
                raw_orthonormalizer_override=O_corrected,
            )
        except (ValueError, FloatingPointError):
            outcome = CLOSURE_ANCHOR
            reason = "minimum_change_correction_changed_support"
            frame = None
        else:
            outcome = CLOSURE_CORRECT
            reason = (
                "spanning_minimum_change_correction"
                if blind == 0
                else "partial_minimum_change_correction_with_blind_subspace"
            )
    else:
        outcome = CLOSURE_ANCHOR
        reason = "closure_defect_requires_authoritative_anchor"
        frame = None
    return ClosureResult(
        outcome=outcome,
        reason=reason,
        frame=frame,
        defect=defect,
        probe_rank=probe_rank,
        blind_dimension=blind,
        correction=Delta,
        observed_probe_gram=Y,
        predicted_probe_gram=Yhat,
        source_primitive_ids=generic_primitive_ids,
        source_observation_ids=tuple(source_observation_ids),
        telemetry={
            "schema": OUTER_CLOSURE_SCHEMA,
            "outcome": outcome,
            "reason": reason,
            "dimensionless_closure_defect": defect,
            "probe_rank": probe_rank,
            "supported_rank": int(predicted.rank),
            "blind_dimension": blind,
            "observation_spans_support": bool(blind == 0),
            "correction_operator_norm": correction_norm,
            "minimum_relative_metric_eigenvalue": min_relative,
            "prediction_age": int(prediction_age),
            "full_endpoint_metric_acquired": False,
            "cross_state_tangent_data_acquired": False,
            "metric_closure_outcome": outcome,
            "orientation_closure_status": "unobserved_predicted_connection",
            "orientation_sensitive_observation_acquired": False,
            "transport_fully_certified": False,
            "classical_quantum_query_charge": 0,
            "force_minimum_change_correction": bool(
                force_minimum_change_correction
            ),
        },
    )


def measured_procrustes_orientation(
    cross_frame_overlap: np.ndarray,
    *,
    alignment_floor: float,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Register two measured frames; this is never a prediction law."""

    floor = float(alignment_floor)
    if not math.isfinite(floor) or floor < 0.0:
        raise ValueError("alignment_floor must be finite and nonnegative.")
    K = np.asarray(cross_frame_overlap, dtype=float)
    if K.ndim != 2 or not np.all(np.isfinite(K)):
        raise ValueError("cross_frame_overlap must be a finite matrix.")
    if K.shape[0] != K.shape[1]:
        raise ValueError(
            "the current outer curvature transport requires square common support; "
            "rectangular anchors must first apply the declared common-support rule."
        )
    U, singular_values, Vh = np.linalg.svd(K, full_matrices=False)
    Q = np.asarray(U @ Vh, dtype=float)
    sigma_min = (
        float(np.min(singular_values)) if singular_values.size else 1.0
    )
    orthogonality = float(
        np.linalg.norm(Q.T @ Q - np.eye(Q.shape[1]), ord="fro")
    )
    if sigma_min <= floor or orthogonality > 5.0e-8:
        raise ValueError("measured endpoint frame registration is ill-conditioned.")
    return Q, {
        "schema": "formal_manifold_measured_procrustes_anchor_v1",
        "singular_values": [float(value) for value in singular_values.tolist()],
        "sigma_min": sigma_min,
        "orthogonality_residual": orthogonality,
        "cross_state_quantum_information_required": True,
        "procrustes_algebra_quantum_query_charge": 0,
    }


def compare_predicted_to_exact_outer_geometry(
    predicted: OuterSupportedFrame,
    *,
    exact_raw_metric: np.ndarray,
    config: OuterInformationConfig,
    exact_raw_gradient: Sequence[float] | None = None,
    predicted_gradient_covector: Sequence[float] | None = None,
    predicted_transport: SplitConnectionTransport | np.ndarray | None = None,
    exact_cross_frame_overlap: np.ndarray | None = None,
    predicted_direct_curvature: np.ndarray | None = None,
    exact_direct_curvature_raw: np.ndarray | None = None,
    source_primitive_ids: Sequence[str] = (),
) -> dict[str, Any]:
    """Compare one predicted endpoint chart with an exact shadow anchor.

    This routine is diagnostic only.  It never mutates an outer-information
    session and never promotes the exact shadow geometry into the controller.
    Endpoint metrics test intrinsic chart prediction.  When the caller also
    supplies the measured cross-state tangent overlap, the routine separately
    tests orientation and the complete coefficient transport after registering
    the independently whitened endpoint gauges.

    ``exact_cross_frame_overlap`` must be the physical overlap from the source
    frame to the independently whitened exact endpoint frame.  An endpoint Gram
    matrix alone cannot supply this quantity.
    """

    exact_metric = _finite_square(exact_raw_metric, name="exact_raw_metric")
    if exact_metric.shape != predicted.raw_metric.shape:
        raise ValueError("exact shadow metric has an incompatible dimension.")
    exact = build_supported_frame(
        exact_metric,
        config=config,
        status=STATUS_ACQUIRED,
        source_primitive_ids=source_primitive_ids,
    )

    metric_delta = _sym(exact_metric - predicted.raw_metric)
    exact_metric_norm = float(np.linalg.norm(exact_metric, ord="fro"))
    metric_fro = float(np.linalg.norm(metric_delta, ord="fro"))
    metric_spectral = float(
        np.linalg.norm(metric_delta, ord=2) if metric_delta.size else 0.0
    )
    metric_relative = float(
        metric_fro / max(exact_metric_norm, np.finfo(float).tiny)
    )
    predicted_whitener_exact_residual = (
        float(
            np.linalg.norm(
                predicted.raw_orthonormalizer.T
                @ exact_metric
                @ predicted.raw_orthonormalizer
                - np.eye(predicted.rank, dtype=float),
                ord="fro",
            )
        )
        if predicted.rank
        else 0.0
    )
    support_defect = supported_subspace_projector_defect(predicted, exact)

    endpoint_registration: np.ndarray | None = None
    endpoint_registration_telemetry: dict[str, Any] | None = None
    if predicted.rank == exact.rank:
        endpoint_overlap = np.asarray(
            exact.raw_orthonormalizer.T
            @ exact_metric
            @ predicted.raw_orthonormalizer,
            dtype=float,
        )
        try:
            endpoint_registration, endpoint_registration_telemetry = (
                measured_procrustes_orientation(
                    endpoint_overlap,
                    alignment_floor=float(config.orientation_alignment_floor),
                )
            )
        except ValueError as exc:
            endpoint_registration_telemetry = {
                "schema": "formal_manifold_exact_shadow_endpoint_registration_v1",
                "available": False,
                "reason": str(exc),
            }

    orientation: dict[str, Any] = {
        "available": False,
        "reason": "exact_cross_state_tangent_overlap_not_supplied",
        "transport_fully_compared": False,
    }
    if exact_cross_frame_overlap is not None:
        if predicted_transport is None:
            raise ValueError(
                "exact cross-frame overlap requires the predicted transport."
            )
        predicted_transport_matrix = np.asarray(
            predicted_transport.coefficient_transport
            if isinstance(predicted_transport, SplitConnectionTransport)
            else predicted_transport,
            dtype=float,
        )
        if (
            predicted_transport_matrix.ndim != 2
            or not np.all(np.isfinite(predicted_transport_matrix))
        ):
            raise ValueError("predicted transport must be a finite matrix.")
        overlap = np.asarray(exact_cross_frame_overlap, dtype=float)
        if overlap.shape != (
            exact.rank,
            predicted_transport_matrix.shape[1],
        ):
            raise ValueError("exact cross-frame overlap has an incompatible shape.")
        if exact.rank != predicted.rank or endpoint_registration is None:
            orientation = {
                "available": False,
                "reason": "predicted_and_exact_endpoint_support_ranks_differ",
                "transport_fully_compared": False,
            }
        else:
            try:
                exact_registration, exact_registration_telemetry = (
                    measured_procrustes_orientation(
                        overlap,
                        alignment_floor=float(
                            config.orientation_alignment_floor
                        ),
                    )
                )
            except ValueError as exc:
                orientation = {
                    "available": False,
                    "reason": (
                        "exact_cross_state_registration_ill_conditioned:"
                        f"{exc}"
                    ),
                    "transport_fully_compared": False,
                }
            else:
                predicted_in_exact_gauge = np.asarray(
                    endpoint_registration
                    @ predicted_transport_matrix,
                    dtype=float,
                )
                transport_delta = np.asarray(
                    predicted_in_exact_gauge - exact_registration,
                    dtype=float,
                )
                orientation = {
                    "available": True,
                    "reason": "exact_cross_state_procrustes_compared",
                    "transport_fully_compared": True,
                    "exact_registration": exact_registration.tolist(),
                    "predicted_registration_in_exact_endpoint_gauge": (
                        predicted_in_exact_gauge.tolist()
                    ),
                    "transport_error_fro": float(
                        np.linalg.norm(transport_delta, ord="fro")
                    ),
                    "transport_error_spectral": float(
                        np.linalg.norm(transport_delta, ord=2)
                        if transport_delta.size
                        else 0.0
                    ),
                    "exact_registration_telemetry": (
                        exact_registration_telemetry
                    ),
                }

    gradient: dict[str, Any] = {
        "available": False,
        "reason": "exact_or_predicted_endpoint_gradient_not_supplied",
    }
    exact_gradient_frame: np.ndarray | None = None
    if exact_raw_gradient is not None:
        exact_gradient = _finite_vector(
            exact_raw_gradient, name="exact_raw_gradient"
        )
        if exact_gradient.size != exact.dimension:
            raise ValueError("exact shadow gradient has an incompatible dimension.")
        compatibility = _raw_metric_null_compatibility(
            exact,
            raw_gradient=exact_gradient,
            raw_curvature=None,
            tolerance=float(config.energy_model_null_tolerance),
            curvature_policy=str(config.null_curvature_policy),
            raise_on_failure=False,
        )
        exact_gradient_frame = np.asarray(
            exact.raw_orthonormalizer.T @ exact_gradient, dtype=float
        )
        gradient = {
            "available": False,
            "reason": "predicted_endpoint_gradient_not_supplied",
            "exact_raw_null_compatibility": compatibility,
            "exact_frame_gradient_norm": float(
                np.linalg.norm(exact_gradient_frame)
            ),
        }
        if predicted_gradient_covector is not None:
            predicted_gradient = _finite_vector(
                predicted_gradient_covector,
                name="predicted_gradient_covector",
            )
            if predicted_gradient.size != predicted.rank:
                raise ValueError(
                    "predicted gradient does not match predicted support rank."
                )
            if endpoint_registration is None or exact.rank != predicted.rank:
                gradient["reason"] = "endpoint_frame_registration_unavailable"
            else:
                predicted_gradient_exact_gauge = np.asarray(
                    endpoint_registration @ predicted_gradient,
                    dtype=float,
                )
                gradient_delta = np.asarray(
                    predicted_gradient_exact_gauge - exact_gradient_frame,
                    dtype=float,
                )
                denom = max(
                    float(np.linalg.norm(exact_gradient_frame)),
                    np.finfo(float).tiny,
                )
                cosine_denom = float(
                    np.linalg.norm(predicted_gradient_exact_gauge)
                    * np.linalg.norm(exact_gradient_frame)
                )
                gradient.update(
                    {
                        "available": True,
                        "reason": "predicted_and_exact_endpoint_gradients_compared",
                        "absolute_error": float(np.linalg.norm(gradient_delta)),
                        "relative_error": float(
                            np.linalg.norm(gradient_delta) / denom
                        ),
                        "cosine": (
                            None
                            if cosine_denom <= np.finfo(float).tiny
                            else float(
                                np.dot(
                                    predicted_gradient_exact_gauge,
                                    exact_gradient_frame,
                                )
                                / cosine_denom
                            )
                        ),
                    }
                )

    curvature: dict[str, Any] = {
        "available": False,
        "reason": "exact_or_predicted_direct_curvature_not_supplied",
    }
    if (
        predicted_direct_curvature is not None
        and exact_direct_curvature_raw is not None
    ):
        predicted_curvature = _finite_square(
            predicted_direct_curvature,
            name="predicted_direct_curvature",
        )
        exact_curvature_raw = _finite_square(
            exact_direct_curvature_raw,
            name="exact_direct_curvature_raw",
        )
        if predicted_curvature.shape != (predicted.rank, predicted.rank):
            raise ValueError(
                "predicted direct curvature does not match predicted support."
            )
        if exact_curvature_raw.shape != (exact.dimension, exact.dimension):
            raise ValueError("exact direct curvature has an incompatible dimension.")
        if endpoint_registration is None or exact.rank != predicted.rank:
            curvature["reason"] = "endpoint_frame_registration_unavailable"
        else:
            predicted_curvature_exact_gauge = _sym(
                endpoint_registration
                @ predicted_curvature
                @ endpoint_registration.T
            )
            exact_curvature_frame = _sym(
                exact.raw_orthonormalizer.T
                @ exact_curvature_raw
                @ exact.raw_orthonormalizer
            )
            curvature_delta = _sym(
                predicted_curvature_exact_gauge - exact_curvature_frame
            )
            exact_norm = float(np.linalg.norm(exact_curvature_frame, ord="fro"))
            curvature = {
                "available": True,
                "reason": "predicted_and_exact_direct_curvature_compared",
                "absolute_error_fro": float(
                    np.linalg.norm(curvature_delta, ord="fro")
                ),
                "relative_error_fro": float(
                    np.linalg.norm(curvature_delta, ord="fro")
                    / max(exact_norm, np.finfo(float).tiny)
                ),
                "operator_error": float(
                    np.linalg.norm(curvature_delta, ord=2)
                    if curvature_delta.size
                    else 0.0
                ),
            }

    return {
        "schema": "formal_manifold_exact_shadow_transport_diagnostic_v1",
        "diagnostic_only": True,
        "controller_state_mutated": False,
        "predicted_frame_id": str(predicted.frame_id),
        "exact_frame_id": str(exact.frame_id),
        "predicted_support_rank": int(predicted.rank),
        "exact_support_rank": int(exact.rank),
        "support_rank_match": bool(predicted.rank == exact.rank),
        "support_projector_defect": float(support_defect),
        "raw_metric_error_fro": metric_fro,
        "raw_metric_error_spectral": metric_spectral,
        "raw_metric_relative_error_fro": metric_relative,
        "predicted_whitener_exact_metric_identity_residual": (
            predicted_whitener_exact_residual
        ),
        "endpoint_frame_registration": endpoint_registration_telemetry,
        "orientation": orientation,
        "gradient": gradient,
        "curvature": curvature,
        "source_primitive_ids": sorted(
            {str(value) for value in source_primitive_ids}
        ),
        "exact_shadow_quantum_information": {
            "full_endpoint_metric_required": True,
            "cross_state_tangent_overlap_required_for_orientation": True,
            "exact_endpoint_gradient_required_for_gradient_test": bool(
                exact_raw_gradient is not None
            ),
            "exact_endpoint_curvature_required_for_curvature_test": bool(
                exact_direct_curvature_raw is not None
            ),
        },
    }


@dataclass(frozen=True)
class OuterInformationState:
    """Committed or speculative state for one complete outer ADAPT recursion."""

    state_id: str
    parent_state_id: str | None
    physical_state_fingerprint: str
    registry: tuple[str, ...]
    theta: np.ndarray
    frame: OuterSupportedFrame
    gradient_covector: np.ndarray
    curvature_kind: str
    curvature: np.ndarray
    normalized_strain_model: np.ndarray
    skew_connection_model: np.ndarray
    prediction_age: int
    geometry_status: str
    orientation_status: str
    orientation_prediction_age: int
    provenance: tuple[ProvenanceRecord, ...]
    closure_history: tuple[Mapping[str, Any], ...] = ()
    source_primitive_ids: tuple[str, ...] = ()
    source_observation_ids: tuple[str, ...] = ()
    transport_from_parent: np.ndarray | None = None
    transport_step_scale: float = 0.0
    secant_history: tuple[Mapping[str, Any], ...] = ()
    schema: str = OUTER_INFORMATION_SCHEMA

    def __post_init__(self) -> None:
        if str(self.schema) != OUTER_INFORMATION_SCHEMA:
            raise ValueError("outer-information state schema mismatch.")
        if not str(self.physical_state_fingerprint):
            raise ValueError("physical_state_fingerprint must be nonempty.")
        registry = tuple(str(value) for value in self.registry)
        if len(set(registry)) != len(registry) or any(not value for value in registry):
            raise ValueError("outer registry entries must be unique and nonempty.")
        theta = _finite_vector(self.theta, name="theta")
        if theta.size != len(registry) or theta.size != self.frame.dimension:
            raise ValueError("outer theta, registry, and frame dimensions disagree.")
        beta = _finite_vector(self.gradient_covector, name="gradient_covector")
        if beta.size != self.frame.rank:
            raise ValueError("gradient covector must live in the supported frame.")
        kind = str(self.curvature_kind)
        if kind not in CURVATURE_KINDS:
            raise ValueError("unknown curvature kind.")
        curvature = np.asarray(self.curvature, dtype=float)
        expected_curvature_shape = (
            (0, 0) if kind == CURVATURE_NONE else (self.frame.rank, self.frame.rank)
        )
        if curvature.shape != expected_curvature_shape or not np.all(
            np.isfinite(curvature)
        ):
            raise ValueError("curvature has an incompatible shape.")
        if kind != CURVATURE_NONE:
            curvature = _sym(curvature)
        strain = _finite_square(
            self.normalized_strain_model, name="normalized_strain_model"
        )
        omega = np.asarray(self.skew_connection_model, dtype=float)
        if strain.shape != (self.frame.rank, self.frame.rank):
            raise ValueError("strain model must act on supported coefficients.")
        if omega.shape != (self.frame.rank, self.frame.rank) or not np.all(
            np.isfinite(omega)
        ):
            raise ValueError("connection model must act on supported coefficients.")
        if np.linalg.norm(omega + omega.T, ord="fro") > 5.0e-10:
            raise ValueError("connection model must be skew-symmetric.")
        if int(self.prediction_age) < 0:
            raise ValueError("prediction_age must be nonnegative.")
        if str(self.geometry_status) not in PROVENANCE_STATUSES:
            raise ValueError("unknown geometry status.")
        if str(self.orientation_status) not in PROVENANCE_STATUSES:
            raise ValueError("unknown orientation status.")
        if int(self.orientation_prediction_age) < 0:
            raise ValueError("orientation_prediction_age must be nonnegative.")
        provenance = tuple(self.provenance)
        if any(not isinstance(value, ProvenanceRecord) for value in provenance):
            raise TypeError("outer provenance entries must be ProvenanceRecord values.")
        # History records can legitimately contain immutable provenance
        # certificates backed by ``MappingProxyType``.  ``deepcopy`` tries to
        # pickle those proxies and fails precisely when a failed prediction is
        # replaced by an exact anchor.  Detach through the module's portable
        # representation instead; it preserves the same JSON/state-id
        # semantics while recursively converting read-only mappings to owned
        # dictionaries before they are frozen again below.
        closure_history = tuple(
            _portable_payload(dict(value)) for value in self.closure_history
        )
        secant_history = tuple(
            _portable_payload(dict(value)) for value in self.secant_history
        )
        source_primitive_ids = tuple(
            sorted({str(value) for value in self.source_primitive_ids})
        )
        source_observation_ids = tuple(
            sorted({str(value) for value in self.source_observation_ids})
        )
        if any(not value for value in source_observation_ids):
            raise ValueError("source observation identifiers must be nonempty.")
        transport = self.transport_from_parent
        transport_step_scale = float(self.transport_step_scale)
        if not math.isfinite(transport_step_scale) or transport_step_scale < 0.0:
            raise ValueError("transport_step_scale must be finite and nonnegative.")
        if transport is not None:
            transport = np.asarray(transport, dtype=float)
            if (
                transport.shape != (self.frame.rank, self.frame.rank)
                or not np.all(np.isfinite(transport))
            ):
                raise ValueError("parent transport must act on common support.")
            if float(
                np.linalg.norm(
                    transport.T @ transport - np.eye(self.frame.rank),
                    ord="fro",
                )
            ) > 5.0e-8:
                raise ValueError("parent transport must be FS-orthogonal.")
        payload = {
            "parent_state_id": self.parent_state_id,
            "physical_state_fingerprint": str(self.physical_state_fingerprint),
            "registry": list(registry),
            "theta": [float(value) for value in theta.tolist()],
            "frame_id": str(self.frame.frame_id),
            "gradient_covector": _array_hash(beta),
            "curvature_kind": kind,
            "curvature": _array_hash(curvature),
            "normalized_strain_model": _array_hash(strain),
            "skew_connection_model": _array_hash(omega),
            "prediction_age": int(self.prediction_age),
            "geometry_status": str(self.geometry_status),
            "orientation_status": str(self.orientation_status),
            "orientation_prediction_age": int(self.orientation_prediction_age),
            "provenance_ids": [value.record_id for value in provenance],
            "closure_history": closure_history,
            "source_primitive_ids": list(source_primitive_ids),
            "source_observation_ids": list(source_observation_ids),
            "transport_from_parent": (
                None if transport is None else _array_hash(transport)
            ),
            "transport_step_scale": transport_step_scale,
            "secant_history": secant_history,
        }
        expected_state_id = _json_hash(payload)
        if self.state_id and str(self.state_id) != expected_state_id:
            raise ValueError("outer-information state fingerprint mismatch.")
        object.__setattr__(self, "state_id", expected_state_id)
        object.__setattr__(self, "registry", registry)
        object.__setattr__(self, "theta", _readonly(theta))
        object.__setattr__(self, "gradient_covector", _readonly(beta))
        object.__setattr__(self, "curvature_kind", kind)
        object.__setattr__(self, "curvature", _readonly(curvature))
        object.__setattr__(self, "normalized_strain_model", _readonly(strain))
        object.__setattr__(self, "skew_connection_model", _readonly(omega))
        object.__setattr__(
            self, "provenance", provenance
        )
        object.__setattr__(
            self,
            "closure_history",
            tuple(_immutable_payload(value) for value in closure_history),
        )
        object.__setattr__(
            self,
            "source_primitive_ids",
            source_primitive_ids,
        )
        object.__setattr__(
            self,
            "source_observation_ids",
            source_observation_ids,
        )
        object.__setattr__(
            self,
            "transport_from_parent",
            None if transport is None else _readonly(transport),
        )
        object.__setattr__(self, "transport_step_scale", transport_step_scale)
        object.__setattr__(
            self,
            "secant_history",
            tuple(_immutable_payload(value) for value in secant_history),
        )

    def portable_payload(self) -> dict[str, Any]:
        return {
            "schema": str(self.schema),
            "state_id": str(self.state_id),
            "parent_state_id": self.parent_state_id,
            "physical_state_fingerprint": str(self.physical_state_fingerprint),
            "registry": list(self.registry),
            "theta": self.theta.tolist(),
            "frame": self.frame.portable_payload(),
            "gradient_covector": self.gradient_covector.tolist(),
            "curvature_kind": str(self.curvature_kind),
            "curvature": self.curvature.tolist(),
            "normalized_strain_model": self.normalized_strain_model.tolist(),
            "skew_connection_model": self.skew_connection_model.tolist(),
            "prediction_age": int(self.prediction_age),
            "geometry_status": str(self.geometry_status),
            "orientation_status": str(self.orientation_status),
            "orientation_prediction_age": int(self.orientation_prediction_age),
            "provenance": [value.portable_payload() for value in self.provenance],
            "closure_history": _portable_payload(self.closure_history),
            "source_primitive_ids": list(self.source_primitive_ids),
            "source_observation_ids": list(self.source_observation_ids),
            "transport_from_parent": (
                None
                if self.transport_from_parent is None
                else self.transport_from_parent.tolist()
            ),
            "transport_step_scale": float(self.transport_step_scale),
            "secant_history": _portable_payload(self.secant_history),
        }

    @classmethod
    def from_portable_payload(
        cls, payload: Mapping[str, Any]
    ) -> "OuterInformationState":
        values = dict(payload)
        if not str(values.get("state_id", "")):
            raise ValueError("portable outer-information state must retain state_id.")
        values["frame"] = OuterSupportedFrame.from_portable_payload(values["frame"])
        frame_rank = int(values["frame"].rank)
        for field_name in (
            "normalized_strain_model",
            "skew_connection_model",
        ):
            array = np.asarray(values.get(field_name), dtype=float)
            if int(array.size) != frame_rank * frame_rank:
                raise ValueError(
                    f"portable outer state {field_name} has an invalid size."
                )
            values[field_name] = np.asarray(array, dtype=float).reshape(
                (frame_rank, frame_rank)
            )
        if values.get("transport_from_parent") is not None:
            transport = np.asarray(
                values["transport_from_parent"], dtype=float
            )
            if int(transport.size) != frame_rank * frame_rank:
                raise ValueError(
                    "portable outer state transport has an invalid size."
                )
            values["transport_from_parent"] = transport.reshape(
                (frame_rank, frame_rank)
            )
        values["provenance"] = tuple(
            ProvenanceRecord.from_portable_payload(value)
            for value in values.get("provenance", ())
        )
        if (
            str(values.get("curvature_kind")) == CURVATURE_NONE
            and np.asarray(values.get("curvature", [])).size == 0
        ) or (
            values["frame"].rank == 0
            and np.asarray(values.get("curvature", [])).size == 0
        ):
            values["curvature"] = np.zeros((0, 0), dtype=float)
        return cls(**values)


def summarize_outer_curvature_model(
    state: OuterInformationState | None,
    *,
    authoritative_sr_trajectory_affected: bool,
) -> dict[str, Any]:
    """Return compact role-separated outer-curvature telemetry.

    The accepted-ansatz refit for the SR-v3 outer-information profiles is
    Powell.  Any secant correction recorded here belongs to the separate
    outer-information predictor and must not be reported as an optimizer-local
    Powell, RBFGS, SR1, qBroyden, or qBANG update.
    """

    secants = (
        []
        if state is None
        else [dict(value) for value in state.secant_history]
    )
    applied = [
        value
        for value in secants
        if bool(value.get("curvature_update_applied", False))
    ]

    def _count(*, kind: str, applied_only: bool) -> int:
        return int(
            sum(
                1
                for value in secants
                if str(value.get("curvature_update_kind", "none")) == kind
                and (
                    not applied_only
                    or bool(value.get("curvature_update_applied", False))
                )
            )
        )

    latest_raw = None if not secants else secants[-1]
    latest = (
        None
        if latest_raw is None
        else {
            key: latest_raw.get(key)
            for key in (
                "source_frame_id",
                "target_frame_id",
                "endpoint_gradient_acquired",
                "curvature_update_applied",
                "curvature_update_kind",
                "reason",
            )
        }
    )
    curvature_kind = None if state is None else str(state.curvature_kind)
    curvature_model_present = bool(
        state is not None and curvature_kind != CURVATURE_NONE
    )
    recognized_kinds = {"direct_sr1", "inverse_bfgs", "none"}
    return {
        "schema": "formal_manifold_outer_curvature_model_summary_v1",
        "owner": "formal_manifold_outer_information_v1",
        "behavioral_role": (
            "active_reuse"
            if bool(authoritative_sr_trajectory_affected)
            else "shadow_diagnostic_only"
        ),
        "authoritative_sr_trajectory_affected": bool(
            authoritative_sr_trajectory_affected
        ),
        "accepted_refit_optimizer": "POWELL",
        "optimizer_local_curvature_recycling_active": False,
        "accepted_refit_optimizer_uses_outer_secant": False,
        "curvature_model_present": bool(curvature_model_present),
        "curvature_kind": curvature_kind,
        "outer_curvature_transport_applied": bool(
            curvature_model_present
            and state is not None
            and state.transport_from_parent is not None
        ),
        "outer_secant_correction_policy": (
            "guarded_direct_sr1_or_inverse_bfgs_endpoint_closure_v1"
        ),
        "outer_secant_observation_count": int(len(secants)),
        "outer_secant_update_applied_count": int(len(applied)),
        "outer_direct_sr1_secant_count": _count(
            kind="direct_sr1", applied_only=False
        ),
        "outer_direct_sr1_update_applied_count": _count(
            kind="direct_sr1", applied_only=True
        ),
        "outer_inverse_bfgs_secant_count": _count(
            kind="inverse_bfgs", applied_only=False
        ),
        "outer_inverse_bfgs_update_applied_count": _count(
            kind="inverse_bfgs", applied_only=True
        ),
        "outer_unrecognized_secant_kind_count": int(
            sum(
                1
                for value in secants
                if str(value.get("curvature_update_kind", "none"))
                not in recognized_kinds
            )
        ),
        "latest_outer_secant": latest,
    }


@dataclass(frozen=True)
class ActiveOuterGeometryPrior:
    """Read-only old--old geometry exposed to an active outer consumer.

    The arrays are raw logical-coordinate representatives at one declared
    endpoint.  ``raw_metric`` is the predicted/corrected FS metric itself.
    A direct-curvature representative is present only when the session owns a
    typed direct form; an inverse response is never silently inverted and
    relabeled as a Hessian.
    """

    state_id: str
    physical_state_fingerprint: str
    registry: tuple[str, ...]
    theta: np.ndarray
    raw_metric: np.ndarray
    raw_gradient: np.ndarray
    raw_direct_curvature: np.ndarray | None
    frame_id: str
    support_id: str
    supported_rank: int
    prediction_age: int
    geometry_status: str
    orientation_status: str
    source_primitive_ids: tuple[str, ...]
    source_observation_ids: tuple[str, ...]
    provenance_record_ids: tuple[str, ...]
    prior_id: str = ""
    schema: str = ACTIVE_OUTER_GEOMETRY_PRIOR_SCHEMA

    def __post_init__(self) -> None:
        if str(self.schema) != ACTIVE_OUTER_GEOMETRY_PRIOR_SCHEMA:
            raise ValueError("active outer-geometry prior schema mismatch.")
        registry = tuple(str(value) for value in self.registry)
        if len(set(registry)) != len(registry) or any(not value for value in registry):
            raise ValueError("active prior registry must be unique and nonempty.")
        theta = _finite_vector(self.theta, name="active prior theta")
        metric = _finite_square(self.raw_metric, name="active prior metric")
        gradient = _finite_vector(
            self.raw_gradient, name="active prior raw gradient"
        )
        dimension = len(registry)
        if (
            theta.size != dimension
            or metric.shape != (dimension, dimension)
            or gradient.size != dimension
        ):
            raise ValueError("active prior raw-coordinate dimensions disagree.")
        direct = self.raw_direct_curvature
        if direct is not None:
            direct = _finite_square(direct, name="active prior direct curvature")
            if direct.shape != (dimension, dimension):
                raise ValueError("active prior direct curvature dimension mismatch.")
        rank = int(self.supported_rank)
        if rank < 0 or rank > dimension:
            raise ValueError("active prior supported rank is invalid.")
        age = int(self.prediction_age)
        if age < 0:
            raise ValueError("active prior prediction age must be nonnegative.")
        if str(self.geometry_status) not in PROVENANCE_STATUSES:
            raise ValueError("active prior geometry status is unknown.")
        if str(self.orientation_status) not in PROVENANCE_STATUSES:
            raise ValueError("active prior orientation status is unknown.")
        primitive_ids = tuple(sorted({str(value) for value in self.source_primitive_ids}))
        observation_ids = tuple(
            sorted({str(value) for value in self.source_observation_ids})
        )
        provenance_ids = tuple(
            str(value) for value in self.provenance_record_ids
        )
        if any(not value for value in (*primitive_ids, *observation_ids, *provenance_ids)):
            raise ValueError("active prior provenance identifiers must be nonempty.")
        payload = {
            "schema": ACTIVE_OUTER_GEOMETRY_PRIOR_SCHEMA,
            "state_id": str(self.state_id),
            "physical_state_fingerprint": str(self.physical_state_fingerprint),
            "registry": list(registry),
            "theta": _array_hash(theta),
            "raw_metric": _array_hash(metric),
            "raw_gradient": _array_hash(gradient),
            "raw_direct_curvature": (
                None if direct is None else _array_hash(direct)
            ),
            "frame_id": str(self.frame_id),
            "support_id": str(self.support_id),
            "supported_rank": rank,
            "prediction_age": age,
            "geometry_status": str(self.geometry_status),
            "orientation_status": str(self.orientation_status),
            "source_primitive_ids": list(primitive_ids),
            "source_observation_ids": list(observation_ids),
            "provenance_record_ids": list(provenance_ids),
        }
        expected_id = _json_hash(payload)
        if self.prior_id and str(self.prior_id) != expected_id:
            raise ValueError("active outer-geometry prior fingerprint mismatch.")
        object.__setattr__(self, "registry", registry)
        object.__setattr__(self, "theta", _readonly(theta))
        object.__setattr__(self, "raw_metric", _readonly(metric))
        object.__setattr__(self, "raw_gradient", _readonly(gradient))
        object.__setattr__(
            self,
            "raw_direct_curvature",
            None if direct is None else _readonly(direct),
        )
        object.__setattr__(self, "supported_rank", rank)
        object.__setattr__(self, "prediction_age", age)
        object.__setattr__(self, "source_primitive_ids", primitive_ids)
        object.__setattr__(self, "source_observation_ids", observation_ids)
        object.__setattr__(self, "provenance_record_ids", provenance_ids)
        object.__setattr__(self, "prior_id", expected_id)

    def portable_payload(self) -> dict[str, Any]:
        return {
            "schema": str(self.schema),
            "prior_id": str(self.prior_id),
            "state_id": str(self.state_id),
            "physical_state_fingerprint": str(self.physical_state_fingerprint),
            "registry": list(self.registry),
            "theta": self.theta.tolist(),
            "raw_metric": self.raw_metric.tolist(),
            "raw_gradient": self.raw_gradient.tolist(),
            "raw_direct_curvature": (
                None
                if self.raw_direct_curvature is None
                else self.raw_direct_curvature.tolist()
            ),
            "frame_id": str(self.frame_id),
            "support_id": str(self.support_id),
            "supported_rank": int(self.supported_rank),
            "prediction_age": int(self.prediction_age),
            "geometry_status": str(self.geometry_status),
            "orientation_status": str(self.orientation_status),
            "source_primitive_ids": list(self.source_primitive_ids),
            "source_observation_ids": list(self.source_observation_ids),
            "provenance_record_ids": list(self.provenance_record_ids),
        }

    @classmethod
    def from_portable_payload(
        cls, payload: Mapping[str, Any]
    ) -> "ActiveOuterGeometryPrior":
        """Restore one tamper-evident active old--old geometry receipt."""

        values = dict(payload)
        if not str(values.get("prior_id", "")):
            raise ValueError(
                "portable active outer-geometry prior must retain prior_id."
            )
        for field_name in ("theta", "raw_metric", "raw_gradient"):
            values[field_name] = np.asarray(values.get(field_name), dtype=float)
        if values.get("raw_direct_curvature") is not None:
            values["raw_direct_curvature"] = np.asarray(
                values["raw_direct_curvature"], dtype=float
            )
        return cls(**values)


def active_outer_geometry_prior(
    state: OuterInformationState,
    *,
    expected_registry: Sequence[str] | None = None,
) -> ActiveOuterGeometryPrior:
    """Expose a typed prior without changing its frame or scientific status."""

    if not isinstance(state, OuterInformationState):
        raise TypeError("state must be an OuterInformationState.")
    if expected_registry is not None and tuple(
        str(value) for value in expected_registry
    ) != tuple(state.registry):
        raise ValueError("active prior registry differs from the requested chart.")
    raw_gradient = np.asarray(
        state.frame.raw_analysis.T @ state.gradient_covector, dtype=float
    )
    raw_direct: np.ndarray | None = None
    if state.curvature_kind == CURVATURE_DIRECT:
        raw_direct = _sym(
            state.frame.raw_analysis.T
            @ state.curvature
            @ state.frame.raw_analysis
        )
    return ActiveOuterGeometryPrior(
        state_id=str(state.state_id),
        physical_state_fingerprint=str(state.physical_state_fingerprint),
        registry=tuple(state.registry),
        theta=np.asarray(state.theta, dtype=float),
        raw_metric=np.asarray(state.frame.raw_metric, dtype=float),
        raw_gradient=raw_gradient,
        raw_direct_curvature=raw_direct,
        frame_id=str(state.frame.frame_id),
        support_id=str(state.frame.support_id),
        supported_rank=int(state.frame.rank),
        prediction_age=int(state.prediction_age),
        geometry_status=str(state.geometry_status),
        orientation_status=str(state.orientation_status),
        source_primitive_ids=tuple(state.source_primitive_ids),
        source_observation_ids=tuple(state.source_observation_ids),
        provenance_record_ids=tuple(
            record.record_id for record in state.provenance
        ),
    )


def initialize_outer_information_state(
    *,
    physical_state_fingerprint: str,
    registry: Sequence[str],
    theta: Sequence[float],
    raw_metric: np.ndarray,
    raw_gradient: Sequence[float],
    config: OuterInformationConfig,
    source_primitive_ids: Sequence[str],
    source_observation_ids: Sequence[str] = (),
    direct_curvature_raw: np.ndarray | None = None,
    inverse_curvature_frame: np.ndarray | None = None,
    authoritative_null_gradient_policy: str = NULL_GRADIENT_REJECT,
) -> OuterInformationState:
    """Create an authoritative anchor from acquired endpoint information."""

    if direct_curvature_raw is not None and inverse_curvature_frame is not None:
        raise ValueError("supply direct or inverse curvature, not both.")
    frame = build_supported_frame(
        raw_metric,
        config=config,
        status=STATUS_ACQUIRED,
        source_primitive_ids=source_primitive_ids,
    )
    raw_b = _finite_vector(raw_gradient, name="raw_gradient")
    if raw_b.size != frame.dimension:
        raise ValueError("raw gradient does not match anchor coordinates.")
    direct_model: np.ndarray | None = None
    if direct_curvature_raw is not None:
        direct_model = _finite_square(
            direct_curvature_raw, name="direct_curvature_raw"
        )
        if direct_model.shape != (frame.dimension, frame.dimension):
            raise ValueError("direct raw curvature dimension mismatch.")
    null_certificate = _raw_metric_null_compatibility(
        frame,
        raw_gradient=raw_b,
        raw_curvature=direct_model,
        tolerance=float(config.energy_model_null_tolerance),
        gradient_policy=str(authoritative_null_gradient_policy),
        curvature_policy=str(config.null_curvature_policy),
    )
    beta = np.asarray(frame.raw_orthonormalizer.T @ raw_b, dtype=float)
    if direct_model is not None:
        if str(config.null_curvature_policy) == (
            "project_to_supported_quotient_v1"
        ):
            retained_projector = _sym(
                frame.retained_vectors @ frame.retained_vectors.T
            )
            direct_model_supported = _sym(
                retained_projector @ direct_model @ retained_projector
            )
        else:
            direct_model_supported = direct_model
        curvature_kind = CURVATURE_DIRECT
        curvature = _sym(
            frame.raw_orthonormalizer.T
            @ direct_model_supported
            @ frame.raw_orthonormalizer
        )
    elif inverse_curvature_frame is not None:
        curvature_kind = CURVATURE_INVERSE
        curvature = _finite_square(
            inverse_curvature_frame, name="inverse_curvature_frame"
        )
        if curvature.shape != (frame.rank, frame.rank):
            raise ValueError("inverse frame curvature dimension mismatch.")
    else:
        curvature_kind = CURVATURE_NONE
        curvature = np.zeros((0, 0), dtype=float)
    chart_id = _json_hash(list(str(value) for value in registry))
    metric_record = ProvenanceRecord(
        quantity="outer_supported_metric_frame",
        status=STATUS_ACQUIRED,
        base_state_id=str(physical_state_fingerprint),
        chart_id=chart_id,
        support_id=frame.support_id,
        primitive_ids=tuple(source_primitive_ids),
        observation_ids=tuple(source_observation_ids),
        certificate={
            "provenance_role": PROVENANCE_ROLE_METRIC,
            "observation_role": (
                "cached_authoritative_geometry"
                if tuple(source_observation_ids)
                else None
            ),
            "whitening_provenance_id": str(frame.whitening_provenance_id),
            "rank": int(frame.rank),
            "raw_metric_null_compatibility": null_certificate,
        },
    )
    provenance_list: list[ProvenanceRecord] = [metric_record]
    if curvature_kind != CURVATURE_NONE:
        provenance_list.append(
            ProvenanceRecord(
                quantity=(
                    "outer_direct_curvature"
                    if curvature_kind == CURVATURE_DIRECT
                    else "outer_inverse_curvature"
                ),
                status=STATUS_ACQUIRED,
                base_state_id=str(physical_state_fingerprint),
                chart_id=chart_id,
                support_id=frame.support_id,
                primitive_ids=tuple(source_primitive_ids),
                observation_ids=tuple(source_observation_ids),
                certificate={
                    "provenance_role": PROVENANCE_ROLE_CURVATURE,
                    "curvature_kind": curvature_kind,
                    "representation": (
                        "raw_curvature_projected_to_supported_quotient"
                        if curvature_kind == CURVATURE_DIRECT
                        and str(config.null_curvature_policy)
                        == "project_to_supported_quotient_v1"
                        else "raw_direct_projected_to_supported_frame"
                        if curvature_kind == CURVATURE_DIRECT
                        else "supplied_supported_frame_inverse"
                    ),
                    "raw_metric_null_compatibility": null_certificate,
                },
            )
        )
    provenance = tuple(provenance_list)
    return OuterInformationState(
        state_id="",
        parent_state_id=None,
        physical_state_fingerprint=str(physical_state_fingerprint),
        registry=tuple(str(value) for value in registry),
        theta=np.asarray(theta, dtype=float),
        frame=frame,
        gradient_covector=beta,
        curvature_kind=curvature_kind,
        curvature=curvature,
        normalized_strain_model=np.zeros((frame.rank, frame.rank), dtype=float),
        skew_connection_model=np.zeros((frame.rank, frame.rank), dtype=float),
        prediction_age=0,
        geometry_status=STATUS_ACQUIRED,
        orientation_status=STATUS_ACQUIRED,
        orientation_prediction_age=0,
        provenance=provenance,
        source_primitive_ids=tuple(source_primitive_ids),
        source_observation_ids=tuple(source_observation_ids),
    )


class OuterInformationSession:
    """Transactional owner of committed and speculative outer geometry.

    Structural admission is never rolled back by this object.  If a predicted
    endpoint fails closure, the caller either supplies an exact endpoint anchor
    with the already accepted registry or leaves the prediction uncommitted.
    The last committed state and immutable primitive IDs remain untouched.
    """

    def __init__(
        self,
        *,
        config: OuterInformationConfig | None = None,
        committed: OuterInformationState | None = None,
    ) -> None:
        self.config = config or OuterInformationConfig()
        self._committed = committed
        self._pending: OuterInformationState | None = None
        self._pending_source: OuterInformationState | None = None
        self._failed_closure: ClosureResult | None = None
        self._stage = TRANSACTION_IDLE
        self._immutable_primitive_ids: set[str] = set(
            () if committed is None else committed.source_primitive_ids
        )
        self._immutable_observation_ids: set[str] = set(
            () if committed is None else committed.source_observation_ids
        )
        self._invalidations: list[dict[str, Any]] = []

    @property
    def committed(self) -> OuterInformationState | None:
        return self._committed

    @property
    def pending(self) -> OuterInformationState | None:
        return self._pending

    @property
    def pending_source(self) -> OuterInformationState | None:
        return self._pending_source

    @property
    def stage(self) -> str:
        return str(self._stage)

    @property
    def failed_closure(self) -> ClosureResult | None:
        return self._failed_closure

    @property
    def immutable_observation_ids(self) -> tuple[str, ...]:
        return tuple(sorted(self._immutable_observation_ids))

    @property
    def immutable_primitive_ids(self) -> tuple[str, ...]:
        return tuple(sorted(self._immutable_primitive_ids))

    @property
    def invalidations(self) -> tuple[Mapping[str, Any], ...]:
        return tuple(deepcopy(value) for value in self._invalidations)

    def initialize(self, state: OuterInformationState) -> None:
        if self._committed is not None or self._pending is not None:
            raise RuntimeError("outer-information session is already initialized.")
        self._committed = state
        self._failed_closure = None
        self._immutable_primitive_ids.update(state.source_primitive_ids)
        self._immutable_observation_ids.update(state.source_observation_ids)

    def replace_committed_endpoint_with_anchor(
        self,
        *,
        physical_state_fingerprint: str,
        registry: Sequence[str],
        theta: Sequence[float],
        raw_metric: np.ndarray,
        raw_gradient: Sequence[float],
        source_primitive_ids: Sequence[str],
        source_observation_ids: Sequence[str] = (),
        direct_curvature_raw: np.ndarray | None = None,
        inverse_curvature_frame: np.ndarray | None = None,
        authoritative_null_gradient_policy: str = NULL_GRADIENT_REJECT,
        reason: str = "candidate_probe_requires_authoritative_reanchor",
    ) -> OuterInformationState:
        """Replace an idle same-ray hypothesis with acquired endpoint geometry.

        This operation is distinct from prediction closure and from structural
        invalidation.  The accepted registry, parameters, and physical ray are
        unchanged; only the propagated metric/frame/curvature hypothesis is
        replaced.  Without measured cross-state tangent overlaps no recycled
        curvature or secant history is claimed across this reanchor.
        """

        if (
            self._committed is None
            or self._pending is not None
            or self._pending_source is not None
            or self._stage != TRANSACTION_IDLE
        ):
            raise RuntimeError(
                "same-ray committed reanchor requires one idle committed state."
            )
        reason_value = str(reason).strip()
        if not reason_value:
            raise ValueError("same-ray committed reanchor requires a reason.")
        old = self._committed
        registry_tuple = tuple(str(value) for value in registry)
        theta_array = _finite_vector(theta, name="reanchor theta")
        if registry_tuple != tuple(old.registry):
            raise ValueError(
                "same-ray committed reanchor must preserve the registry."
            )
        if theta_array.shape != old.theta.shape or not np.allclose(
            theta_array, old.theta, rtol=0.0, atol=2.0e-10
        ):
            raise ValueError(
                "same-ray committed reanchor must preserve the endpoint theta."
            )
        physical_fingerprint_matches = bool(
            str(physical_state_fingerprint)
            == str(old.physical_state_fingerprint)
        )
        predicted_fingerprint_replaced = bool(
            not physical_fingerprint_matches
            and str(old.physical_state_fingerprint).startswith(
                "predicted_ray:"
            )
        )
        if not (
            physical_fingerprint_matches or predicted_fingerprint_replaced
        ):
            raise ValueError(
                "same-ray committed reanchor must preserve the physical ray."
            )
        fresh = initialize_outer_information_state(
            physical_state_fingerprint=str(physical_state_fingerprint),
            registry=registry_tuple,
            theta=theta_array,
            raw_metric=raw_metric,
            raw_gradient=raw_gradient,
            config=self.config,
            source_primitive_ids=source_primitive_ids,
            source_observation_ids=source_observation_ids,
            direct_curvature_raw=direct_curvature_raw,
            inverse_curvature_frame=inverse_curvature_frame,
            authoritative_null_gradient_policy=(
                authoritative_null_gradient_policy
            ),
        )
        primitive_ids = tuple(
            sorted(
                set(old.source_primitive_ids)
                | {str(value) for value in source_primitive_ids}
            )
        )
        observation_ids = tuple(
            sorted(
                set(old.source_observation_ids)
                | {str(value) for value in source_observation_ids}
            )
        )
        anchor = OuterInformationState(
            state_id="",
            parent_state_id=str(old.state_id),
            physical_state_fingerprint=str(fresh.physical_state_fingerprint),
            registry=fresh.registry,
            theta=fresh.theta,
            frame=fresh.frame,
            gradient_covector=fresh.gradient_covector,
            curvature_kind=fresh.curvature_kind,
            curvature=fresh.curvature,
            normalized_strain_model=fresh.normalized_strain_model,
            skew_connection_model=fresh.skew_connection_model,
            prediction_age=0,
            geometry_status=STATUS_ACQUIRED,
            orientation_status=STATUS_ACQUIRED,
            orientation_prediction_age=0,
            provenance=(*old.provenance, *fresh.provenance),
            closure_history=(
                *old.closure_history,
                {
                    "schema": "formal_manifold_same_ray_authoritative_reanchor_v1",
                    "reason": reason_value,
                    "accepted_registry_preserved": True,
                    "physical_ray_preserved": True,
                    "predicted_physical_fingerprint_replaced": bool(
                        predicted_fingerprint_replaced
                    ),
                    "transported_curvature_discarded": True,
                    "transported_secants_discarded": True,
                    "gradient_projected": False,
                    "structural_rollback_performed": False,
                },
            ),
            source_primitive_ids=primitive_ids,
            source_observation_ids=observation_ids,
            transport_from_parent=None,
            transport_step_scale=0.0,
            secant_history=(),
        )
        self._committed = anchor
        self._failed_closure = None
        self._immutable_primitive_ids.update(primitive_ids)
        self._immutable_observation_ids.update(observation_ids)
        return anchor

    def invalidate_geometry_hypothesis(
        self,
        *,
        reason: str,
        accepted_registry: Sequence[str] = (),
        source_primitive_ids: Sequence[str] = (),
        source_observation_ids: Sequence[str] = (),
    ) -> None:
        """Discard only uncertified FM geometry while preserving the ansatz.

        The authoritative selector/refit transition is not rolled back.  A
        later outer round may establish a fresh acquired anchor for the same
        accepted structural registry.
        """

        reason_value = str(reason).strip()
        if not reason_value:
            raise ValueError("geometry invalidation requires a reason.")
        primitive_ids = tuple(
            sorted({str(value) for value in source_primitive_ids})
        )
        observation_ids = tuple(
            sorted({str(value) for value in source_observation_ids})
        )
        self._immutable_primitive_ids.update(primitive_ids)
        self._immutable_observation_ids.update(observation_ids)
        self._invalidations.append(
            {
                "schema": "formal_manifold_outer_geometry_invalidation_v1",
                "reason": reason_value,
                "accepted_registry": [
                    str(value) for value in accepted_registry
                ],
                "source_primitive_ids": list(primitive_ids),
                "source_observation_ids": list(observation_ids),
                "structural_rollback_performed": False,
                "accepted_structure_preserved": True,
                "discarded_information_only": True,
                "previous_committed_state_id": (
                    None
                    if self._committed is None
                    else str(self._committed.state_id)
                ),
                "previous_pending_state_id": (
                    None
                    if self._pending is None
                    else str(self._pending.state_id)
                ),
            }
        )
        self._committed = None
        self._pending = None
        self._pending_source = None
        self._failed_closure = None
        self._stage = TRANSACTION_IDLE

    def begin_same_ray_growth(
        self,
        *,
        registry: Sequence[str],
        theta: Sequence[float],
        active_candidate_gram: np.ndarray,
        candidate_candidate_gram: np.ndarray,
        candidate_gradient: Sequence[float],
        old_to_new_registry_mapping: Sequence[int],
        candidate_positions: Sequence[int],
        source_primitive_ids: Sequence[str],
        cache_observation_provenance_ids: Sequence[str] = (),
        cache_observation_provenance_role: str = (
            "query_free_cached_geometry_observation"
        ),
        direct_curvature_raw: np.ndarray | None = None,
        direct_curvature_active_candidate: np.ndarray | None = None,
        direct_curvature_candidate_candidate: np.ndarray | None = None,
        new_inverse_prior: float = 1.0,
    ) -> SameRayExtension:
        if self._committed is None:
            raise RuntimeError("outer-information session has no committed anchor.")
        if self._pending is not None:
            raise RuntimeError("outer-information session already has a proposal.")
        old = self._committed
        cache_observation_ids = tuple(
            sorted(
                {
                    str(value)
                    for value in cache_observation_provenance_ids
                }
            )
        )
        if any(not value for value in cache_observation_ids):
            raise ValueError(
                "cache observation provenance identifiers must be nonempty."
            )
        cache_observation_role = str(
            cache_observation_provenance_role
        ).strip()
        if cache_observation_ids and not cache_observation_role:
            raise ValueError(
                "cache observation provenance role must be nonempty."
            )
        extension = extend_same_ray_frame(
            old.frame,
            active_candidate_gram=active_candidate_gram,
            candidate_candidate_gram=candidate_candidate_gram,
            old_to_new_registry_mapping=old_to_new_registry_mapping,
            candidate_positions=candidate_positions,
            config=self.config,
            source_primitive_ids=source_primitive_ids,
        )
        registry_tuple = tuple(str(value) for value in registry)
        theta_array = _finite_vector(theta, name="growth theta")
        if len(registry_tuple) != extension.frame.dimension or theta_array.size != len(
            registry_tuple
        ):
            raise ValueError("growth registry/theta dimension mismatch.")
        old_mapping = extension.old_to_new_registry_mapping
        new_positions = extension.candidate_positions
        if not np.allclose(
            theta_array[list(old_mapping)], old.theta, rtol=0.0, atol=1.0e-12
        ) or not np.allclose(
            theta_array[list(new_positions)], 0.0, rtol=0.0, atol=1.0e-12
        ):
            raise ValueError("same-ray growth must embed old theta and zero new coordinates.")
        raw_b_old = np.asarray(old.frame.raw_analysis.T @ old.gradient_covector, dtype=float)
        raw_b = np.zeros(extension.frame.dimension, dtype=float)
        raw_b[list(old_mapping)] = raw_b_old
        candidate_b = _finite_vector(candidate_gradient, name="candidate_gradient")
        if candidate_b.size != len(new_positions):
            raise ValueError("candidate gradient dimension mismatch.")
        raw_b[list(new_positions)] = candidate_b
        curvature_blocks_supplied = bool(
            direct_curvature_active_candidate is not None
            or direct_curvature_candidate_candidate is not None
        )
        if direct_curvature_raw is not None and curvature_blocks_supplied:
            raise ValueError(
                "supply a full growth curvature or candidate cross/new blocks, "
                "not both."
            )
        if curvature_blocks_supplied and (
            direct_curvature_active_candidate is None
            or direct_curvature_candidate_candidate is None
        ):
            raise ValueError(
                "active-candidate and candidate-candidate curvature blocks "
                "must be supplied together."
            )
        if curvature_blocks_supplied:
            candidate_primitive_ids = tuple(
                sorted({str(value).strip() for value in source_primitive_ids})
            )
            if not candidate_primitive_ids or any(
                not value for value in candidate_primitive_ids
            ):
                raise ValueError(
                    "active candidate curvature blocks require immutable source "
                    "primitive identifiers."
                )
            if not cache_observation_ids:
                raise ValueError(
                    "active candidate curvature blocks require cache-observation "
                    "provenance."
                )
        direct_model: np.ndarray | None = None
        curvature_extension_rule: str | None = None
        if direct_curvature_raw is not None:
            direct_model = _finite_square(
                direct_curvature_raw, name="direct_curvature_raw"
            )
            if direct_model.shape != (
                extension.frame.dimension,
                extension.frame.dimension,
            ):
                raise ValueError("growth direct curvature dimension mismatch.")
            curvature_extension_rule = "acquired_full_raw_direct_curvature"
        elif curvature_blocks_supplied:
            if old.curvature_kind != CURVATURE_DIRECT:
                raise ValueError(
                    "candidate curvature blocks require an inherited direct "
                    "curvature form."
                )
            cross = np.asarray(
                direct_curvature_active_candidate, dtype=float
            )
            candidate_count = len(new_positions)
            if cross.shape != (old.frame.dimension, candidate_count) or not np.all(
                np.isfinite(cross)
            ):
                raise ValueError(
                    "direct_curvature_active_candidate has an incompatible shape."
                )
            new_block = _finite_square(
                direct_curvature_candidate_candidate,
                name="direct_curvature_candidate_candidate",
            )
            if new_block.shape != (candidate_count, candidate_count):
                raise ValueError(
                    "direct_curvature_candidate_candidate dimension mismatch."
                )
            old_raw_direct = _sym(
                old.frame.raw_analysis.T
                @ old.curvature
                @ old.frame.raw_analysis
            )
            direct_model = np.zeros(
                (extension.frame.dimension, extension.frame.dimension),
                dtype=float,
            )
            direct_model[np.ix_(old_mapping, old_mapping)] = old_raw_direct
            direct_model[np.ix_(old_mapping, new_positions)] = cross
            direct_model[np.ix_(new_positions, old_mapping)] = cross.T
            direct_model[np.ix_(new_positions, new_positions)] = new_block
            direct_model = _sym(direct_model)
            curvature_extension_rule = (
                "inherited_predicted_old_block_acquired_candidate_cross_new"
            )
        growth_gradient_policy = NULL_GRADIENT_REJECT
        if str(old.frame.status) == STATUS_ACQUIRED:
            acquired_metric_record = next(
                (
                    record
                    for record in reversed(old.provenance)
                    if str(record.certificate.get("provenance_role", ""))
                    == PROVENANCE_ROLE_METRIC
                ),
                None,
            )
            if acquired_metric_record is not None:
                acquired_null_certificate = dict(
                    acquired_metric_record.certificate.get(
                        "raw_metric_null_compatibility", {}
                    )
                )
                if str(
                    acquired_null_certificate.get("gradient_policy", "")
                ) == NULL_GRADIENT_PROJECT:
                    growth_gradient_policy = NULL_GRADIENT_PROJECT
        null_certificate = _raw_metric_null_compatibility(
            extension.frame,
            raw_gradient=raw_b,
            raw_curvature=direct_model,
            tolerance=float(self.config.energy_model_null_tolerance),
            gradient_policy=growth_gradient_policy,
            curvature_policy=str(self.config.null_curvature_policy),
        )
        beta = np.asarray(extension.frame.raw_orthonormalizer.T @ raw_b, dtype=float)
        if direct_model is not None:
            if str(self.config.null_curvature_policy) == (
                "project_to_supported_quotient_v1"
            ):
                retained_projector = _sym(
                    extension.frame.retained_vectors
                    @ extension.frame.retained_vectors.T
                )
                direct_model_supported = _sym(
                    retained_projector @ direct_model @ retained_projector
                )
            else:
                direct_model_supported = direct_model
            curvature_kind = CURVATURE_DIRECT
            curvature = _sym(
                extension.frame.raw_orthonormalizer.T
                @ direct_model_supported
                @ extension.frame.raw_orthonormalizer
            )
        elif old.curvature_kind == CURVATURE_DIRECT:
            curvature_kind = CURVATURE_DIRECT
            curvature = np.zeros((extension.frame.rank, extension.frame.rank))
            curvature[: old.frame.rank, : old.frame.rank] = old.curvature
        elif old.curvature_kind == CURVATURE_INVERSE:
            if not math.isfinite(float(new_inverse_prior)) or float(new_inverse_prior) <= 0.0:
                raise ValueError("new_inverse_prior must be finite and positive.")
            curvature_kind = CURVATURE_INVERSE
            curvature = float(new_inverse_prior) * np.eye(extension.frame.rank)
            curvature[: old.frame.rank, : old.frame.rank] = old.curvature
        else:
            curvature_kind = CURVATURE_NONE
            curvature = np.zeros((0, 0))
        chart_id = _json_hash(list(registry_tuple))
        metric_record = ProvenanceRecord(
            quantity="same_ray_extended_metric_frame",
            status=STATUS_INHERITED,
            base_state_id=str(old.physical_state_fingerprint),
            chart_id=chart_id,
            support_id=extension.frame.support_id,
            parent_ids=_parent_tuple(
                _latest_provenance_id(
                    old.provenance, role=PROVENANCE_ROLE_METRIC
                )
            ),
            primitive_ids=tuple(source_primitive_ids),
            observation_ids=cache_observation_ids,
            certificate={
                **dict(extension.telemetry),
                "provenance_role": PROVENANCE_ROLE_METRIC,
                "cache_observation_provenance_role": (
                    cache_observation_role
                    if cache_observation_ids
                    else None
                ),
                "raw_metric_null_compatibility": null_certificate,
            },
        )
        provenance_list: list[ProvenanceRecord] = [
            *old.provenance,
            metric_record,
        ]
        if curvature_kind != CURVATURE_NONE:
            acquired_full_curvature = bool(
                direct_curvature_raw is not None
            )
            acquired_candidate_blocks = bool(curvature_blocks_supplied)
            old_curvature_status = _latest_provenance_status(
                old.provenance,
                role=PROVENANCE_ROLE_CURVATURE,
            )
            provenance_list.append(
                ProvenanceRecord(
                    quantity=(
                        "same_ray_acquired_direct_curvature"
                        if acquired_full_curvature
                        else "same_ray_mixed_provenance_direct_curvature"
                        if acquired_candidate_blocks
                        else "same_ray_inherited_curvature"
                    ),
                    status=(
                        STATUS_ACQUIRED
                        if acquired_full_curvature
                        else STATUS_PREDICTED
                        if acquired_candidate_blocks
                        and old_curvature_status == STATUS_PREDICTED
                        else STATUS_CORRECTED
                        if acquired_candidate_blocks
                        and old_curvature_status == STATUS_CORRECTED
                        else STATUS_INHERITED
                    ),
                    base_state_id=str(old.physical_state_fingerprint),
                    chart_id=chart_id,
                    support_id=extension.frame.support_id,
                    parent_ids=_parent_tuple(
                        _latest_provenance_id(
                            old.provenance,
                            role=PROVENANCE_ROLE_CURVATURE,
                        )
                    ),
                    primitive_ids=(
                        tuple(source_primitive_ids)
                        if acquired_full_curvature or acquired_candidate_blocks
                        else ()
                    ),
                    observation_ids=(
                        cache_observation_ids
                        if acquired_full_curvature or acquired_candidate_blocks
                        else ()
                    ),
                    certificate={
                        "provenance_role": PROVENANCE_ROLE_CURVATURE,
                        "curvature_kind": curvature_kind,
                        "representation": (
                            "raw_curvature_projected_to_supported_quotient"
                            if curvature_kind == CURVATURE_DIRECT
                            and str(self.config.null_curvature_policy)
                            == "project_to_supported_quotient_v1"
                            else "supported_frame_curvature"
                        ),
                        "extension_rule": (
                            curvature_extension_rule
                            if curvature_extension_rule is not None
                            else "inherited_old_block_zero_new_prior"
                            if curvature_kind == CURVATURE_DIRECT
                            else "inherited_old_block_isotropic_new_inverse_prior"
                        ),
                        "old_old_curvature_status": (
                            old_curvature_status
                            if acquired_candidate_blocks
                            else None
                        ),
                        "old_old_curvature_reacquired": bool(
                            acquired_full_curvature
                        ),
                        "candidate_cross_new_curvature_acquired": bool(
                            acquired_candidate_blocks
                        ),
                        "new_inverse_prior": (
                            float(new_inverse_prior)
                            if curvature_kind == CURVATURE_INVERSE
                            and not acquired_full_curvature
                            and not acquired_candidate_blocks
                            else None
                        ),
                        "raw_metric_null_compatibility": null_certificate,
                    },
                )
            )
        provenance = tuple(provenance_list)
        extended_strain = np.zeros(
            (extension.frame.rank, extension.frame.rank), dtype=float
        )
        extended_connection = np.zeros_like(extended_strain)
        if old.frame.rank:
            extended_strain[: old.frame.rank, : old.frame.rank] = (
                old.normalized_strain_model
            )
            extended_connection[: old.frame.rank, : old.frame.rank] = (
                old.skew_connection_model
            )
        pending = OuterInformationState(
            state_id="",
            parent_state_id=str(old.state_id),
            physical_state_fingerprint=str(old.physical_state_fingerprint),
            registry=registry_tuple,
            theta=theta_array,
            frame=extension.frame,
            gradient_covector=beta,
            curvature_kind=curvature_kind,
            curvature=curvature,
            normalized_strain_model=extended_strain,
            skew_connection_model=extended_connection,
            prediction_age=int(old.prediction_age),
            geometry_status=STATUS_INHERITED,
            orientation_status=STATUS_INHERITED,
            orientation_prediction_age=int(old.orientation_prediction_age),
            provenance=provenance,
            closure_history=old.closure_history,
            source_primitive_ids=tuple(
                sorted(set(old.source_primitive_ids) | set(source_primitive_ids))
            ),
            source_observation_ids=tuple(
                sorted(
                    set(old.source_observation_ids)
                    | set(cache_observation_ids)
                )
            ),
            secant_history=old.secant_history,
        )
        self._pending = pending
        self._pending_source = pending
        self._failed_closure = None
        self._stage = TRANSACTION_GROWTH
        self._immutable_primitive_ids.update(str(value) for value in source_primitive_ids)
        self._immutable_observation_ids.update(cache_observation_ids)
        return extension

    def predict_refit(
        self,
        *,
        physical_state_fingerprint: str,
        theta: Sequence[float],
        normalized_strain: np.ndarray | None = None,
        skew_connection: np.ndarray | None = None,
        step_scale: float = 1.0,
    ) -> SplitConnectionTransport:
        if self._pending is None or self._stage != TRANSACTION_GROWTH:
            raise RuntimeError("refit prediction requires a pending same-ray growth state.")
        source = self._pending
        metric_prediction = predict_endpoint_metric(
            source.frame,
            normalized_strain=(
                source.normalized_strain_model
                if normalized_strain is None
                else normalized_strain
            ),
            step_scale=float(step_scale),
            config=self.config,
        )
        omega = (
            source.skew_connection_model
            if skew_connection is None
            else np.asarray(skew_connection, dtype=float)
        )
        transport = build_split_connection_transport(
            source.frame,
            metric_prediction.frame,
            config=self.config,
            skew_connection=omega,
            step_scale=float(step_scale),
            orientation_provenance=(
                "minimal_rotation_zero_connection_prior_v1"
                if not np.any(np.asarray(omega, dtype=float))
                else "predicted_skew_connection_v1"
            ),
        )
        theta_array = _finite_vector(theta, name="endpoint theta")
        if theta_array.size != source.frame.dimension:
            raise ValueError("endpoint theta dimension mismatch.")
        transported_beta = transport_covector(
            transport, source.gradient_covector
        )
        if source.curvature_kind == CURVATURE_DIRECT:
            curvature = transport_direct_curvature(transport, source.curvature)
        elif source.curvature_kind == CURVATURE_INVERSE:
            curvature = transport_inverse_curvature(transport, source.curvature)
        else:
            curvature = np.zeros((0, 0), dtype=float)
        delta_raw = np.asarray(theta_array - source.theta, dtype=float)
        displacement_source = np.asarray(
            source.frame.raw_analysis @ delta_raw, dtype=float
        )
        displacement_target = transport_vector(
            transport, displacement_source
        )
        if str(self.config.endpoint_gradient_prediction_policy) == (
            "transported_source_plus_curvature_displacement_v2"
        ):
            curvature_action, gradient_prediction_telemetry = (
                _typed_curvature_action(
                    curvature_kind=source.curvature_kind,
                    curvature=curvature,
                    displacement=displacement_target,
                )
            )
        else:
            curvature_action = np.zeros_like(transported_beta)
            gradient_prediction_telemetry = {
                "schema": "formal_manifold_typed_curvature_action_v1",
                "curvature_kind": str(source.curvature_kind),
                "action_available": False,
                "reason": "legacy_transported_source_only_policy",
            }
        beta = np.asarray(transported_beta + curvature_action, dtype=float)
        chart_id = _json_hash(list(source.registry))
        metric_record = ProvenanceRecord(
            quantity="predicted_endpoint_metric_frame_and_transport",
            status=STATUS_PREDICTED,
            base_state_id=str(physical_state_fingerprint),
            chart_id=chart_id,
            support_id=metric_prediction.frame.support_id,
            parent_ids=_parent_tuple(
                _latest_provenance_id(
                    source.provenance, role=PROVENANCE_ROLE_METRIC
                )
            ),
            primitive_ids=(),
            certificate={
                **dict(metric_prediction.telemetry),
                **dict(transport.telemetry),
                "provenance_role": PROVENANCE_ROLE_METRIC,
            },
        )
        provenance_list: list[ProvenanceRecord] = [
            *source.provenance,
            metric_record,
        ]
        if source.curvature_kind != CURVATURE_NONE:
            provenance_list.append(
                ProvenanceRecord(
                    quantity="predicted_endpoint_curvature_transport",
                    status=STATUS_PREDICTED,
                    base_state_id=str(physical_state_fingerprint),
                    chart_id=chart_id,
                    support_id=metric_prediction.frame.support_id,
                    parent_ids=_parent_tuple(
                        _latest_provenance_id(
                            source.provenance,
                            role=PROVENANCE_ROLE_CURVATURE,
                        )
                    ),
                    primitive_ids=(),
                    certificate={
                        "provenance_role": PROVENANCE_ROLE_CURVATURE,
                        "curvature_kind": source.curvature_kind,
                        "typed_transport": (
                            "P_inverse_transpose_A_P_inverse"
                            if source.curvature_kind == CURVATURE_DIRECT
                            else "P_B_P_transpose"
                        ),
                        "transport_id": _array_hash(
                            transport.coefficient_transport
                        ),
                        "orientation_provenance": str(
                            transport.orientation_provenance
                        ),
                        "endpoint_gradient_prediction_policy": (
                            str(
                                self.config.endpoint_gradient_prediction_policy
                            )
                        ),
                        "gradient_prediction": {
                            **dict(gradient_prediction_telemetry),
                            "source_gradient_norm": float(
                                np.linalg.norm(source.gradient_covector)
                            ),
                            "transported_source_gradient_norm": float(
                                np.linalg.norm(transported_beta)
                            ),
                            "displacement_norm": float(
                                np.linalg.norm(displacement_target)
                            ),
                            "curvature_action_norm": float(
                                np.linalg.norm(curvature_action)
                            ),
                            "predicted_endpoint_gradient_norm": float(
                                np.linalg.norm(beta)
                            ),
                        },
                    },
                )
            )
        provenance = tuple(provenance_list)
        self._pending_source = source
        self._pending = OuterInformationState(
            state_id="",
            parent_state_id=str(source.state_id),
            physical_state_fingerprint=str(physical_state_fingerprint),
            registry=source.registry,
            theta=theta_array,
            frame=metric_prediction.frame,
            gradient_covector=beta,
            curvature_kind=source.curvature_kind,
            curvature=curvature,
            normalized_strain_model=np.asarray(
                metric_prediction.normalized_strain, dtype=float
            ),
            skew_connection_model=np.asarray(omega, dtype=float),
            prediction_age=int(source.prediction_age + 1),
            geometry_status=STATUS_PREDICTED,
            orientation_status=STATUS_PREDICTED,
            orientation_prediction_age=int(source.orientation_prediction_age + 1),
            provenance=provenance,
            closure_history=source.closure_history,
            source_primitive_ids=source.source_primitive_ids,
            source_observation_ids=source.source_observation_ids,
            transport_from_parent=transport.coefficient_transport,
            transport_step_scale=float(step_scale),
            secant_history=source.secant_history,
        )
        self._failed_closure = None
        self._stage = TRANSACTION_PREDICTION
        return transport

    def close_prediction(
        self,
        *,
        probe_coefficients: np.ndarray | None = None,
        observed_probe_gram: np.ndarray | None = None,
        source_primitive_ids: Sequence[str] = (),
        source_observation_ids: Sequence[str] = (),
        endpoint_raw_gradient: Sequence[float] | None = None,
        force_minimum_change_correction: bool = False,
        authoritative_full_endpoint_metric: np.ndarray | None = None,
        metric_source_primitive_ids: Sequence[str] = (),
        endpoint_gradient_primitive_ids: Sequence[str] = (),
    ) -> ClosureResult:
        if (
            self._pending is None
            or self._pending_source is None
            or self._stage != TRANSACTION_PREDICTION
        ):
            raise RuntimeError("closure requires a pending refit prediction.")
        predicted_state = self._pending
        source_state = self._pending_source
        exact_metric_supplied = authoritative_full_endpoint_metric is not None
        metric_primitive_ids = tuple(
            sorted(
                {
                    str(value).strip()
                    for value in metric_source_primitive_ids
                }
            )
        )
        gradient_primitive_ids = tuple(
            sorted(
                {
                    str(value).strip()
                    for value in endpoint_gradient_primitive_ids
                }
            )
        )
        if any(
            not value
            for value in (*metric_primitive_ids, *gradient_primitive_ids)
        ):
            raise ValueError("typed endpoint primitive IDs must be nonempty.")
        if exact_metric_supplied and endpoint_raw_gradient is not None and not (
            gradient_primitive_ids
        ):
            raise ValueError(
                "an endpoint gradient used with an authoritative full endpoint "
                "metric requires independent endpoint gradient primitive IDs."
            )
        if not exact_metric_supplied and gradient_primitive_ids:
            raise ValueError(
                "endpoint_gradient_primitive_ids are reserved for the typed "
                "authoritative full endpoint metric path."
            )
        result = close_predicted_geometry(
            predicted_state.frame,
            probe_coefficients=probe_coefficients,
            observed_probe_gram=observed_probe_gram,
            config=self.config,
            source_primitive_ids=source_primitive_ids,
            source_observation_ids=source_observation_ids,
            prediction_age=int(predicted_state.prediction_age),
            force_minimum_change_correction=bool(
                force_minimum_change_correction
            ),
            authoritative_full_endpoint_metric=(
                authoritative_full_endpoint_metric
            ),
            metric_source_primitive_ids=metric_primitive_ids,
        )
        closure_primitive_ids = tuple(result.source_primitive_ids)
        self._immutable_primitive_ids.update(closure_primitive_ids)
        self._immutable_primitive_ids.update(gradient_primitive_ids)
        self._immutable_observation_ids.update(
            str(value) for value in source_observation_ids
        )
        if result.outcome not in {CLOSURE_CONTINUE, CLOSURE_CORRECT}:
            # Preserve the failed prediction and its complete closure
            # certificate.  This state is deliberately noncommittable but can
            # be checkpointed, resumed, authoritatively reanchored, or rolled
            # back as information only.  The accepted structural registry is
            # untouched.
            self._failed_closure = result
            self._stage = TRANSACTION_REANCHOR_REQUIRED
            return result
        assert result.frame is not None
        raw_endpoint: np.ndarray | None = None
        if endpoint_raw_gradient is not None:
            raw_endpoint = _finite_vector(
                endpoint_raw_gradient, name="endpoint_raw_gradient"
            )
            if raw_endpoint.size != result.frame.dimension:
                raise ValueError("endpoint gradient dimension mismatch.")
            endpoint_null_certificate = _raw_metric_null_compatibility(
                result.frame,
                raw_gradient=raw_endpoint,
                raw_curvature=None,
                tolerance=float(self.config.energy_model_null_tolerance),
                curvature_policy=str(self.config.null_curvature_policy),
                raise_on_failure=False,
            )
            if not bool(endpoint_null_certificate["gradient_compatible"]):
                result = ClosureResult(
                    outcome=CLOSURE_ANCHOR,
                    reason="endpoint_gradient_outside_predicted_support",
                    frame=None,
                    defect=float(result.defect),
                    probe_rank=int(result.probe_rank),
                    blind_dimension=int(result.blind_dimension),
                    correction=np.asarray(result.correction, dtype=float),
                    observed_probe_gram=np.asarray(
                        result.observed_probe_gram, dtype=float
                    ),
                    predicted_probe_gram=np.asarray(
                        result.predicted_probe_gram, dtype=float
                    ),
                    source_primitive_ids=tuple(result.source_primitive_ids),
                    source_observation_ids=tuple(
                        result.source_observation_ids
                    ),
                    telemetry={
                        **dict(result.telemetry),
                        "outcome": CLOSURE_ANCHOR,
                        "reason": (
                            "endpoint_gradient_outside_predicted_support"
                        ),
                        "metric_closure_outcome": (
                            result.telemetry.get("metric_closure_outcome")
                            if exact_metric_supplied
                            else CLOSURE_ANCHOR
                        ),
                        "endpoint_energy_model_outcome": CLOSURE_ANCHOR,
                        "endpoint_raw_metric_null_compatibility": (
                            endpoint_null_certificate
                        ),
                        "endpoint_gradient_projected": False,
                        "full_endpoint_metric_required": bool(
                            not exact_metric_supplied
                        ),
                        "authoritative_metric_remains_acquired": bool(
                            exact_metric_supplied
                        ),
                    },
                )
                self._failed_closure = result
                self._stage = TRANSACTION_REANCHOR_REQUIRED
                return result
        transport = build_split_connection_transport(
            source_state.frame,
            result.frame,
            config=self.config,
            skew_connection=predicted_state.skew_connection_model,
            step_scale=float(predicted_state.transport_step_scale),
            orientation_provenance=(
                "minimal_rotation_zero_connection_prior_v1"
                if not np.any(predicted_state.skew_connection_model)
                else "predicted_skew_connection_v1"
            ),
        )
        transported_beta = transport_covector(
            transport, source_state.gradient_covector
        )
        if source_state.curvature_kind == CURVATURE_DIRECT:
            curvature = transport_direct_curvature(transport, source_state.curvature)
        elif source_state.curvature_kind == CURVATURE_INVERSE:
            curvature = transport_inverse_curvature(transport, source_state.curvature)
        else:
            curvature = np.zeros((0, 0), dtype=float)
        secant_history = list(source_state.secant_history)
        beta = transported_beta
        update_telemetry: dict[str, Any] = {
            "curvature_update_applied": False,
            "curvature_update_kind": (
                "direct_sr1"
                if source_state.curvature_kind == CURVATURE_DIRECT
                else "inverse_bfgs"
                if source_state.curvature_kind == CURVATURE_INVERSE
                else "none"
            ),
            "curvature_update_denominator": None,
            "reason": "endpoint_gradient_not_acquired",
        }
        relative_metric = _sym(
            np.eye(result.frame.rank, dtype=float) + result.correction
        )
        # The closure correction is expressed in the predicted endpoint frame.
        # Compose it with the prior affine-invariant strain by congruence before
        # returning to the source-frame Lie algebra.  Adding two matrix logs is
        # valid only when the strain and correction commute.
        prior_half = _matrix_exp_symmetric(
            0.5 * predicted_state.normalized_strain_model
        )
        learned_strain = _matrix_log_spd(
            _sym(prior_half @ relative_metric @ prior_half)
        )
        if raw_endpoint is not None:
            beta = np.asarray(
                result.frame.raw_orthonormalizer.T @ raw_endpoint, dtype=float
            )
            delta_raw = np.asarray(
                predicted_state.theta - source_state.theta, dtype=float
            )
            displacement_source = np.asarray(
                source_state.frame.raw_analysis @ delta_raw, dtype=float
            )
            s = transport_vector(transport, displacement_source)
            y = np.asarray(beta - transported_beta, dtype=float)
            curvature, update_telemetry = _guarded_typed_secant_update(
                curvature_kind=source_state.curvature_kind,
                curvature=curvature,
                displacement=s,
                differential_change=y,
                config=self.config,
            )
            secant_history.append(
                {
                    "schema": "formal_manifold_outer_secant_v1",
                    "source_frame_id": str(source_state.frame.frame_id),
                    "target_frame_id": str(result.frame.frame_id),
                    "s": [float(value) for value in s.tolist()],
                    "y": [float(value) for value in y.tolist()],
                    "endpoint_gradient_acquired": True,
                    **dict(update_telemetry),
                }
            )
        update_applied = bool(
            update_telemetry.get("curvature_update_applied", False)
        )
        update_reason = str(update_telemetry.get("reason", ""))
        update_denominator = update_telemetry.get(
            "curvature_update_denominator"
        )
        chart_id = _json_hash(list(predicted_state.registry))
        metric_record = ProvenanceRecord(
            quantity=(
                "authoritative_full_endpoint_metric_frame"
                if exact_metric_supplied
                else "closed_endpoint_metric_frame"
            ),
            status=(
                STATUS_ACQUIRED
                if exact_metric_supplied
                else STATUS_PREDICTED
                if result.outcome == CLOSURE_CONTINUE
                else STATUS_CORRECTED
            ),
            base_state_id=str(predicted_state.physical_state_fingerprint),
            chart_id=chart_id,
            support_id=result.frame.support_id,
            parent_ids=_parent_tuple(
                _latest_provenance_id(
                    predicted_state.provenance,
                    role=PROVENANCE_ROLE_METRIC,
                )
            ),
            primitive_ids=closure_primitive_ids,
            observation_ids=tuple(source_observation_ids),
            certificate={
                **dict(result.telemetry),
                "provenance_role": PROVENANCE_ROLE_METRIC,
            },
        )
        provenance_list: list[ProvenanceRecord] = [
            *predicted_state.provenance,
            metric_record,
        ]
        if source_state.curvature_kind != CURVATURE_NONE:
            provenance_list.append(
                ProvenanceRecord(
                    quantity=(
                        "outer_curvature_secant_corrected"
                        if update_applied
                        else "outer_curvature_transport_reclosed"
                    ),
                    status=(STATUS_CORRECTED if update_applied else STATUS_PREDICTED),
                    base_state_id=str(
                        predicted_state.physical_state_fingerprint
                    ),
                    chart_id=chart_id,
                    support_id=result.frame.support_id,
                    parent_ids=_parent_tuple(
                        _latest_provenance_id(
                            predicted_state.provenance,
                            role=PROVENANCE_ROLE_CURVATURE,
                        )
                    ),
                    primitive_ids=(
                        gradient_primitive_ids
                        if exact_metric_supplied
                        and endpoint_raw_gradient is not None
                        else tuple(source_primitive_ids)
                        if endpoint_raw_gradient is not None
                        else ()
                    ),
                    observation_ids=(
                        tuple(source_observation_ids)
                        if endpoint_raw_gradient is not None
                        else ()
                    ),
                    certificate={
                        "provenance_role": PROVENANCE_ROLE_CURVATURE,
                        "curvature_kind": source_state.curvature_kind,
                        "typed_transport": (
                            "P_inverse_transpose_A_P_inverse"
                            if source_state.curvature_kind == CURVATURE_DIRECT
                            else "P_B_P_transpose"
                        ),
                        "endpoint_gradient_acquired": bool(
                            endpoint_raw_gradient is not None
                        ),
                        "secant_update_applied": bool(update_applied),
                        "secant_update_reason": str(update_reason),
                        "secant_update_denominator": update_denominator,
                    },
                )
            )
        provenance = tuple(provenance_list)
        self._pending = OuterInformationState(
            state_id="",
            parent_state_id=str(source_state.state_id),
            physical_state_fingerprint=str(
                predicted_state.physical_state_fingerprint
            ),
            registry=predicted_state.registry,
            theta=predicted_state.theta,
            frame=result.frame,
            gradient_covector=beta,
            curvature_kind=source_state.curvature_kind,
            curvature=curvature,
            normalized_strain_model=learned_strain,
            skew_connection_model=predicted_state.skew_connection_model,
            prediction_age=(
                0
                if exact_metric_supplied
                else int(predicted_state.prediction_age)
            ),
            geometry_status=(
                STATUS_ACQUIRED
                if exact_metric_supplied
                else STATUS_PREDICTED
                if result.outcome == CLOSURE_CONTINUE
                else STATUS_CORRECTED
            ),
            orientation_status=STATUS_PREDICTED,
            orientation_prediction_age=int(
                predicted_state.orientation_prediction_age
            ),
            provenance=provenance,
            closure_history=(
                *predicted_state.closure_history,
                dict(result.telemetry),
            ),
            source_primitive_ids=tuple(
                sorted(
                    set(predicted_state.source_primitive_ids)
                    | set(closure_primitive_ids)
                    | set(gradient_primitive_ids)
                )
            ),
            source_observation_ids=tuple(
                sorted(
                    set(predicted_state.source_observation_ids)
                    | {str(value) for value in source_observation_ids}
                )
            ),
            transport_from_parent=transport.coefficient_transport,
            transport_step_scale=float(predicted_state.transport_step_scale),
            secant_history=tuple(secant_history),
        )
        self._failed_closure = None
        self._stage = TRANSACTION_CLOSED
        return result

    def replace_failed_prediction_with_anchor(
        self,
        *,
        physical_state_fingerprint: str,
        registry: Sequence[str],
        theta: Sequence[float],
        raw_metric: np.ndarray,
        raw_gradient: Sequence[float],
        source_primitive_ids: Sequence[str],
        source_observation_ids: Sequence[str] = (),
        direct_curvature_raw: np.ndarray | None = None,
        inverse_curvature_frame: np.ndarray | None = None,
        cross_frame_overlap: np.ndarray | None = None,
        cross_frame_primitive_ids: Sequence[str] = (),
        apply_endpoint_secant: bool = False,
        authoritative_null_gradient_policy: str = NULL_GRADIENT_REJECT,
    ) -> OuterInformationState:
        """Reanchor the accepted endpoint without undoing structural growth.

        ``cross_frame_overlap`` is optional because an authoritative metric
        anchor does not automatically acquire cross-state tangent data.  When
        it is supplied, it is interpreted as the measured overlap from the
        enlarged source frame to the endpoint frame.  Its Procrustes factor is
        the complete coefficient registration, and any retained source
        curvature is transported with its correct direct/inverse tensor law.
        Without that measurement, no cross-state curvature reuse is claimed.
        ``apply_endpoint_secant`` is an explicit v2 authority policy: after a
        measured registration transports retained curvature, the exact
        endpoint differential supplies a typed SR1/BFGS outer secant.  An
        exact curvature supplied directly remains authoritative and is never
        overwritten by the quasi-Newton correction.
        """

        if self._pending is None:
            raise RuntimeError("there is no failed prediction to replace.")
        if cross_frame_overlap is None and tuple(cross_frame_primitive_ids):
            raise ValueError(
                "cross-frame primitive IDs require a measured cross-frame overlap."
            )
        if cross_frame_overlap is not None and not tuple(
            str(value) for value in cross_frame_primitive_ids
        ):
            raise ValueError(
                "a measured cross-frame overlap requires immutable primitive IDs."
            )
        accepted_registry = tuple(str(value) for value in self._pending.registry)
        supplied_registry = tuple(str(value) for value in registry)
        if supplied_registry != accepted_registry:
            raise ValueError(
                "reanchor must preserve the already accepted structural registry."
            )
        anchor = initialize_outer_information_state(
            physical_state_fingerprint=str(physical_state_fingerprint),
            registry=supplied_registry,
            theta=theta,
            raw_metric=raw_metric,
            raw_gradient=raw_gradient,
            config=self.config,
            source_primitive_ids=source_primitive_ids,
            source_observation_ids=source_observation_ids,
            direct_curvature_raw=direct_curvature_raw,
            inverse_curvature_frame=inverse_curvature_frame,
            authoritative_null_gradient_policy=(
                authoritative_null_gradient_policy
            ),
        )
        source_state = self._pending_source
        parent_state_id = (
            None if self._committed is None else self._committed.state_id
        )
        transport: SplitConnectionTransport | None = None
        curvature_kind = anchor.curvature_kind
        curvature = np.asarray(anchor.curvature, dtype=float)
        provenance_list: list[ProvenanceRecord] = []
        if source_state is not None:
            provenance_list.extend(source_state.provenance)
        provenance_list.extend(anchor.provenance)
        source_ids = {str(value) for value in source_primitive_ids}
        if source_state is not None:
            source_ids.update(source_state.source_primitive_ids)
        closure_history: list[Mapping[str, Any]] = list(
            () if source_state is None else source_state.closure_history
        )
        secant_history: list[Mapping[str, Any]] = list(
            () if source_state is None else source_state.secant_history
        )
        if self._failed_closure is not None:
            closure_history.append(dict(self._failed_closure.telemetry))

        if cross_frame_overlap is not None:
            if source_state is None:
                raise RuntimeError(
                    "measured reanchor registration requires the retained source frame."
                )
            registration, registration_telemetry = measured_procrustes_orientation(
                cross_frame_overlap,
                alignment_floor=float(self.config.orientation_alignment_floor),
            )
            transport = build_split_connection_transport(
                source_state.frame,
                anchor.frame,
                config=self.config,
                measured_orientation=registration,
                orientation_provenance="measured_cross_frame_procrustes_v1",
            )
            parent_state_id = str(source_state.state_id)
            source_ids.update(str(value) for value in cross_frame_primitive_ids)
            source_metric_id = _latest_provenance_id(
                source_state.provenance,
                role=PROVENANCE_ROLE_METRIC,
            )
            target_metric_id = _latest_provenance_id(
                anchor.provenance,
                role=PROVENANCE_ROLE_METRIC,
            )
            registration_record = ProvenanceRecord(
                quantity="measured_cross_frame_procrustes_registration",
                status=STATUS_ACQUIRED,
                base_state_id=str(physical_state_fingerprint),
                chart_id=_json_hash(list(supplied_registry)),
                support_id=anchor.frame.support_id,
                parent_ids=tuple(
                    value
                    for value in (source_metric_id, target_metric_id)
                    if value is not None
                ),
                primitive_ids=tuple(cross_frame_primitive_ids),
                certificate={
                    **registration_telemetry,
                    **dict(transport.telemetry),
                    "provenance_role": PROVENANCE_ROLE_REGISTRATION,
                    "coefficient_transport_id": _array_hash(
                        transport.coefficient_transport
                    ),
                },
            )
            provenance_list.append(registration_record)
            if (
                direct_curvature_raw is None
                and inverse_curvature_frame is None
                and source_state.curvature_kind != CURVATURE_NONE
            ):
                curvature_kind = source_state.curvature_kind
                if curvature_kind == CURVATURE_DIRECT:
                    curvature = transport_direct_curvature(
                        transport, source_state.curvature
                    )
                else:
                    curvature = transport_inverse_curvature(
                        transport, source_state.curvature
                    )
                transport_curvature_record = ProvenanceRecord(
                        quantity="outer_curvature_measured_reanchor_transport",
                        status=STATUS_INHERITED,
                        base_state_id=str(physical_state_fingerprint),
                        chart_id=_json_hash(list(supplied_registry)),
                        support_id=anchor.frame.support_id,
                        parent_ids=tuple(
                            value
                            for value in (
                                _latest_provenance_id(
                                    source_state.provenance,
                                    role=PROVENANCE_ROLE_CURVATURE,
                                ),
                                registration_record.record_id,
                            )
                            if value is not None
                        ),
                        primitive_ids=(),
                        certificate={
                            "provenance_role": PROVENANCE_ROLE_CURVATURE,
                            "curvature_kind": curvature_kind,
                            "typed_transport": (
                                "P_inverse_transpose_A_P_inverse"
                                if curvature_kind == CURVATURE_DIRECT
                                else "P_B_P_transpose"
                            ),
                            "registration_record_id": str(
                                registration_record.record_id
                            ),
                            "cross_state_quantum_information_reused": True,
                            "classical_transport_quantum_query_charge": 0,
                        },
                    )
                provenance_list.append(transport_curvature_record)
                if bool(apply_endpoint_secant):
                    transported_beta = transport_covector(
                        transport, source_state.gradient_covector
                    )
                    delta_raw = np.asarray(
                        anchor.theta - source_state.theta, dtype=float
                    )
                    displacement_source = np.asarray(
                        source_state.frame.raw_analysis @ delta_raw,
                        dtype=float,
                    )
                    s = transport_vector(transport, displacement_source)
                    y = np.asarray(
                        anchor.gradient_covector - transported_beta,
                        dtype=float,
                    )
                    curvature, secant_telemetry = (
                        _guarded_typed_secant_update(
                            curvature_kind=curvature_kind,
                            curvature=curvature,
                            displacement=s,
                            differential_change=y,
                            config=self.config,
                        )
                    )
                    secant_record = {
                        "schema": "formal_manifold_outer_secant_v1",
                        "source_frame_id": str(source_state.frame.frame_id),
                        "target_frame_id": str(anchor.frame.frame_id),
                        "s": [float(value) for value in s.tolist()],
                        "y": [float(value) for value in y.tolist()],
                        "endpoint_gradient_acquired": True,
                        "authority_policy": (
                            "measured_reanchor_exact_gradient_secant_v2"
                        ),
                        **dict(secant_telemetry),
                    }
                    secant_history.append(secant_record)
                    provenance_list.append(
                        ProvenanceRecord(
                            quantity=(
                                "outer_curvature_measured_reanchor_"
                                "secant_corrected"
                                if bool(
                                    secant_telemetry.get(
                                        "curvature_update_applied", False
                                    )
                                )
                                else "outer_curvature_measured_reanchor_"
                                "secant_guarded"
                            ),
                            status=(
                                STATUS_CORRECTED
                                if bool(
                                    secant_telemetry.get(
                                        "curvature_update_applied", False
                                    )
                                )
                                else STATUS_INHERITED
                            ),
                            base_state_id=str(physical_state_fingerprint),
                            chart_id=_json_hash(list(supplied_registry)),
                            support_id=anchor.frame.support_id,
                            parent_ids=(
                                str(transport_curvature_record.record_id),
                            ),
                            primitive_ids=tuple(source_primitive_ids),
                            observation_ids=tuple(source_observation_ids),
                            certificate={
                                "provenance_role": PROVENANCE_ROLE_CURVATURE,
                                "curvature_kind": curvature_kind,
                                "endpoint_gradient_acquired": True,
                                "authority_policy": (
                                    "measured_reanchor_exact_gradient_"
                                    "secant_v2"
                                ),
                                **dict(secant_telemetry),
                            },
                        )
                    )

        closure_history.append(
            {
                "schema": "formal_manifold_authoritative_reanchor_v1",
                "failed_closure_outcome": (
                    None
                    if self._failed_closure is None
                    else str(self._failed_closure.outcome)
                ),
                "measured_cross_frame_registration": bool(
                    cross_frame_overlap is not None
                ),
                "endpoint_secant_requested": bool(apply_endpoint_secant),
                "endpoint_secant_observed": bool(
                    len(secant_history)
                    > (0 if source_state is None else len(source_state.secant_history))
                ),
                "accepted_registry_preserved": True,
                "structural_rollback_performed": False,
            }
        )
        anchor = OuterInformationState(
            state_id="",
            parent_state_id=parent_state_id,
            physical_state_fingerprint=str(physical_state_fingerprint),
            registry=anchor.registry,
            theta=anchor.theta,
            frame=anchor.frame,
            gradient_covector=anchor.gradient_covector,
            curvature_kind=curvature_kind,
            curvature=curvature,
            normalized_strain_model=anchor.normalized_strain_model,
            skew_connection_model=anchor.skew_connection_model,
            prediction_age=0,
            geometry_status=STATUS_ACQUIRED,
            orientation_status=STATUS_ACQUIRED,
            orientation_prediction_age=0,
            provenance=tuple(provenance_list),
            closure_history=tuple(closure_history),
            source_primitive_ids=tuple(sorted(str(value) for value in source_ids)),
            source_observation_ids=tuple(
                sorted(
                    set(anchor.source_observation_ids)
                    | {
                        str(value)
                        for value in source_observation_ids
                    }
                )
            ),
            transport_from_parent=(
                None if transport is None else transport.coefficient_transport
            ),
            transport_step_scale=(
                0.0
                if transport is None
                else float(
                    self._pending.transport_step_scale
                    if self._pending is not None
                    else 1.0
                )
            ),
            secant_history=tuple(secant_history),
        )
        self._pending = anchor
        self._pending_source = None
        self._failed_closure = None
        self._stage = TRANSACTION_CLOSED
        self._immutable_primitive_ids.update(source_ids)
        self._immutable_observation_ids.update(
            str(value) for value in source_observation_ids
        )
        return anchor

    def commit(self) -> OuterInformationState:
        if (
            self._pending is None
            or self._stage != TRANSACTION_CLOSED
            or self._failed_closure is not None
        ):
            raise RuntimeError("only a closed or authoritative anchor may commit.")
        self._committed = self._pending
        self._pending = None
        self._pending_source = None
        self._failed_closure = None
        self._stage = TRANSACTION_IDLE
        return self._committed

    def rollback_prediction(self) -> None:
        """Discard speculative descendants while preserving acquired IDs."""

        self._pending = None
        self._pending_source = None
        self._failed_closure = None
        self._stage = TRANSACTION_IDLE

    def invalidate_after_structural_change(
        self,
        *,
        reason: str,
        accepted_registry: Sequence[str] = (),
        source_primitive_ids: Sequence[str] = (),
        source_observation_ids: Sequence[str] = (),
    ) -> None:
        """Drop incompatible geometry after an accepted prune or chart change.

        This is not structural rollback.  The caller has already accepted the
        new ansatz registry; only the stale metric/frame/curvature hypothesis
        is discarded.  Acquired primitive identities remain immutable and the
        next outer round must establish a new authoritative anchor.
        """

        reason_value = str(reason).strip()
        if not reason_value:
            raise ValueError("structural invalidation requires a reason.")
        primitive_ids = tuple(sorted({str(value) for value in source_primitive_ids}))
        observation_ids = tuple(
            sorted({str(value) for value in source_observation_ids})
        )
        self._immutable_primitive_ids.update(primitive_ids)
        self._immutable_observation_ids.update(observation_ids)
        self._invalidations.append(
            {
                "schema": "formal_manifold_outer_structural_invalidation_v1",
                "reason": reason_value,
                "accepted_registry": [str(value) for value in accepted_registry],
                "source_primitive_ids": list(primitive_ids),
                "source_observation_ids": list(observation_ids),
                "structural_rollback_performed": False,
                "discarded_information_only": True,
                "previous_committed_state_id": (
                    None if self._committed is None else str(self._committed.state_id)
                ),
                "previous_pending_state_id": (
                    None if self._pending is None else str(self._pending.state_id)
                ),
            }
        )
        self._committed = None
        self._pending = None
        self._pending_source = None
        self._failed_closure = None
        self._stage = TRANSACTION_IDLE

    def checkpoint_payload(self) -> dict[str, Any]:
        payload = {
            "schema": OUTER_INFORMATION_CHECKPOINT_SCHEMA,
            "config": self.config.as_dict(),
            "stage": str(self._stage),
            "committed": (
                None if self._committed is None else self._committed.portable_payload()
            ),
            "pending": (
                None if self._pending is None else self._pending.portable_payload()
            ),
            "pending_source": (
                None
                if self._pending_source is None
                else self._pending_source.portable_payload()
            ),
            "failed_closure": (
                None
                if self._failed_closure is None
                else self._failed_closure.portable_payload()
            ),
            "immutable_primitive_ids": list(self.immutable_primitive_ids),
            "immutable_observation_ids": list(self.immutable_observation_ids),
            "invalidations": _portable_payload(self._invalidations),
        }
        payload["checkpoint_sha256"] = _json_hash(payload)
        return payload

    @classmethod
    def from_checkpoint_payload(
        cls, payload: Mapping[str, Any]
    ) -> "OuterInformationSession":
        values = dict(payload)
        if values.get("schema") != OUTER_INFORMATION_CHECKPOINT_SCHEMA:
            raise ValueError("outer-information checkpoint schema mismatch.")
        supplied_checkpoint_sha256 = str(values.pop("checkpoint_sha256", ""))
        if not supplied_checkpoint_sha256:
            raise ValueError("outer-information checkpoint fingerprint is missing.")
        expected_checkpoint_sha256 = _json_hash(values)
        if supplied_checkpoint_sha256 != expected_checkpoint_sha256:
            raise ValueError("outer-information checkpoint fingerprint mismatch.")
        config = OuterInformationConfig(**dict(values.get("config", {})))
        committed_raw = values.get("committed")
        session = cls(
            config=config,
            committed=(
                None
                if committed_raw is None
                else OuterInformationState.from_portable_payload(committed_raw)
            ),
        )
        pending_raw = values.get("pending")
        pending_source_raw = values.get("pending_source")
        session._pending = (
            None
            if pending_raw is None
            else OuterInformationState.from_portable_payload(pending_raw)
        )
        session._pending_source = (
            None
            if pending_source_raw is None
            else OuterInformationState.from_portable_payload(pending_source_raw)
        )
        failed_closure_raw = values.get("failed_closure")
        session._failed_closure = (
            None
            if failed_closure_raw is None
            else ClosureResult.from_portable_payload(failed_closure_raw)
        )
        stage = str(values.get("stage", TRANSACTION_IDLE))
        if stage not in {
            TRANSACTION_IDLE,
            TRANSACTION_GROWTH,
            TRANSACTION_PREDICTION,
            TRANSACTION_REANCHOR_REQUIRED,
            TRANSACTION_CLOSED,
        }:
            raise ValueError("outer-information checkpoint has an unknown stage.")
        pending = session._pending
        pending_source = session._pending_source
        failed_closure = session._failed_closure
        transaction_valid = False
        if stage == TRANSACTION_IDLE:
            transaction_valid = bool(
                pending is None
                and pending_source is None
                and failed_closure is None
            )
        elif stage == TRANSACTION_GROWTH:
            transaction_valid = bool(
                pending is not None
                and pending_source is not None
                and failed_closure is None
                and pending.state_id == pending_source.state_id
                and pending.geometry_status == STATUS_INHERITED
                and pending.orientation_status == STATUS_INHERITED
            )
        elif stage == TRANSACTION_PREDICTION:
            transaction_valid = bool(
                pending is not None
                and pending_source is not None
                and failed_closure is None
                and pending.geometry_status == STATUS_PREDICTED
                and pending.orientation_status == STATUS_PREDICTED
                and pending.parent_state_id == pending_source.state_id
                and pending.registry == pending_source.registry
            )
        elif stage == TRANSACTION_REANCHOR_REQUIRED:
            transaction_valid = bool(
                pending is not None
                and pending_source is not None
                and failed_closure is not None
                and failed_closure.outcome
                in {CLOSURE_ANCHOR, CLOSURE_INVALIDATE}
                and failed_closure.frame is None
                and pending.geometry_status == STATUS_PREDICTED
                and pending.orientation_status == STATUS_PREDICTED
                and pending.parent_state_id == pending_source.state_id
                and pending.registry == pending_source.registry
            )
        elif stage == TRANSACTION_CLOSED:
            if (
                pending is not None
                and pending_source is None
                and failed_closure is None
            ):
                transaction_valid = bool(
                    pending.geometry_status == STATUS_ACQUIRED
                    and pending.orientation_status == STATUS_ACQUIRED
                )
            elif (
                pending is not None
                and pending_source is not None
                and failed_closure is None
            ):
                transaction_valid = bool(
                    pending.geometry_status in {STATUS_PREDICTED, STATUS_CORRECTED}
                    and pending.orientation_status == STATUS_PREDICTED
                    and pending.parent_state_id == pending_source.state_id
                    and pending.registry == pending_source.registry
                )
        if not transaction_valid:
            raise ValueError("outer-information checkpoint transaction mismatch.")
        session._stage = stage
        if "immutable_primitive_ids" not in values:
            raise ValueError(
                "outer-information checkpoint lacks typed primitive inventory."
            )
        session._immutable_primitive_ids = {
            str(value) for value in values.get("immutable_primitive_ids", ())
        }
        session._immutable_observation_ids = {
            str(value) for value in values.get("immutable_observation_ids", ())
        }
        session._invalidations = [
            deepcopy(dict(value)) for value in values.get("invalidations", ())
        ]
        if session._committed is not None:
            session._immutable_primitive_ids.update(
                session._committed.source_primitive_ids
            )
            session._immutable_observation_ids.update(
                session._committed.source_observation_ids
            )
        required_primitive_ids: set[str] = set()
        required_observation_ids: set[str] = set()
        for state in (session._committed, pending, pending_source):
            if state is not None:
                required_primitive_ids.update(state.source_primitive_ids)
                required_observation_ids.update(state.source_observation_ids)
        if failed_closure is not None:
            required_primitive_ids.update(failed_closure.source_primitive_ids)
            required_observation_ids.update(failed_closure.source_observation_ids)
        if not required_primitive_ids.issubset(session._immutable_primitive_ids):
            raise ValueError(
                "outer-information checkpoint lost immutable primitive IDs."
            )
        if not required_observation_ids.issubset(
            session._immutable_observation_ids
        ):
            raise ValueError(
                "outer-information checkpoint lost immutable observation IDs."
            )
        return session


__all__ = [
    "CLOSURE_ANCHOR",
    "CLOSURE_CONTINUE",
    "CLOSURE_CORRECT",
    "CLOSURE_INVALIDATE",
    "CURVATURE_DIRECT",
    "CURVATURE_INVERSE",
    "CURVATURE_NONE",
    "EXACT_OUTER_CONTROL_AUTHORITY_EACH_OUTER_V1",
    "EXACT_OUTER_CONTROL_MODEL_GUARD_EACH_OUTER_V2",
    "EXACT_OUTER_CONTROL_CHOICES",
    "EXACT_OUTER_CONTROL_OFF",
    "EXACT_OUTER_CONTROL_SHADOW_EACH_OUTER_V1",
    "ClosureResult",
    "MetricPrediction",
    "OuterInformationConfig",
    "OuterInformationReanchorRequired",
    "OuterInformationSession",
    "OuterInformationState",
    "OuterSupportedFrame",
    "ProvenanceRecord",
    "STATUS_ACQUIRED",
    "STATUS_CORRECTED",
    "STATUS_DERIVED",
    "STATUS_INHERITED",
    "STATUS_INVALIDATED",
    "STATUS_PREDICTED",
    "TRANSACTION_CLOSED",
    "TRANSACTION_GROWTH",
    "TRANSACTION_IDLE",
    "TRANSACTION_PREDICTION",
    "TRANSACTION_REANCHOR_REQUIRED",
    "SameRayExtension",
    "SplitConnectionTransport",
    "build_split_connection_transport",
    "build_supported_frame",
    "close_predicted_geometry",
    "compare_predicted_to_exact_outer_geometry",
    "extend_same_ray_frame",
    "initialize_outer_information_state",
    "measured_procrustes_orientation",
    "normalize_exact_outer_control_mode",
    "predict_endpoint_metric",
    "summarize_outer_curvature_model",
    "supported_subspace_projector_defect",
    "transport_covector",
    "transport_direct_curvature",
    "transport_inverse_curvature",
    "transport_vector",
]
