#!/usr/bin/env python3
"""CLI wrapper for Paper-I HH Table-III exact prefix-resource export."""

from __future__ import annotations

import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from pipelines.exact_bench.hh_tableiii_prefix_resources import main


if __name__ == "__main__":
    raise SystemExit(main())
