#!/usr/bin/env python3
"""Growth-trace campaign for record-first adaptive QSE and its comparators.

Implements section 1 of `agent_guidance/qse/paper-iii-comparison-protocol.md`.
Every method grows its subspace one direction at a time to a fixed cap; at
each step k the tuple (k, N2q, D2q, Dc,
max_{nu in mathcal R}|Delta E_nu|) is recorded.
The comparison is read off the trace:

    K*(eps_E) = min{cost over trace : max|Delta E| <= eps_E}

so no method's own stopping rule enters the comparison (the Paper-I
fixed-iteration convention). Our residual stop is reported as a marker on the
trace, never as the comparison mechanism.

Exchange policies, both implemented, evaluated on the cheap tier before one
becomes canonical:

- ``crossing``  (policy A) -- certified exchange applied only to the prefix
  that first crosses each target. Matches what exchange is: post-hoc
  compression of a finished basis. Cheap.
- ``every_k``   (policy B) -- exchange applied at every recorded step,
  producing a fully exchanged trace. Expensive; may compress earlier.

The canonical method acquires and exchange-maintains inexpensive records from
a fixed pool. It terminates with an explicit online status when the target
window is certified, the pool is exhausted, or the dimension cap prevents a
certificate. Davidson remains a separate comparator; the optional two-stage
hybrid exists only behind an explicit function and is not run by this campaign.

Statevector diagnostics; never feeds controller decisions.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from pipelines.exact_bench.paper_iii_matched_accuracy_campaign import (
    ERROR_TARGET_LADDER,
    REGIME_SETS,
    STATUS_NOT_IN_POOL,
    STATUS_REACHED,
    STATUS_UNATTAINABLE,
)
from pipelines.exact_bench.paper_iii_qse_paper_i_convention_sweep import (
    _LINEAR_RESPONSE_FAMILIES,
    _element_family,
)
from pipelines.qse_spectra.core import QSEBasisVectorPolicy, compute_qse_spectra
from pipelines.qse_spectra.exchange_maintenance import (
    QSEExchangeConfig,
    run_qse_exchange_maintenance,
)
from pipelines.qse_spectra.adaptive_qse_benchmark import (
    STOP_MAX_DIMENSION,
    STOP_POOL_EXHAUSTED_EQUIVALENT,
    STOP_RESIDUAL_CONVERGED,
    run_adaptive_qse_benchmark,
)
from pipelines.qse_spectra.davidson_initialization import (
    ORIGIN_COMPUTATIONAL_PROBE,
    ORIGIN_FIXED_RECORD,
    build_direct_davidson_start,
)
from pipelines.qse_spectra.method_completion import (
    ROUTE_DIRECT_DAVIDSON,
    ROUTE_SELECTED_QSE_DAVIDSON_HYBRID,
    certify_fixed_pool_support,
    classify_selected_qse_completion,
)
from pipelines.qse_spectra.paper_iii_problem import load_problem
from pipelines.qse_spectra.record_selection import (
    StaticRecordSelectionConfig,
    select_static_qse_records,
)

DEFAULT_OUTPUT = (
    REPO_ROOT
    / "output/diagnostics/paper_iii_selected_qse_fixed_pool_v1/growth_trace.json"
)
_Q0_POLICY = QSEBasisVectorPolicy(
    reference_projection="q0", basis_vector_normalization="raw_projected"
)
_TARGET_ROOTS = 6
RESIDUAL_MARKER = 1.0e-3
DEFAULT_DIMENSION_CAP = 64


def _mixed_resource_triple(
    *,
    seed_resources: Mapping[str, float],
    per_synthesized_direction: Mapping[str, float],
    synthesized_direction_count: int,
) -> dict[str, float]:
    """Combine record-seed cost with residual-synthesis cost.

    Adaptive QSE starts from declared operator records but only its later
    Davidson corrections are synthesized directions.  Keeping those two
    contributions separate prevents charging a cheap seed record as a full
    Hamiltonian-evolution step.
    """

    count = int(synthesized_direction_count)
    if count < 0:
        raise ValueError("synthesized_direction_count must be non-negative.")
    return {
        resource: float(seed_resources[resource])
        + count * float(per_synthesized_direction[resource])
        for resource in ("n2q", "d2q", "dc")
    }


def _window_error(
    problem: Any, indices: Sequence[int]
) -> tuple[float | None, int, list[float] | None, list[float]]:
    """Max window error, retained rank, and the per-target-root errors.

    ``per_root`` is additive reporting data: it lets a post-run reading score
    a declared subset of the target window (see
    ``pipelines/qse_spectra/target_window.py``) without rerunning anything.
    ``max_root_abs_error`` keeps its exact previous meaning.
    """

    try:
        result = compute_qse_spectra(
            problem.hamiltonian,
            problem.ground,
            tuple(problem.basis[int(i)] for i in indices),
            basis_vector_policy=_Q0_POLICY,
        )
    except ValueError:
        return None, 0, None, []
    energies = np.asarray(result.eigenvalues, dtype=float).reshape(-1)
    refs = problem.references
    roots = [float(value) for value in energies[: len(refs)]]
    if energies.size < len(refs):
        return None, int(result.retained_rank), None, roots
    per_root = [abs(float(energies[r]) - float(ref)) for r, ref in enumerate(refs)]
    return max(per_root), int(result.retained_rank), per_root, roots


def _exchange(problem: Any, indices: Sequence[int]) -> list[int]:
    result = run_qse_exchange_maintenance(
        problem.basis,
        list(indices),
        problem.costs,
        hamiltonian=problem.hamiltonian,
        prepared_state=problem.ground,
        basis_vector_policy=_Q0_POLICY,
        config=QSEExchangeConfig(
            max_rounds=30, target_root_count=_TARGET_ROOTS, insertion_shortlist_size=16
        ),
    )
    return [int(i) for i in result.final_indices]


def _row(problem: Any, indices: Sequence[int], k: int, *, exchanged: bool) -> dict[str, Any]:
    err, rank, per_root, roots = _window_error(problem, indices)
    res = problem.resource_triple(indices)
    return {
        "k": int(k),
        "support_size": len(indices),
        "support_indices": [int(index) for index in indices],
        "exchanged": bool(exchanged),
        "retained_rank": rank,
        "max_root_abs_error": err,
        "per_root_abs_error": per_root,
        "root_match_convention": "index_matched_ascending",
        "root_energies": roots,
        **res,
    }


def trace_arm(
    problem: Any,
    order: Sequence[int],
    *,
    stride: int,
    k_max: int,
    exchange_policy: str,
) -> list[dict[str, Any]]:
    """Grow along ``order`` to ``k_max``, recording one row per stride step."""

    rows: list[dict[str, Any]] = []
    cap = min(int(k_max), len(order))
    # The terminal prefix must always be evaluated: an order whose length is
    # not a multiple of the stride would otherwise drop its final record, and
    # that record is often the one completing the retained rank.
    steps = sorted({*range(stride, cap + 1, stride), cap})
    for k in steps:
        if k <= 0:
            continue
        prefix = [int(i) for i in order[:k]]
        if exchange_policy == "every_k":
            prefix = _exchange(problem, prefix)
            rows.append(_row(problem, prefix, k, exchanged=True))
        else:
            rows.append(_row(problem, prefix, k, exchanged=False))
    return rows


def _trace_direct_davidson(
    problem: Any,
    *,
    k_max: int,
    target_root_count: int = _TARGET_ROOTS,
    require_completion_metadata: bool,
    include_terminal_ritz_vectors: bool = False,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Growth trace for the external adaptive-QSE (quantum Davidson) arm.

    Grown to the same dimension cap as every other arm and scored on the same
    exact references. It synthesizes directions rather than consuming the
    record alphabet, so its resources come from the arm's own costing
    convention, not from `problem.resource_triple`.
    """

    roots_requested = int(target_root_count)
    if roots_requested <= 0:
        raise ValueError("target_root_count must be positive.")
    seed_indices = [
        i for i, e in enumerate(problem.basis)
        if _element_family(e.name) in _LINEAR_RESPONSE_FAMILIES
    ]
    start = build_direct_davidson_start(
        problem,
        target_root_count=roots_requested,
        fixed_record_indices=seed_indices,
    )
    declared_initial_dimension = 1 + len(start.seed_directions)
    if int(k_max) < declared_initial_dimension:
        raise ValueError(
            "DAVIDSON_INITIALIZATION_CAP_INSUFFICIENT: dimension cap "
            f"{int(k_max)} cannot evaluate the declared initialization block "
            f"of dimension at most {declared_initial_dimension}."
        )
    seed = [direction.payload for direction in start.seed_directions]
    seed_direction_resources = [
        dict(direction.resources) for direction in start.seed_directions
    ]
    # Residual corrections are charged as one first-order Trotter step of H,
    # matching Krylov.  The declared seed is different: those directions are
    # literal pool records and retain their record-specific compiled costs.
    from pipelines.qse_spectra.compiled_costs import (
        ORACLE_KIND_MARRAKESH_GRAPH_SPAN,
        annotate_basis_with_compiled_costs,
        resolve_cost_weights_preset,
    )
    from pipelines.qse_spectra.core import polynomial_basis_element

    step_rows = annotate_basis_with_compiled_costs(
        [polynomial_basis_element(problem.hamiltonian, name="first_order_trotter_step")],
        num_qubits=problem.num_qubits,
        oracle_kind=ORACLE_KIND_MARRAKESH_GRAPH_SPAN,
        cost_weights=resolve_cost_weights_preset("two_qubit_only_v1"),
    )
    est = step_rows[0].estimate
    per_direction = {
        "n2q": float(est.c_hat_2q),
        "d2q": float(est.c_hat_d),
        "dc": float(est.c_hat_d) + float(est.c_hat_1q),
    }
    adaptive_kwargs: dict[str, Any] = {}
    if include_terminal_ritz_vectors:
        adaptive_kwargs["return_final_ritz_vectors"] = True
    audit = run_adaptive_qse_benchmark(
        problem.hamiltonian,
        problem.ground,
        # The benchmark returns the lowest N Ritz values INCLUDING the ground
        # root, so request R+1 and compare the excitations root_energies[1:].
        target_roots=roots_requested + 1,
        eps_residual=1.0e-14,      # effectively run to the cap; the trace supplies K*
        max_dimension=int(k_max),
        seed_elements=seed,
        seed_direction_resources=seed_direction_resources,
        direction_resources=per_direction,
        **adaptive_kwargs,
    )
    seed_rows = list(audit["seed_policy"]["seed_rows"])
    evaluated_directions = tuple(start.seed_directions[: len(seed_rows)])
    admitted_directions = [
        direction
        for direction, row in zip(evaluated_directions, seed_rows)
        if bool(row["admitted"])
    ]
    admitted_seed_count = len(admitted_directions)
    initial_adaptive_dimension = 1 + admitted_seed_count
    seed_resources = {
        resource: float(
            sum(float(direction.resources[resource]) for direction in admitted_directions)
        )
        for resource in ("n2q", "d2q", "dc")
    }
    seed_resources_by_origin = {
        origin: {
            resource: float(
                sum(
                    float(direction.resources[resource])
                    for direction in admitted_directions
                    if direction.origin == origin
                )
            )
            for resource in ("n2q", "d2q", "dc")
        }
        for origin in (ORIGIN_FIXED_RECORD, ORIGIN_COMPUTATIONAL_PROBE)
    }
    initialization_receipt = {
        **dict(start.receipt),
        "declared_seed_direction_count": len(start.seed_directions),
        "evaluated_seed_direction_count": len(seed_rows),
        "admitted_seed_direction_count": admitted_seed_count,
        "admitted_fixed_record_count": sum(
            direction.origin == ORIGIN_FIXED_RECORD for direction in admitted_directions
        ),
        "admitted_computational_probe_count": sum(
            direction.origin == ORIGIN_COMPUTATIONAL_PROBE
            for direction in admitted_directions
        ),
        "admitted_seed_labels": [direction.label for direction in admitted_directions],
        "admitted_seed_resources_by_origin": seed_resources_by_origin,
    }
    from pipelines.exact_bench.paper_iii_qse_measurement_cost import _polynomial_words

    # Estimator queries for a synthesized-basis pencil. This arm's basis
    # vectors are states, not O_i|psi0>, so its S/H elements are not Pauli-word
    # products and cannot be QWC-grouped: each of the d(d+1)/2 independent
    # elements needs an overlap estimation plus one per Hamiltonian Pauli term
    # (Hadamard-test style, no grouping reuse). The convention is deliberately
    # less favourable than the record arms' QWC cover and is declared as such.
    ham_term_count = len(_polynomial_words(problem.hamiltonian))

    def _adaptive_estimator(dimension: int) -> dict[str, Any]:
        pairs = int(dimension) * (int(dimension) + 1) // 2
        return {
            "pair_count": pairs,
            "queries": int(pairs * (1 + ham_term_count)),
            "hamiltonian_pauli_terms": int(ham_term_count),
            "convention": "synthesized_basis_pencil_no_qwc_reuse",
        }

    refs = problem.references
    rows: list[dict[str, Any]] = []
    for it in audit["iterations"]:
        all_roots = it.get("root_energies") or []
        roots = list(all_roots[1:])          # drop the ground root
        per_root = (
            [abs(float(roots[r]) - float(ref)) for r, ref in enumerate(refs)]
            if len(roots) >= len(refs) else None
        )
        err = max(per_root) if per_root is not None else None
        dimension = int(it["dimension"])
        synthesized_direction_count = max(
            0, dimension - int(initial_adaptive_dimension)
        )
        res = _mixed_resource_triple(
            seed_resources=seed_resources,
            per_synthesized_direction=per_direction,
            synthesized_direction_count=synthesized_direction_count,
        )
        rows.append(
            {
                "k": dimension,
                "support_size": dimension,
                "exchanged": False,
                "retained_rank": int(it["retained_rank"]),
                "max_root_abs_error": err,
                "n2q": float(res["n2q"]),
                "d2q": float(res["d2q"]),
                "dc": float(res["dc"]),
                "seed_direction_count": int(admitted_seed_count),
                "seed_record_count": int(
                    initialization_receipt["admitted_fixed_record_count"]
                ),
                "seed_fixed_record_count": int(
                    initialization_receipt["admitted_fixed_record_count"]
                ),
                "seed_computational_probe_count": int(
                    initialization_receipt["admitted_computational_probe_count"]
                ),
                "seed_resources": dict(seed_resources),
                "seed_resources_by_origin": dict(seed_resources_by_origin),
                "initialization_receipt": dict(initialization_receipt),
                "synthesized_direction_count": int(synthesized_direction_count),
                "per_synthesized_direction": dict(per_direction),
                "costing_convention": "robust_mixed_seed_plus_trotterized_residual_directions_v2",
                "per_root_abs_error": per_root,
                "root_match_convention": "index_matched_ascending",
                "root_energies": roots,
                "estimator": _adaptive_estimator(dimension),
            }
        )
    if not require_completion_metadata and "stop_reason" not in audit:
        # The legacy row-only API predates terminal receipts.  Keeping that API
        # tolerant lets older test doubles continue to exercise its costing
        # semantics, while the campaign-facing API below remains fail-closed.
        return rows, {}
    native_stop_reason = str(audit["stop_reason"])
    terminal_status = {
        STOP_RESIDUAL_CONVERGED: "DAVIDSON_RESIDUAL_CERTIFIED",
        STOP_MAX_DIMENSION: "DAVIDSON_DIMENSION_CAP_REACHED",
        STOP_POOL_EXHAUSTED_EQUIVALENT: "DAVIDSON_NO_NOVEL_CORRECTION",
    }[native_stop_reason]
    completion = {
        "schema_version": "paper_iii_direct_davidson_completion_v1",
        "method_id": "direct_davidson_qse",
        "completion_route": ROUTE_DIRECT_DAVIDSON,
        "davidson_invoked": True,
        "online_only": True,
        "terminal_status": terminal_status,
        "native_stop_reason": native_stop_reason,
        "target_root_count": roots_requested,
        "residual_stop_threshold": float(audit["config"]["eps_residual"]),
        "terminal_dimension": int(audit["terminal_dimension"]),
        "terminal_retained_rank": int(audit["terminal_retained_rank"]),
        "target_window_complete": bool(audit["target_window_complete"]),
        "root_residual_norms": [float(value) for value in audit["root_residual_norms"]],
        "max_root_residual": float(audit["max_root_residual"]),
        "initialization_receipt": initialization_receipt,
        "costing": dict(audit["costing"]),
    }
    if include_terminal_ritz_vectors:
        completion["terminal_ritz_vectors"] = np.asarray(
            audit["final_ritz_vectors"], dtype=complex
        )
    return rows, completion


def trace_direct_davidson_with_completion(
    problem: Any,
    *,
    k_max: int,
    target_root_count: int = _TARGET_ROOTS,
    include_terminal_ritz_vectors: bool = False,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Return direct-Davidson trace rows and its required terminal receipt."""

    return _trace_direct_davidson(
        problem,
        k_max=k_max,
        target_root_count=target_root_count,
        require_completion_metadata=True,
        include_terminal_ritz_vectors=include_terminal_ritz_vectors,
    )


def trace_adaptive_qse(
    problem: Any,
    *,
    k_max: int,
    target_root_count: int = _TARGET_ROOTS,
) -> list[dict[str, Any]]:
    """Compatibility wrapper returning only the direct-Davidson trace rows."""

    rows, _completion = _trace_direct_davidson(
        problem,
        k_max=k_max,
        target_root_count=target_root_count,
        require_completion_metadata=False,
    )
    return rows


def trace_selected_qse_fixed_pool(
    problem: Any,
    order: Sequence[int],
    *,
    k_max: int,
    stride: int,
    record_stop: Mapping[str, Any],
    target_root_count: int = _TARGET_ROOTS,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run canonical selected QSE without an implicit completion solver.

    The production selector supplies ``order`` and its online terminal receipt;
    certified exchange is applied to every recorded prefix.  Pool exhaustion,
    a dimension cap, or an incomplete window certificate ends this route with
    a structured status.  Davidson is intentionally absent from this function.
    """

    record_cap = len(order)
    rows = trace_arm(
        problem,
        order,
        stride=int(stride),
        k_max=min(int(k_max), int(record_cap)),
        exchange_policy="every_k",
    )
    for row in rows:
        row.setdefault("phase", "records")
    support_certificate = None
    if rows:
        support_certificate = certify_fixed_pool_support(
            problem.basis,
            rows[-1]["support_indices"],
            hamiltonian=problem.hamiltonian,
            prepared_state=problem.ground,
            basis_vector_policy=_Q0_POLICY,
            target_root_count=int(target_root_count),
            residual_stop_threshold=float(
                record_stop.get("residual_stop_threshold") or RESIDUAL_MARKER
            ),
        )
    completion = classify_selected_qse_completion(
        dict(record_stop),
        trace_terminal_record_count=(0 if not rows else int(rows[-1]["k"])),
        selector_terminal_record_count=int(record_cap),
        target_root_count=int(target_root_count),
        trace_reached_selector_terminal=bool(rows) and int(record_cap) <= int(k_max),
        terminal_support_certificate=support_certificate,
    )
    return rows, {
        "method_id": "record_first_adaptive_qse",
        **completion,
        "record_stop": dict(record_stop),
    }


def trace_selected_qse_davidson_hybrid(
    problem: Any,
    order: Sequence[int],
    *,
    k_max: int,
    stride: int,
    record_stop: Mapping[str, Any],
    target_root_count: int = _TARGET_ROOTS,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run the explicit selected-QSE-to-Davidson hybrid route.

    Phase A buys cheap alphabet directions under the production rule. The
    production selector's terminal receipt determines the transition: a
    converged record residual terminates the method, while genuine alphabet
    exhaustion hands the actual exchange-maintained support to residual
    synthesis as seed elements.  Exact reference errors annotate the trace but
    never control the handoff.

    This function is intentionally not called by canonical selected QSE. It is
    retained as the future separately declared route whose receipt charges the
    selected-record stage and every synthesized Davidson direction.
    """

    stop_receipt = dict(record_stop)
    stop_reason = str(stop_receipt.get("stop_reason", ""))
    record_cap = len(order)
    phase_a_cap = min(int(k_max), int(record_cap))
    rows = trace_arm(
        problem,
        order,
        stride=stride,
        k_max=phase_a_cap,
        exchange_policy="every_k",
    )
    for row in rows:
        row.setdefault("phase", "records")
    if record_cap > int(k_max):
        return rows, {
            "method_id": "selected_qse_davidson_hybrid",
            "completion_route": ROUTE_SELECTED_QSE_DAVIDSON_HYBRID,
            "davidson_invoked": False,
            "fired": False,
            "reason": "record_stop_beyond_dimension_cap",
            "trigger_source": "record_selector_terminal_receipt",
            "record_stop": stop_receipt,
        }
    if not rows:
        return rows, {
            "method_id": "selected_qse_davidson_hybrid",
            "completion_route": ROUTE_SELECTED_QSE_DAVIDSON_HYBRID,
            "davidson_invoked": False,
            "fired": False,
            "reason": "empty_record_support",
            "trigger_source": "record_selector_terminal_receipt",
            "record_stop": stop_receipt,
        }
    if stop_reason == "residual_converged":
        return rows, {
            "method_id": "selected_qse_davidson_hybrid",
            "completion_route": ROUTE_SELECTED_QSE_DAVIDSON_HYBRID,
            "davidson_invoked": False,
            "fired": False,
            "reason": "record_residual_converged",
            "trigger_source": "record_selector_terminal_receipt",
            "record_stop": stop_receipt,
        }
    if stop_reason != "pool_exhausted":
        return rows, {
            "method_id": "selected_qse_davidson_hybrid",
            "completion_route": ROUTE_SELECTED_QSE_DAVIDSON_HYBRID,
            "davidson_invoked": False,
            "fired": False,
            "reason": "record_acquisition_not_terminal",
            "trigger_source": "record_selector_terminal_receipt",
            "record_stop": stop_receipt,
        }

    phase_a = list(rows)
    base = phase_a[-1]
    phase_a_error = base.get("max_root_abs_error")
    phase_a_support_indices = [int(index) for index in base["support_indices"]]
    seed_indices = list(phase_a_support_indices)
    seed = [problem.basis[index] for index in seed_indices]
    if 1 + len(seed) > int(k_max):
        raise ValueError(
            "DAVIDSON_INITIALIZATION_CAP_INSUFFICIENT: hybrid phase-A support "
            "plus the reference exceeds the declared hybrid dimension cap."
        )

    from pipelines.qse_spectra.compiled_costs import (
        ORACLE_KIND_MARRAKESH_GRAPH_SPAN,
        annotate_basis_with_compiled_costs,
        resolve_cost_weights_preset,
    )
    from pipelines.qse_spectra.core import polynomial_basis_element
    from pipelines.exact_bench.paper_iii_qse_measurement_cost import _polynomial_words

    est = annotate_basis_with_compiled_costs(
        [polynomial_basis_element(problem.hamiltonian, name="first_order_trotter_step")],
        num_qubits=problem.num_qubits,
        oracle_kind=ORACLE_KIND_MARRAKESH_GRAPH_SPAN,
        cost_weights=resolve_cost_weights_preset("two_qubit_only_v1"),
    )[0].estimate
    per_direction = {
        "n2q": float(est.c_hat_2q),
        "d2q": float(est.c_hat_d),
        "dc": float(est.c_hat_d) + float(est.c_hat_1q),
    }
    ham_terms = len(_polynomial_words(problem.hamiltonian))

    audit = run_adaptive_qse_benchmark(
        problem.hamiltonian,
        problem.ground,
        target_roots=int(target_root_count) + 1,
        eps_residual=1.0e-14,
        max_dimension=int(k_max),
        seed_elements=seed,
        direction_resources=per_direction,
    )
    admitted_seed_count = int(audit["seed_policy"]["admitted_seed_direction_count"])
    initial_adaptive_dimension = 1 + admitted_seed_count
    phase_a_resources = {
        resource: float(base[resource]) for resource in ("n2q", "d2q", "dc")
    }
    refs = problem.references
    phase_b: list[dict[str, Any]] = []
    for it in audit["iterations"]:
        roots = list((it.get("root_energies") or [])[1:])
        per_root = (
            [abs(float(roots[r]) - float(ref)) for r, ref in enumerate(refs)]
            if len(roots) >= len(refs) else None
        )
        err = max(per_root) if per_root is not None else None
        d = int(it["dimension"])
        if d <= initial_adaptive_dimension:
            continue                      # seed re-solve, already in phase A
        synthesized_direction_count = d - initial_adaptive_dimension
        resources = _mixed_resource_triple(
            seed_resources=phase_a_resources,
            per_synthesized_direction=per_direction,
            synthesized_direction_count=synthesized_direction_count,
        )
        pairs = d * (d + 1) // 2
        phase_b.append({
            "k": d,
            "support_size": d,
            "exchanged": False,
            "phase": "synthesis",
            "retained_rank": int(it["retained_rank"]),
            "max_root_abs_error": err,
            "per_root_abs_error": per_root,
            "root_match_convention": "index_matched_ascending",
            # phase-A record cost is already paid; synthesis adds on top
            "n2q": resources["n2q"],
            "d2q": resources["d2q"],
            "dc": resources["dc"],
            "synthesized_direction_count": synthesized_direction_count,
            "costing_convention": "record_support_plus_trotterized_residual_directions_v2",
            "root_energies": roots,
            "estimator": {
                "pair_count": pairs,
                "queries": int(pairs * (1 + ham_terms)),
                "hamiltonian_pauli_terms": int(ham_terms),
                "convention": "record_first_adaptive_pencil_no_qwc_reuse_after_handoff",
            },
        })
    terminal_root_energies = [float(value) for value in audit["root_energies"][1:]]
    terminal_window_error = (
        max(
            abs(float(terminal_root_energies[root]) - float(reference))
            for root, reference in enumerate(refs)
        )
        if len(terminal_root_energies) >= len(refs)
        else None
    )
    return phase_a + phase_b, {
        "method_id": "selected_qse_davidson_hybrid",
        "completion_route": ROUTE_SELECTED_QSE_DAVIDSON_HYBRID,
        "davidson_invoked": True,
        "fired": True,
        "reason": "record_pool_exhausted",
        "trigger_k": int(base["k"]),
        "trigger_source": "record_selector_terminal_receipt",
        "phase_a_error": None if phase_a_error is None else float(phase_a_error),
        "phase_a_n2q": float(base["n2q"]),
        "phase_a_support_indices": phase_a_support_indices,
        "seed_indices": seed_indices,
        "seed_size": len(seed),
        "admitted_seed_direction_count": admitted_seed_count,
        "initial_adaptive_dimension": initial_adaptive_dimension,
        "phase_a_resources": phase_a_resources,
        "per_synthesized_direction": dict(per_direction),
        "adaptive_stop_reason": str(audit["stop_reason"]),
        "residual_stop_is_window_completeness_certificate": False,
        "terminal_root_energies": terminal_root_energies,
        "terminal_window_error": terminal_window_error,
        "record_stop": stop_receipt,
    }


def trace_krylov(problem: Any, *, k_max: int) -> list[dict[str, Any]]:
    """Growth trace for real-time Krylov, scored on the same references.

    States exp(-i H k dt) from a seeded random sector kick orthogonal to the
    reference (the exact reference has an identically zero Hamiltonian
    residual, so a residual kick is unusable). Per dimension the pencil is
    solved with the shared cutoff and each target root is scored by its
    best-matching pencil root -- the Krylov-favouring convention. State
    preparation is charged one first-order Trotter step of H per interval,
    the same costing the adaptive method uses.
    """

    from pipelines.qse_spectra.compiled_costs import (
        ORACLE_KIND_MARRAKESH_GRAPH_SPAN,
        annotate_basis_with_compiled_costs,
        resolve_cost_weights_preset,
    )
    from pipelines.qse_spectra.core import polynomial_basis_element
    from pipelines.exact_bench.paper_iii_qse_measurement_cost import _polynomial_words

    step = annotate_basis_with_compiled_costs(
        [polynomial_basis_element(problem.hamiltonian, name="first_order_trotter_step")],
        num_qubits=problem.num_qubits,
        oracle_kind=ORACLE_KIND_MARRAKESH_GRAPH_SPAN,
        cost_weights=resolve_cost_weights_preset("two_qubit_only_v1"),
    )[0].estimate
    ham_terms = len(_polynomial_words(problem.hamiltonian))

    dim = 1 << int(problem.num_qubits)
    dense = np.zeros((dim, dim), dtype=complex)
    from pipelines.exact_bench.paper_iii_qse_regime_frontier_sweep import _dense_hamiltonian

    dense = _dense_hamiltonian(problem.hamiltonian, dim)
    energies, vectors = np.linalg.eigh(dense)
    ground = np.asarray(problem.ground, dtype=complex)
    rng = np.random.default_rng(20260826)
    support = np.abs(ground) > 0.0
    source = np.zeros_like(ground)
    n = int(support.sum())
    source[support] = rng.normal(size=n) + 1j * rng.normal(size=n)
    source = source - complex(np.vdot(ground, source)) * ground
    norm = float(np.linalg.norm(source))
    if norm <= 1.0e-14:
        return []
    amplitudes = vectors.conj().T @ (source / norm)
    refs = problem.references

    best: dict[int, dict[str, Any]] = {}
    for dt in (0.25, 0.5):
        states = [
            vectors @ (np.exp(-1j * energies * float(dt) * k) * amplitudes)
            for k in range(int(k_max) + 1)
        ]
        for d in range(2, int(k_max) + 1):
            block = states[:d]
            S = np.array([[np.vdot(a, b) for b in block] for a in block])
            M = np.array([[np.vdot(a, dense @ b) for b in block] for a in block])
            S = 0.5 * (S + S.conj().T)
            M = 0.5 * (M + M.conj().T)
            w, U = np.linalg.eigh(S)
            keep = w > 1.0e-12 * float(max(w.max(), 0.0))
            if int(keep.sum()) < 1:
                continue
            X = U[:, keep] / np.sqrt(w[keep])
            red = X.conj().T @ M @ X
            roots = np.sort(np.linalg.eigvalsh(0.5 * (red + red.conj().T)))
            per_root = [float(np.min(np.abs(roots - float(r)))) for r in refs]
            err = max(per_root)
            steps_charged = d * (d - 1) // 2
            pairs = d * (d + 1) // 2
            row = {
                "k": int(d),
                "support_size": int(d),
                "exchanged": False,
                "retained_rank": int(keep.sum()),
                "max_root_abs_error": err,
                "per_root_abs_error": per_root,
                "root_match_convention": "best_matching_pencil_root",
                "n2q": float(step.c_hat_2q) * steps_charged,
                "d2q": float(step.c_hat_d) * steps_charged,
                "dc": (float(step.c_hat_d) + float(step.c_hat_1q)) * steps_charged,
                "dt": float(dt),
                "estimator": {
                    "pair_count": pairs,
                    "queries": int(pairs * (1 + ham_terms)),
                    "hamiltonian_pauli_terms": int(ham_terms),
                    "convention": "synthesized_basis_pencil_no_qwc_reuse",
                },
            }
            prev = best.get(d)
            if prev is None or err < prev["max_root_abs_error"]:
                best[d] = row
    del dense
    return [best[d] for d in sorted(best)]


def resolve_from_trace(
    rows: Sequence[dict[str, Any]], eps_e: float, *, extendable: bool
) -> dict[str, Any]:
    reaching = [
        r for r in rows
        if r.get("max_root_abs_error") is not None
        and float(r["max_root_abs_error"]) <= float(eps_e)
    ]
    if reaching:
        best = min(reaching, key=lambda r: float(r["n2q"]))
        return {"status": STATUS_REACHED, "crossing": dict(best)}  # carries row estimator if present
    finite = [r for r in rows if r.get("max_root_abs_error") is not None]
    terminal = min(finite, key=lambda r: float(r["max_root_abs_error"])) if finite else None
    return {
        "status": STATUS_NOT_IN_POOL if extendable else STATUS_UNATTAINABLE,
        "terminal": None if terminal is None else dict(terminal),
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-json", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--regime-set", choices=sorted(REGIME_SETS), default="hubbard_l2")
    parser.add_argument("--regimes", default=None, help="Comma-separated regime filter within the set.")
    parser.add_argument("--stride", type=int, default=2)
    parser.add_argument(
        "--k-max",
        type=int,
        default=DEFAULT_DIMENSION_CAP,
        help=(
            "Common subspace-dimension cap. The default reaches the largest "
            "observed record-exhaustion receipt and leaves room for residual completion."
        ),
    )
    parser.add_argument(
        "--krylov-k-max", type=int, default=40,
        help="Krylov dimension cap. Krylov needs larger dimension than a record "
             "basis to resolve an interior window; capping it low cripples the "
             "benchmark rather than measuring it.",
    )
    parser.add_argument(
        "--exchange-policy", choices=("crossing", "every_k", "both"), default="every_k"
    )
    args = parser.parse_args(argv)

    policies = (
        ("crossing", "every_k") if args.exchange_policy == "both"
        else (args.exchange_policy,)
    )
    regimes_payload: dict[str, Any] = {}
    terminal_status_counts: dict[str, int] = {}

    wanted = None if args.regimes is None else {t.strip() for t in str(args.regimes).split(",")}
    for regime, u, g_ep, n_ph_max in REGIME_SETS[str(args.regime_set)]:
        if wanted is not None and regime not in wanted:
            continue
        problem = load_problem(
            regime=regime, u=u, g_ep=g_ep, n_ph_max=n_ph_max, target_roots=_TARGET_ROOTS
        )
        print(f"\n== {regime} (pool={len(problem.basis)})", flush=True)

        selection = select_static_qse_records(
            problem.basis,
            config=StaticRecordSelectionConfig(
                mode="geometry_selected",
                max_records=len(problem.basis),
                geometry_target_roots=_TARGET_ROOTS,
                geometry_cost_discount_alpha=1.0,
            ),
            hamiltonian=problem.hamiltonian,
            prepared_state=problem.ground,
            basis_vector_policy=_Q0_POLICY,
            compiled_costs=problem.costs,
        )
        our_order = [int(i) for i in selection.selected_original_indices]

        marker = select_static_qse_records(
            problem.basis,
            config=StaticRecordSelectionConfig(
                mode="geometry_selected",
                max_records=len(problem.basis),
                geometry_target_roots=_TARGET_ROOTS,
                geometry_cost_discount_alpha=1.0,
                geometry_residual_stop=RESIDUAL_MARKER,
            ),
            hamiltonian=problem.hamiltonian,
            prepared_state=problem.ground,
            basis_vector_policy=_Q0_POLICY,
            compiled_costs=problem.costs,
        )
        marker_k = len(marker.selected_original_indices)

        cheapest = sorted(range(len(problem.basis)),
                          key=lambda i: (float(problem.costs[i]), i))
        fixed_indices = [
            i for i, e in enumerate(problem.basis)
            if _element_family(e.name) in _LINEAR_RESPONSE_FAMILIES
        ]

        arms: dict[str, Any] = {}
        for policy in policies:
            for arm, order in (
                ("record_only", our_order),
                ("cheapest_first", cheapest),
                ("input_order", list(range(len(problem.basis)))),
            ):
                # Exchange belongs to the record selector; controls are not exchanged.
                pol = policy if arm == "record_only" else "none"
                key = f"{arm}__{policy}" if arm == "record_only" else arm
                if key in arms:
                    continue
                rows = trace_arm(
                    problem, order,
                    stride=int(args.stride), k_max=int(args.k_max), exchange_policy=pol,
                )
                arms[key] = {"trace": rows}
                best = min((r for r in rows if r["max_root_abs_error"] is not None),
                           key=lambda r: r["max_root_abs_error"], default=None)
                if best:
                    print(
                        f"   {key:<22} terminal {best['max_root_abs_error']:.1e} "
                        f"@k={best['k']} N2q={best['n2q']:.0f}", flush=True
                    )

        arms["adaptive_qse"] = {
            "trace": trace_adaptive_qse(problem, k_max=int(args.k_max)),
            "note": (
                "external benchmark; starts from the declared fixed record seed, "
                "then synthesizes residual directions outside the alphabet"
            ),
        }
        best_ad = min(
            (r for r in arms["adaptive_qse"]["trace"] if r["max_root_abs_error"] is not None),
            key=lambda r: r["max_root_abs_error"], default=None,
        )
        if best_ad:
            print(f"   {'adaptive_qse':<22} terminal {best_ad['max_root_abs_error']:.1e} "
                  f"@k={best_ad['k']} N2q={best_ad['n2q']:.0f}", flush=True)

        record_first_rows, completion_info = trace_selected_qse_fixed_pool(
            problem,
            [int(index) for index in marker.selected_original_indices],
            k_max=int(args.k_max),
            stride=int(args.stride),
            record_stop=marker.geometry_stop or {"stop_reason": "missing"},
            target_root_count=_TARGET_ROOTS,
        )
        terminal_status = str(completion_info["terminal_status"])
        terminal_status_counts[terminal_status] = (
            terminal_status_counts.get(terminal_status, 0) + 1
        )
        arms["record_first_adaptive_qse"] = {
            "trace": record_first_rows,
            "algorithm_completion": completion_info,
            "role": "canonical_method",
            "note": (
                "fixed-pool exchange-maintained selected QSE; target-window "
                "certification, pool exhaustion, or the dimension cap terminates the route"
            ),
        }
        best_record_first = min(
            (r for r in record_first_rows if r["max_root_abs_error"] is not None),
            key=lambda r: r["max_root_abs_error"], default=None,
        )
        if best_record_first:
            print(
                f"   {'record_first_adaptive':<22} "
                f"terminal {best_record_first['max_root_abs_error']:.1e} "
                f"@k={best_record_first['k']} N2q={best_record_first['n2q']:.0f} "
                f"({terminal_status})",
                flush=True,
            )

        arms["krylov"] = {
            "trace": trace_krylov(problem, k_max=int(args.krylov_k_max)),
            "note": "external benchmark; different construction family, does not consume the alphabet",
        }
        best_kr = min(
            (r for r in arms["krylov"]["trace"] if r["max_root_abs_error"] is not None),
            key=lambda r: r["max_root_abs_error"], default=None,
        )
        if best_kr:
            print(f"   {'krylov':<22} terminal {best_kr['max_root_abs_error']:.1e} "
                  f"@k={best_kr['k']} N2q={best_kr['n2q']:.0f}", flush=True)

        f_err, f_rank, f_per_root, _f_roots = _window_error(problem, fixed_indices)
        arms["fixed_class"] = {
            "trace": [
                {
                    "k": len(fixed_indices), "support_size": len(fixed_indices),
                    "exchanged": False, "retained_rank": f_rank,
                    "max_root_abs_error": f_err,
                    "per_root_abs_error": f_per_root,
                    "root_match_convention": "index_matched_ascending",
                    **problem.resource_triple(fixed_indices),
                }
            ]
        }

        cells: dict[str, Any] = {}
        for eps_e in ERROR_TARGET_LADDER:
            key = f"{eps_e:.0e}"
            cells[key] = {}
            for arm_key, arm in arms.items():
                extendable = arm_key in {
                    "record_first_adaptive_qse",
                    "adaptive_qse",
                    "krylov",
                }
                cells[key][arm_key] = resolve_from_trace(
                    arm["trace"], eps_e, extendable=extendable
                )
        # Policy A: exchange only the prefix that first crosses each target.
        for eps_e in ERROR_TARGET_LADDER:
            key = f"{eps_e:.0e}"
            cell = cells[key].get("record_only__crossing")
            if cell and cell.get("status") == STATUS_REACHED:
                k = int(cell["crossing"]["k"])
                compressed = _exchange(problem, our_order[:k])
                cell["crossing_exchanged"] = _row(problem, compressed, k, exchanged=True)

        # Estimator work (axis 4) at every crossing point -- protocol section 3
        # mandates all four axes in a reported cell.
        supports = {
            "record_only__crossing": our_order,
            "record_only__every_k": our_order,
            "cheapest_first": cheapest,
            "input_order": list(range(len(problem.basis))),
            "fixed_class": fixed_indices,
        }  # adaptive_qse absent here: its estimator rides on its own trace rows
        for eps_e in ERROR_TARGET_LADDER:
            key = f"{eps_e:.0e}"
            for arm_key, cell in cells[key].items():
                if cell.get("status") != STATUS_REACHED:
                    continue
                if cell["crossing"].get("estimator") is not None:
                    continue
                support_indices = cell["crossing"].get("support_indices")
                if support_indices is not None:
                    idx = [int(index) for index in support_indices]
                    est = problem.estimator_cost(idx)
                    est["convention"] = "record_pencil_qwc_basis_cover"
                    est["queries"] = int(est["qwc_groups"])
                    cell["crossing"]["estimator"] = est
                    continue
                order_src = supports.get(arm_key)
                if order_src is None:
                    continue
                k = int(cell["crossing"]["k"])
                idx = (
                    list(order_src) if arm_key == "fixed_class"
                    else list(order_src[:k])
                )
                if arm_key == "record_only__every_k":
                    idx = _exchange(problem, idx)
                est = problem.estimator_cost(idx)
                est["convention"] = "record_pencil_qwc_basis_cover"
                est["queries"] = int(est["qwc_groups"])
                cell["crossing"]["estimator"] = est

        regimes_payload[regime] = {
            "u": float(u), "g_ep": float(g_ep), "n_ph_max": int(n_ph_max),
            "pool_size": len(problem.basis),
            "shared_problem_receipt": problem.arm_receipt(),
            "reference_ground_energy": problem.ground_energy,
            "reference_excitations": list(problem.references),
            "residual_stop_marker": {"eps_res": RESIDUAL_MARKER, "k": marker_k},
            "fixed_class_size": len(fixed_indices),
            "arms": arms,
            "cells": cells,
        }

    payload = {
        "schema_version": "paper_iii_selected_qse_fixed_pool_campaign_v1",
        "protocol": "agent_guidance/qse/paper-iii-comparison-protocol.md#1",
        "policy": "diagnostic_only_growth_trace_campaign",
        "controller_boundary": {
            "feeds_controller_decisions": False,
            "controller_usable": False,
            "post_run_diagnostic_only": True,
        },
        "convention": (
            "every method grows one direction at a time to a fixed cap; the canonical "
            "selected-QSE method terminates from its online record-selector receipt and "
            "never invokes Davidson, while "
            "K*(eps_E) is read from the completed trace"
        ),
        "regime_set": str(args.regime_set),
        "k_max": int(args.k_max),
        "stride": int(args.stride),
        "exchange_policies": list(policies),
        "error_target_ladder": [float(x) for x in ERROR_TARGET_LADDER],
        "target_roots": _TARGET_ROOTS,
        "terminal_status_counts": terminal_status_counts,
        "fixed_pool_cell_count": len(regimes_payload),
        "fixed_pool_uncertified_count": sum(
            count
            for status, count in terminal_status_counts.items()
            if status != "TARGET_WINDOW_CERTIFIED"
        ),
        "regimes": regimes_payload,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    print(f"\noutput_json: {args.output_json}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
